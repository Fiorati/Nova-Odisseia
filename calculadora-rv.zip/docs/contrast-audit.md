# Auditoria de contraste — 28/08/2026

## Evidência enviada pelo usuário

A captura mostra uma superfície verde-escura com o título **“Frases de campo”** e a orientação **“Reescreva o script acima para um contexto real, sem incluir dados pessoais, números confidenciais ou informações fora dos sistemas autorizados.”**. O texto foi renderizado em verde quase tão escuro quanto o fundo, tornando título e orientação praticamente ilegíveis.

O reparo deve atribuir primeiro plano claro explicitamente a títulos e textos auxiliares dentro de superfícies escuras, sem depender de cor herdada. A varredura também deve buscar superfícies `bg-emerald-*`, `bg-[#0e3426]` ou equivalentes combinadas com `text-emerald-9*`, `text-slate-9*` ou ausência de classe de primeiro plano.

## Verificação após a correção

As capturas em **1280 × 720 px** e **375 × 812 px** confirmaram que o tema escuro permanece limitado à navegação principal e aos heróis que já possuem primeiro plano claro. A Biblioteca, o painel de Carteiras e Campanhas mantiveram títulos, textos auxiliares, campos e cartões legíveis; o cartão branco de Campanhas deixou de receber o fundo escuro global aplicado anteriormente a qualquer elemento `aside`.

No celular vertical, o menu, o seletor de navegação, os heróis e os textos auxiliares conservaram hierarquia visual sem corte horizontal. A tela de Carteiras exibiu a origem consolidada e o histórico por rota com texto escuro sobre superfícies claras.
