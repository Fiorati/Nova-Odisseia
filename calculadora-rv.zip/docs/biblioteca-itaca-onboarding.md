# Onboarding de Clientes e Gestão Estratégica da Base

**Biblioteca de Ítaca · Trilha inaugural**

> **Propósito da trilha.** Transformar o fechamento em início de uma jornada consultiva: alinhamento de valor, agenda previsível, execução registrada e revisão orientada à evolução do negócio do cliente.

## Como usar este treinamento

Este curso foi desenhado para estudo individual ou para uma sessão de 60 a 90 minutos em equipe. Cada módulo possui uma decisão de campo, um roteiro de comunicação e uma prática. O objetivo não é decorar frases: é criar clareza para o cliente, registrar acordos e revisar resultados com disciplina.

As menções a CRM, tarefas, réguas, matriz de ativação ou produtos são **pontos de conexão com a rotina de trabalho relatada no material-base**. Consulte a liderança e a documentação interna vigente antes de executar qualquer procedimento operacional, condição comercial, ativação, retirada de equipamento ou comunicação com o cliente.

| Ao concluir, você será capaz de | Evidência prática |
| --- | --- |
| Posicionar a relação como uma parceria de negócio desde o aceite. | Um resumo de valor e de compromissos aprovado pelo cliente. |
| Agendar uma sequência de acompanhamentos com objetivo explícito. | Datas combinadas e próximos passos registrados. |
| Registrar tarefas úteis no CRM, sem dados sensíveis fora dos sistemas autorizados. | Uma tarefa por visita, com objetivo, contexto, ação e critério de sucesso. |
| Conduzir revisões que geram aprendizado e próximos passos. | Um plano de ação de uma página com responsável e prazo. |

## Mapa da jornada: do acordo ao primeiro valor

Onboarding é o processo de ajudar o cliente a passar do “fechamos” para o “estou obtendo valor e consigo operar com autonomia”. Referências de Customer Success destacam a importância de uma jornada estruturada, com primeira vitória, educação adequada e acompanhamento consistente. [1] [2]

| Marco da jornada | Pergunta que guia a conversa | Saída mínima |
| --- | --- | --- |
| **Fechamento** | “Que resultado de negócio esta parceria deve ajudar a mover?” | Hipótese de valor e expectativa registrada. |
| **Agenda contratada** | “Quais datas fazem sentido para validar cada etapa?” | Três contatos com finalidade combinada. |
| **Ativação** | “O que precisa estar pronto para o cliente começar com segurança?” | Checklist de início e responsável por pendências. |
| **Consolidação** | “O que está funcionando, o que travou e qual é a prioridade?” | Diagnóstico curto e plano de correção. |
| **Plano estratégico** | “Qual próximo experimento pode gerar valor observável?” | Ação, dono, prazo e sinal de sucesso. |

## Módulo 1 — O discurso no fechamento: vender continuidade, não apenas uma solução

O fechamento não encerra a venda: inaugura a confiança. Antes de prometer qualquer resultado, traduza o que foi ouvido sobre o negócio em uma hipótese verificável. Uma boa conversa evita frases genéricas e deixa claro o que será acompanhado, por quem e em qual cadência.

### A estrutura em quatro movimentos

| Movimento | Intenção | Perguntas e exemplos de linguagem |
| --- | --- | --- |
| **1. Reafirmar o contexto** | Mostrar escuta e reduzir ambiguidade. | “Você comentou que o horário de pico concentra boa parte das vendas. É nesse ponto que vamos observar primeiro.” |
| **2. Definir uma hipótese de valor** | Conectar a solução a uma necessidade, sem prometer o que não controla. | “Nossa hipótese é que, com a operação pronta e o time orientado, você terá uma alternativa de pagamento mais simples para o cliente final.” |
| **3. Apresentar a jornada** | Dar previsibilidade. | “Além da etapa inicial, proponho voltarmos em duas datas para conferir uso, ajustar pendências e escolher o próximo ganho.” |
| **4. Confirmar compromisso mútuo** | Tornar as responsabilidades visíveis. | “Eu fico responsável por conduzir e registrar os próximos passos; do seu lado, quem será nosso ponto focal para validar as ações?” |

### Script adaptável de fechamento consultivo

> “Antes de concluirmos, quero alinhar como vamos trabalhar depois de hoje. Meu papel é acompanhar a implantação e ajudar você a transformar o acordo em rotina de operação. Vamos definir agora três momentos: o início, uma checagem de consolidação e uma conversa de plano de ação. Em cada encontro, vamos sair com uma decisão e um próximo passo. Para você, qual resultado faria esta parceria valer a pena nos próximos meses?”

**Prática de campo.** Reescreva o script usando o contexto de um cliente real, mas não inclua dados pessoais, números confidenciais ou informações fora dos sistemas autorizados. A frase final deve convidar o cliente a definir o que percebe como valor.

### Erros que atrasam a jornada

| Evite | Substitua por |
| --- | --- |
| Prometer resultado garantido ou prazo que não depende apenas de você. | Explicar o que será acompanhado, quais são as premissas e quando a evolução será revisada. |
| Encerrar a conversa sem um próximo encontro. | Combinar uma próxima data e a finalidade objetiva dela. |
| Tratar o cliente como uma etapa administrativa. | Fazer uma pergunta de negócio e registrar a resposta como contexto do plano. |

## Módulo 2 — Agenda contratada: previsibilidade é uma entrega

Uma agenda “contratada” não é uma sequência de visitas vagas. É um pacto de ritmo: o cliente sabe quando será procurado, qual assunto será tratado e o que precisa trazer para a conversa. A prática reduz retrabalho e torna mais fácil perceber um bloqueio antes que ele se transforme em frustração.

### Cadência de três encontros

| Encontro | Objetivo | Preparação do agente | Evidência ao encerrar |
| --- | --- | --- | --- |
| **Visita 1 · Ativação** | Garantir entendimento da etapa inicial, responsáveis e pendências. | Rever o que foi acordado, materiais vigentes e pessoas que participam da operação. | Checklist de início; pendências, responsáveis e data de retorno. |
| **Visita 2 · Consolidação** | Observar a adoção, ouvir atritos e confirmar os acordos da etapa inicial. | Levar perguntas de diagnóstico e os combinados anteriores. | O que avançou, o que bloqueou e a ação prioritária. |
| **Visita 3 · Plano estratégico** | Testar a hipótese de valor e escolher um experimento viável. | Organizar evidências trazidas pelo cliente e alternativas permitidas pela política vigente. | Plano de ação com objetivo, dono, prazo e sinal de evolução. |

### Roteiro de convite e confirmação

> “Para que a implantação não fique solta, sugiro já reservarmos três momentos curtos. No primeiro, alinhamos o início e as pendências; no segundo, verificamos como a operação se adaptou; no terceiro, analisamos o que vale ajustar para aproximar o resultado que você quer. Posso te sugerir estas datas? Se houver alguma mudança, nós a registramos e já deixamos a próxima confirmação combinada.”

**Checklist antes de sair do cliente.** Confirme a data, o horário, o participante principal, o objetivo da próxima conversa e o que cada lado fará até lá. Envie ou registre o resumo pelos canais aprovados pela organização.

## Módulo 3 — CRM: transformar conversa em continuidade operacional

Um registro de qualidade é a ponte entre intenção e execução. Ele permite que você recupere o contexto, que a liderança apoie quando necessário e que o cliente não precise repetir a própria história. Sistemas de CRM, tarefas e réguas devem ser utilizados exclusivamente conforme a política e os acessos internos autorizados.

### Estrutura de uma tarefa útil

| Campo | Como preencher | Exemplo seguro |
| --- | --- | --- |
| **Objetivo** | Comece com um verbo e um resultado observável. | “Validar pendências da ativação e confirmar o responsável do cliente.” |
| **Contexto** | Registre o que foi combinado, de modo conciso. | “Cliente prioriza reduzir dúvidas do time no horário de maior movimento.” |
| **Ação** | Descreva o que será feito no encontro. | “Revisar checklist, ouvir os operadores e listar bloqueios.” |
| **Critério de sucesso** | Diga como saberemos que a conversa avançou. | “Pendências classificadas, dono definido e próximo contato confirmado.” |
| **Prazo** | Use a data efetivamente acordada. | “Data da próxima visita ou contato.” |

### Modelo de registro depois da visita

> **Resumo:** [o que o cliente confirmou, em linguagem objetiva].  
> **Pendência prioritária:** [o que bloqueia o próximo passo].  
> **Responsável:** [papel da pessoa, conforme registro autorizado].  
> **Ação do agente:** [ação específica].  
> **Próximo marco:** [data e objetivo].

**Atenção à privacidade.** Nunca copie informações de carteira, credenciais, documentos, links temporários ou dados pessoais em materiais de estudo, aplicativos paralelos ou canais não autorizados. O treinamento ensina a qualidade do raciocínio; a execução deve ocorrer nos sistemas aprovados.

## Módulo 4 — Validação do plano: medir, aprender e ajustar

O plano estratégico precisa ser pequeno o suficiente para ser executado e claro o suficiente para ser avaliado. Em vez de uma promessa ampla, escolha um experimento que responda a uma pergunta. Por exemplo: “Se o time dominar a orientação definida, há mais fluidez no atendimento?” A resposta vem de observação responsável, feedback do cliente e indicadores que estejam disponíveis e autorizados.

### Canvas de plano de ação

| Elemento | Pergunta de qualidade |
| --- | --- |
| **Resultado desejado** | Que mudança o cliente quer perceber no negócio ou na operação? |
| **Hipótese** | O que acreditamos que pode ajudar e por quê? |
| **Ação simples** | Qual é o menor passo que pode ser feito nesta semana? |
| **Dono** | Quem executará e quem acompanhará? |
| **Prazo** | Quando revisaremos o resultado? |
| **Sinal de evolução** | Que evidência observável mostrará avanço ou necessidade de ajuste? |

### Perguntas para uma revisão madura

1. O que o cliente esperava que acontecesse desde o último encontro?
2. O que ocorreu de fato, sem justificar antes de observar?
3. Onde houve fricção: entendimento, processo, acesso, treinamento ou prioridade?
4. Qual ação cabe a cada parte até o próximo marco?
5. Que pergunta ainda não conseguimos responder?

O foco em primeira vitória, etapas progressivas e escuta de feedback está alinhado a recomendações amplamente divulgadas de onboarding e Customer Success. [1] [2] A lógica de usar feedback para orientar melhorias também se conecta à abordagem de lealdade do Net Promoter System. [3]

## Gestão estratégica da base: cinco rotinas que evitam abandono

| Rotina | Frequência sugerida | Pergunta operacional |
| --- | --- | --- |
| **Handoff de contexto** | Ao concluir a venda | “O que foi prometido, quem decide e que resultado importa?” |
| **Mapa de marcos** | No início e a cada revisão | “Qual é o próximo passo visível para o cliente?” |
| **Leitura de sinais** | Entre visitas | “Há evidência de avanço, dúvida ou bloqueio?” |
| **Ação priorizada** | Após cada diagnóstico | “Qual única ação pode destravar mais valor agora?” |
| **Fechamento do ciclo** | Ao concluir uma etapa | “O cliente percebeu valor? O que vamos manter ou ajustar?” |

> **Princípio de Ítaca.** O acompanhamento não existe para preencher uma agenda. Ele existe para reduzir incerteza e tornar o próximo ganho mais provável.

## Roleplay — A primeira travessia

### Cenário

Uma pequena empresa acabou de confirmar a parceria. A decisora está satisfeita com a negociação, mas teme que a equipe não adote a nova rotina durante o horário de pico. O agente precisa encerrar a venda sem exagerar promessas, marcar os três encontros e deixar registrado o objetivo da primeira visita.

| Papel | Missão | Comportamento na simulação |
| --- | --- | --- |
| **Agente consultivo** | Conduzir o fechamento, perguntar sobre valor, propor cadência e resumir o acordo. | Use perguntas abertas, linguagem simples e confirmações. |
| **Cliente decisor** | Trazer preocupações reais de operação e escolher um ponto focal. | Faça uma objeção sobre tempo e uma pergunta sobre acompanhamento. |
| **Observador** | Avaliar clareza e qualidade do plano. | Use o roteiro de avaliação abaixo; não interrompa a primeira rodada. |

### Roteiro de 12 minutos

| Tempo | Etapa | Entrega |
| --- | --- | --- |
| 2 min | Preparação | Agente escreve hipótese de valor e próximo objetivo. |
| 5 min | Conversa de fechamento | Cliente confirma ou ajusta a jornada proposta. |
| 3 min | Registro | Agente simula uma tarefa no formato objetivo–contexto–ação–critério. |
| 2 min | Feedback | Observador oferece um elogio específico e uma melhoria acionável. |

### Rubrica de avaliação

| Critério | Pergunta de avaliação |
| --- | --- |
| Clareza de valor | O agente conectou a conversa a um objetivo do cliente? |
| Previsibilidade | As próximas etapas têm motivo e data? |
| Escuta | O agente confirmou a preocupação antes de responder? |
| Registro | A tarefa permitiria continuidade para outra pessoa da equipe? |
| Responsabilidade | O agente evitou garantias impróprias e definiu próximos passos de ambos? |

## Desafio de campo — 7 dias para estabilizar a rota

No próximo cliente elegível e nos canais autorizados, escolha uma etapa da jornada e aplique o ciclo abaixo. Faça uma reflexão de cinco linhas para si ou para a conversa de gestão, sem exportar dados sensíveis.

| Dia | Ação | Pergunta para reflexão |
| --- | --- | --- |
| 1 | Releia o contexto e defina a hipótese de valor. | “O que o cliente realmente quer melhorar?” |
| 2 | Confirme o próximo contato com objetivo claro. | “A pessoa sabe por que vamos conversar?” |
| 3 | Prepare três perguntas de diagnóstico. | “Que informação mudaria minha recomendação?” |
| 4 | Execute a conversa e registre a tarefa. | “Meu registro permite continuidade?” |
| 5 | Escolha uma pendência prioritária. | “O que mais reduz a fricção agora?” |
| 6 | Combine dono, prazo e sinal de avanço. | “Como saberemos que evoluiu?” |
| 7 | Faça uma revisão curta. | “O que vou manter, interromper ou testar?” |

## Leituras e referências

1. [Gainsight. *Customer Onboarding: Best Practices and Actionable Tips*.](https://www.gainsight.com/blog/customer-onboarding/)
2. [Dock. *SaaS Customer Onboarding Guide: Best Practices & Templates*.](https://www.dock.us/library/customer-onboarding)
3. [Bain & Company. *Net Promoter System®*.](https://www.bain.com/consulting-services/customer-strategy-and-marketing/net-promoter-score-system/)
4. Ross, Aaron; Tyler, Marylou. *Predictable Revenue* — leitura complementar sobre processos repetíveis de receita e prospecção.
5. Murphy, Lincoln; Mehta, Sixteen Ventures. *Customer Success* — leitura complementar sobre resultados desejados e evolução do cliente.
6. Kotler, Philip; Keller, Kevin Lane. *Marketing Management* — leitura complementar sobre valor, segmentação e gestão de relacionamento.

> **Fechamento.** A jornada para Ítaca não se mede pelo número de contatos feitos, mas pela qualidade da próxima decisão que o cliente consegue tomar com você. Quando o valor é claro, o plano é visível e o acompanhamento é disciplinado, cada encontro deixa de ser uma cobrança e se torna uma construção conjunta.
