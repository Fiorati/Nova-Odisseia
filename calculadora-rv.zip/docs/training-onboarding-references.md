# Referências de conteúdo — Onboarding de Clientes

## Fontes consultadas em 28/08/2026

| Fonte | Conclusões aproveitadas no treinamento |
| --- | --- |
| [Gainsight — Customer Onboarding: Best Practices and Actionable Tips](https://www.gainsight.com/blog/customer-onboarding/) | Onboarding deve acelerar o primeiro valor, criar confiança e orientar o cliente até a autonomia. A fonte organiza a jornada em boas-vindas e setup, educação do produto, orientação personalizada, vitória inicial e comunicação contínua. Também sugere monitorar tempo até o primeiro valor, conclusão e adoção. |
| [Bain & Company — Net Promoter System](https://www.bain.com/consulting-services/customer-strategy-and-marketing/net-promoter-score-system/) | O Net Promoter System é apresentado como uma abordagem para mensurar e gerir lealdade de clientes. No treinamento, a ideia é usada apenas como convite a ouvir o cliente, aprender com o feedback e fechar o ciclo de melhoria. |
| [Dock — SaaS Customer Onboarding Guide](https://www.dock.us/library/customer-onboarding) | Um handoff organizado entre venda e sucesso do cliente, critérios de sucesso claros, planos compartilhados, marcos e entrega progressiva de valor ajudam a reduzir ruído e manter a implementação compreensível. |

## Limites editoriais

As referências apoiam princípios gerais de onboarding. O treinamento não reproduz textos das fontes e não afirma processos internos, métricas, produtos, políticas ou sistemas proprietários da Stone. As rotinas operacionais específicas devem ser confirmadas com os materiais e a liderança interna responsáveis.
