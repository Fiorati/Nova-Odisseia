export function canManageOdysseyUpdates(
  role: "user" | "admin" | null | undefined
) {
  return role === "admin";
}

export function canReadOdysseyUpdate(status: "rascunho" | "publicado") {
  return status === "publicado";
}
