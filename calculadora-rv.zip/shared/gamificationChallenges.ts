export const X1_KPIS = ["salesTasks", "newProposals", "newClients", "newActives", "newTpv"] as const;
export type X1Kpi = typeof X1_KPIS[number];
export type X1Results = Record<X1Kpi, number>;
export type PromisePeriod = "dia" | "semana" | "mes";

export const X1_KPI_LABELS: Record<X1Kpi, string> = {
  salesTasks: "Tarefas de venda",
  newProposals: "Novas propostas",
  newClients: "Novos clientes",
  newActives: "Novos ativos",
  newTpv: "TPV novo",
};

export function emptyX1Results(): X1Results {
  return { salesTasks: 0, newProposals: 0, newClients: 0, newActives: 0, newTpv: 0 };
}

export function sanitizeX1Results(input: Partial<X1Results>): X1Results {
  const output = emptyX1Results();
  for (const key of X1_KPIS) output[key] = Math.max(0, Number(input[key]) || 0);
  return output;
}

export function calculateX1Winner(kpis: X1Kpi[], creator: X1Results, opponent: X1Results) {
  let creatorScore = 0;
  let opponentScore = 0;
  for (const kpi of kpis) {
    if (creator[kpi] > opponent[kpi]) creatorScore += 1;
    if (opponent[kpi] > creator[kpi]) opponentScore += 1;
  }
  return { creatorScore, opponentScore, winner: creatorScore === opponentScore ? "empate" as const : creatorScore > opponentScore ? "criador" as const : "oponente" as const };
}

export function promisePeriodKey(periodType: PromisePeriod, date = new Date()) {
  const local = new Date(date.getTime());
  const dateKey = local.toISOString().slice(0, 10);
  if (periodType === "dia") return dateKey;
  if (periodType === "mes") return dateKey.slice(0, 7);
  const day = local.getUTCDay() || 7;
  local.setUTCDate(local.getUTCDate() - day + 1);
  return local.toISOString().slice(0, 10);
}

export function validPromisePeriodKey(periodType: PromisePeriod, periodKey: string) {
  return periodType === "mes" ? /^\d{4}-\d{2}$/.test(periodKey) : /^\d{4}-\d{2}-\d{2}$/.test(periodKey);
}
