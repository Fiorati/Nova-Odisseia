export type PortfolioImportScope = "route" | "polo" | "district";
export type LeadershipRole = "none" | "polo" | "distrital";

export function assertPortfolioImportAccess(
  scope: PortfolioImportScope,
  leadershipRole: LeadershipRole,
  systemRole?: "user" | "admin"
) {
  if (systemRole === "admin" || scope === "route") return;
  if (scope === "district" && leadershipRole !== "distrital")
    throw new Error(
      "A importação distrital é exclusiva para líderes distritais."
    );
  // Agentes também podem colaborar com a atualização do próprio polo. O servidor
  // valida o polo do perfil e cada rota formal antes de persistir a importação.
  if (scope === "polo") return;
}
