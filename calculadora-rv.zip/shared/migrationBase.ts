import { findCnaeEntry, findMccEntry, MCC_CATALOG, type CommissionTier, type ProposalPricing } from "./mccCatalog";

export type PersonType = "PJ" | "MEI";
export type CommissionSource = "custom-percent" | "manual-value" | "person-default" | "matrix" | "ineligible";
export type PersonCommissionDefaults = Record<PersonType, number | null>;

type ResolveClientCommissionInput = {
  automaticBase: number;
  manualBase?: number | null;
  migratedTpv: number;
  customCommissionPercent?: number | null;
  defaultPersonCommissionPercent?: number | null;
  eligible: boolean;
};

export function tierForTpv(tpv: number): CommissionTier {
  if (tpv < 7000) return "0-7k";
  if (tpv < 15000) return "7-15k";
  if (tpv < 30000) return "15-30k";
  if (tpv < 50000) return "30-50k";
  if (tpv < 100000) return "50-100k";
  if (tpv < 200000) return "100-200k";
  return "200k+";
}

export function calculateAutomaticMigrationBase(input: { mcc?: string; cnae?: string; tpv: number; proposal: ProposalPricing }) {
  const byMcc = input.mcc ? findMccEntry(input.mcc) : undefined;
  const byCnae = input.cnae ? findCnaeEntry(input.cnae) : undefined;
  const entry = byMcc ?? byCnae;
  const segment = entry ? MCC_CATALOG.find(item => item.id === entry.segmentId) : undefined;
  const tier = tierForTpv(input.tpv);
  return { tier, segmentId: segment?.id ?? "", base: segment?.rates[tier]?.[input.proposal] ?? 0 };
}

export function resolveMigrationBase(automaticBase: number, manualBase: number | null | undefined, eligible: boolean) {
  if (!eligible) return 0;
  return typeof manualBase === "number" ? manualBase : automaticBase;
}

export function commissionFromPercent(tpv: number, percent: number) {
  return Math.max(tpv || 0, 0) * Math.max(percent || 0, 0) / 100;
}

export function getDefaultPersonCommissionPercent(personType: PersonType, defaults: PersonCommissionDefaults) {
  return defaults[personType];
}

/**
 * Prioridade auditável: percentual customizado do cliente, valor manual legado,
 * percentual padrão PJ/MEI e, por fim, matriz de segmento/tier/proposta.
 */
export function resolveClientCommissionBase(input: ResolveClientCommissionInput): { base: number; source: CommissionSource } {
  if (!input.eligible) return { base: 0, source: "ineligible" };
  if (typeof input.customCommissionPercent === "number") return { base: commissionFromPercent(input.migratedTpv, input.customCommissionPercent), source: "custom-percent" };
  if (typeof input.manualBase === "number") return { base: Math.max(input.manualBase, 0), source: "manual-value" };
  if (typeof input.defaultPersonCommissionPercent === "number") return { base: commissionFromPercent(input.migratedTpv, input.defaultPersonCommissionPercent), source: "person-default" };
  return { base: Math.max(input.automaticBase || 0, 0), source: "matrix" };
}
