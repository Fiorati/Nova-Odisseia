export type OdysseyUpdateCategory =
  | "Experiência"
  | "Carteiras e rotas"
  | "Conteúdo"
  | "Desempenho";

export type OdysseyUpdateBody = {
  intro: string;
  improvements: { title: string; description: string }[];
  bestPractices: string[];
  impact: string;
};

export type InitialOdysseyUpdate = {
  slug: string;
  title: string;
  summary: string;
  category: OdysseyUpdateCategory;
  readingMinutes: number;
  publishedAt: Date;
  content: OdysseyUpdateBody;
};

export const INITIAL_ODYSSEY_UPDATES: InitialOdysseyUpdate[] = [
  {
    slug: "biblioteca-itaca-imagens-mais-leves",
    title: "Biblioteca de Ítaca com imagens mais leves",
    summary:
      "As capas agora se adaptam ao dispositivo e carregam arquivos menores, preservando a experiência visual.",
    category: "Desempenho",
    readingMinutes: 3,
    publishedAt: new Date("2026-08-28T14:22:00.000Z"),
    content: {
      intro:
        "A Biblioteca de Ítaca recebeu uma melhoria de desempenho para abrir as trilhas com mais agilidade, especialmente em conexões móveis.",
      improvements: [
        {
          title: "Capas responsivas",
          description:
            "O aplicativo escolhe uma imagem adequada à largura da tela, evitando transferir um arquivo maior do que o necessário.",
        },
        {
          title: "Carregamento por prioridade",
          description:
            "A imagem que está visível recebe prioridade; capas de cartões fora da área visível aguardam o momento certo para carregar.",
        },
        {
          title: "Espaço reservado",
          description:
            "As dimensões são conhecidas antes do download, reduzindo mudanças inesperadas de layout durante a leitura.",
        },
      ],
      bestPractices: [
        "No celular, aguarde a trilha desejada entrar na área visível antes de abrir vários materiais em sequência.",
        "Use uma conexão estável quando o treinamento tiver links externos ou materiais complementares.",
        "Se uma imagem não atualizar, recarregue a página uma vez; a nova versão usa um endereço próprio e permanente.",
      ],
      impact:
        "A navegação continua com a mesma identidade visual, mas transfere menos dados e reduz o tempo percebido para exibir as capas.",
    },
  },
  {
    slug: "carteiras-deduplicacao-distribuicao-por-rota",
    title: "Carteiras organizadas por polo e rota formal",
    summary:
      "Importações complementares são consolidadas e cada agente recebe somente os clientes vinculados à sua rota.",
    category: "Carteiras e rotas",
    readingMinutes: 5,
    publishedAt: new Date("2026-08-28T14:12:00.000Z"),
    content: {
      intro:
        "A importação de carteiras foi aprimorada para transformar uma planilha do polo em visões individuais, sem misturar territórios ou repetir clientes equivalentes.",
      improvements: [
        {
          title: "Deduplicação complementar",
          description:
            "Registros da mesma rota podem ser reconhecidos por nome canônico, CNPJ ou telefone. Informações complementares são preservadas sem somar o mesmo TPV duas vezes.",
        },
        {
          title: "Distribuição por e-mail e rota",
          description:
            "Quando uma carteira do polo é enviada, cada linha é disponibilizada somente ao titular formal daquela rota, vinculado pelo e-mail cadastrado.",
        },
        {
          title: "Fronteira territorial",
          description:
            "Rotas de outro polo são bloqueadas. Linhas sem titularidade compatível ficam aguardando regularização, sem atribuição por aproximação.",
        },
      ],
      bestPractices: [
        "Antes do upload, confirme com a liderança se cada rota está vinculada ao e-mail corporativo correto.",
        "Mantenha uma coluna de rota consistente na planilha e evite abreviações diferentes para o mesmo território.",
        "Após importar, revise as rotas em espera e regularize a titularidade antes de repetir o envio.",
      ],
      impact:
        "Líderes e agentes autorizados do polo podem atualizar uma base comum, enquanto a leitura individual continua limitada às rotas formalmente atribuídas.",
    },
  },
  {
    slug: "contraste-e-legibilidade-em-todas-as-telas",
    title: "Mais contraste para leitura confortável",
    summary:
      "Textos, cartões e campos receberam combinações de cor mais legíveis em telas claras e escuras.",
    category: "Experiência",
    readingMinutes: 3,
    publishedAt: new Date("2026-08-28T14:10:00.000Z"),
    content: {
      intro:
        "A identidade verde da Nova Odisseia foi preservada, com correções para evitar textos escuros sobre superfícies escuras ou informações auxiliares com opacidade excessiva.",
      improvements: [
        {
          title: "Escopo visual seguro",
          description:
            "O tema escuro ficou restrito à navegação e aos heróis preparados para ele, sem invadir cartões editoriais.",
        },
        {
          title: "Textos auxiliares mais nítidos",
          description:
            "Rótulos, descrições, placeholders e mensagens de apoio receberam primeiro plano explícito conforme o fundo.",
        },
      ],
      bestPractices: [
        "Use o zoom padrão do navegador sempre que possível para preservar a hierarquia visual da tela.",
        "No celular, prefira o modo vertical para formulários longos e use a rolagem horizontal somente nas tabelas.",
        "Ao encontrar um caso de baixa leitura, envie uma captura com a seção e o dispositivo utilizado.",
      ],
      impact:
        "Informações operacionais permanecem mais fáceis de distinguir sem descaracterizar a paleta da plataforma.",
    },
  },
  {
    slug: "menu-lateral-para-celular",
    title: "Menu lateral disponível no celular",
    summary:
      "A navegação vertical ganhou um painel lateral com todas as áreas liberadas ao perfil.",
    category: "Experiência",
    readingMinutes: 2,
    publishedAt: new Date("2026-08-28T13:55:00.000Z"),
    content: {
      intro:
        "Em dispositivos móveis, o usuário pode alternar entre as áreas pelo botão de menu no topo ou pelo seletor suspenso já existente.",
      improvements: [
        {
          title: "Todas as áreas em um painel",
          description:
            "O menu abre pela esquerda, identifica a tela atual e respeita as permissões do perfil autenticado.",
        },
        {
          title: "Duas formas de navegar",
          description:
            "O seletor suspenso foi mantido como atalho, oferecendo uma alternativa direta para quem prefere poucos toques.",
        },
      ],
      bestPractices: [
        "Use o menu lateral quando quiser comparar as áreas disponíveis ao seu perfil.",
        "Use o seletor suspenso para trocar rapidamente entre duas telas conhecidas.",
        "Feche o menu tocando na área escolhida; o conteúdo correspondente será aberto automaticamente.",
      ],
      impact:
        "A navegação móvel passa a mostrar o conjunto completo de ferramentas sem depender de uma barra inferior parcial.",
    },
  },
  {
    slug: "biblioteca-de-itaca-primeira-trilha",
    title: "Biblioteca de Ítaca abre sua primeira trilha",
    summary:
      "O espaço de estudos foi inaugurado com Onboarding de Clientes e Gestão Estratégica da Base.",
    category: "Conteúdo",
    readingMinutes: 4,
    publishedAt: new Date("2026-08-28T13:45:00.000Z"),
    content: {
      intro:
        "A Biblioteca de Ítaca reúne materiais de estudo para transformar conhecimento em prática de campo, com publicação controlada pela administração.",
      improvements: [
        {
          title: "Trilha inaugural",
          description:
            "O primeiro treinamento organiza objetivos, módulos, scripts, checklists, roleplay e referências para aprofundamento.",
        },
        {
          title: "Leitura protegida",
          description:
            "Usuários autenticados leem conteúdos publicados. Rascunhos permanecem exclusivos da administração até a publicação explícita.",
        },
      ],
      bestPractices: [
        "Estude um módulo por vez e execute o exercício indicado antes de avançar.",
        "Adapte os scripts ao contexto da conversa, sem registrar dados de clientes fora dos sistemas autorizados.",
        "Confirme processos e políticas internas vigentes com a liderança antes de transformar o material em procedimento operacional.",
      ],
      impact:
        "A equipe passa a ter um ponto único para estudar, revisar referências e praticar rotinas de desenvolvimento comercial.",
    },
  },
];
