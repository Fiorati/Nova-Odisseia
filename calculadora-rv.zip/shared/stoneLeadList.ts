import { normalizeRouteKey, type RoutePortfolioRow } from "./routePortfolio";

const GOOGLE_EXPORT_BASE_HOST = "apidata.googleusercontent.com";
const GOOGLE_EXPORT_PATH =
  /^\/download\/storage\/v1\/b\/cartao-super-zap-1\/o\/tam-leads-report%2Ftam-leads---[a-z0-9._@+-]+---\d{4}-\d{2}-\d{2}-\d{4}\.html$/i;

export function isAuthorizedStoneGoogleHtmlUrl(url: URL) {
  const host = url.hostname.toLocaleLowerCase("pt-BR");
  const isGoogleExportHost = new RegExp(
    `^[a-f0-9]{32,96}-${GOOGLE_EXPORT_BASE_HOST.replaceAll(".", "\\.")}$`,
    "i"
  ).test(host);
  const signature = url.searchParams.get("jk") ?? "";
  const queryIsExpected = Array.from(url.searchParams.keys()).every(
    key => key === "jk" || key === "isca"
  );
  return (
    isGoogleExportHost &&
    GOOGLE_EXPORT_PATH.test(url.pathname) &&
    /^[a-z0-9_-]{32,10000}$/i.test(signature) &&
    url.searchParams.get("isca") === "1" &&
    queryIsExpected
  );
}

export function stoneLeadListSourceOrigin(url: URL) {
  return isAuthorizedStoneGoogleHtmlUrl(url)
    ? GOOGLE_EXPORT_BASE_HOST
    : url.hostname.toLocaleLowerCase("pt-BR");
}

export function parseAuthorizedStoneLeadListUrl(value: string) {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Informe um link válido da Lista Inteligente.");
  }
  const host = url.hostname.toLocaleLowerCase("pt-BR");
  const isStoneHost = host === "stone.com.br" || host.endsWith(".stone.com.br");
  if (
    url.protocol !== "https:" ||
    url.port ||
    url.username ||
    url.password ||
    url.hash
  )
    throw new Error(
      "Use um link HTTPS exportável Stone, sem porta, credenciais ou fragmento."
    );
  if (!isStoneHost && !isAuthorizedStoneGoogleHtmlUrl(url))
    throw new Error(
      "Use um link exportável Stone ou o relatório HTML temporário oficial da Lista Inteligente."
    );
  return url;
}

function identityPart(value: string | undefined) {
  return (value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR")
    .replace(/[^a-z0-9]/g, "");
}

function leadAliases(row: RoutePortfolioRow) {
  const route = normalizeRouteKey(row.route);
  const document = (row.document ?? "").replace(/\D/g, "");
  const phone = (row.phone ?? "").replace(/\D/g, "");
  const client = identityPart(row.clientName);
  const aliases = [`${route}|cliente:${client}`];
  if (document) aliases.push(`${route}|documento:${document}`);
  if (phone) aliases.push(`${route}|telefone:${phone}`);
  return aliases;
}

function mergeLeadRows(
  previous: RoutePortfolioRow,
  current: RoutePortfolioRow
) {
  const value = <T extends string | Date | null | undefined>(
    newer: T,
    older: T
  ) =>
    typeof newer === "string"
      ? newer.trim()
        ? newer
        : older
      : (newer ?? older);
  return {
    ...previous,
    ...current,
    route: value(current.route, previous.route) ?? "",
    agentName: value(current.agentName, previous.agentName),
    clientName: value(current.clientName, previous.clientName) ?? "",
    document: value(current.document, previous.document),
    mcc: value(current.mcc, previous.mcc),
    cnae: value(current.cnae, previous.cnae),
    segment: value(current.segment, previous.segment),
    projectedTpv:
      typeof current.projectedTpv === "number" && current.projectedTpv > 0
        ? current.projectedTpv
        : previous.projectedTpv,
    stage: value(current.stage, previous.stage),
    status: value(current.status, previous.status),
    phase: value(current.phase, previous.phase),
    temperature: value(current.temperature, previous.temperature),
    phone: value(current.phone, previous.phone),
    city: value(current.city, previous.city),
    lastInteraction: value(current.lastInteraction, previous.lastInteraction),
    nextAction: value(current.nextAction, previous.nextAction),
    nextContactAt: current.nextContactAt ?? previous.nextContactAt,
    notes: value(current.notes, previous.notes),
    rawJson: value(current.rawJson, previous.rawJson),
  } satisfies RoutePortfolioRow;
}

/** Remove duplicidades na importação e une linhas complementares sem somar TPV. */
export function deduplicateLeadListRows(rows: RoutePortfolioRow[]) {
  const byIdentity = new Map<string, RoutePortfolioRow>();
  const aliasToIdentity = new Map<string, string>();
  for (const row of rows) {
    const aliases = leadAliases(row);
    const matched = Array.from(
      new Set(aliases.map(alias => aliasToIdentity.get(alias)).filter(Boolean))
    ) as string[];
    const identity = matched[0] ?? aliases[0]!;
    const linkedRows = matched
      .map(key => byIdentity.get(key))
      .filter((item): item is RoutePortfolioRow => Boolean(item));
    const merged = [...linkedRows, row].reduce(mergeLeadRows);
    const matchedSet = new Set(matched);
    matched.forEach(key => byIdentity.delete(key));
    for (const [alias, mappedIdentity] of Array.from(
      aliasToIdentity.entries()
    )) {
      if (matchedSet.has(mappedIdentity)) aliasToIdentity.set(alias, identity);
    }
    byIdentity.set(identity, merged);
    leadAliases(merged).forEach(alias => aliasToIdentity.set(alias, identity));
  }
  const uniqueRows = Array.from(byIdentity.values());
  return { uniqueRows, duplicates: rows.length - uniqueRows.length };
}
