import * as XLSX from "xlsx";
import { getPortfolioLifecycle } from "./portfolioLifecycle";

export type ParsedPortfolioRow = {
  route: string;
  agentName?: string;
  clientName: string;
  document?: string;
  mcc?: string;
  cnae?: string;
  segment?: string;
  projectedTpv?: number;
  stage?: string;
  status?: string;
  phase?: string;
  temperature?: string;
  phone?: string;
  city?: string;
  lastInteraction?: string;
  nextAction?: string;
  notes?: string;
  rawJson?: string;
};

const headerKey = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").replace(/[^a-z0-9]/g, "");
const clientHeaderKeys = ["cliente", "nomecliente", "nomefantasia", "razaosocial", "nomedoestabelecimento", "nomedocomercio", "estabelecimento", "nome", "lojista", "merchant"];
const valueFrom = (row: Record<string, unknown>, candidates: string[]) => { const key = Object.keys(row).find((column) => candidates.includes(headerKey(column))); return key ? row[key] : undefined; };
const textFrom = (row: Record<string, unknown>, candidates: string[]) => { const value = valueFrom(row, candidates); return value === null || value === undefined ? "" : String(value).trim(); };
const numericFrom = (row: Record<string, unknown>, candidates: string[]) => { const value = valueFrom(row, candidates); if (typeof value === "number" && Number.isFinite(value)) return Math.max(value, 0); const parsed = Number(String(value ?? "").replace(/R\$\s?/gi, "").replace(/\./g, "").replace(",", ".").replace(/[^0-9.-]/g, "")); return Number.isFinite(parsed) ? Math.max(parsed, 0) : 0; };

export function toParsedPortfolioRows(records: Record<string, unknown>[], sourceSheet = ""): ParsedPortfolioRow[] {
  return records.map((row) => {
    const stage = textFrom(row, ["etapa", "status", "stage", "fase", "etapaatual", "etapapipeline", "etapadopipe", "pipe"]) || sourceSheet;
    const lifecycle = getPortfolioLifecycle(stage, sourceSheet);
    return {
    route: textFrom(row, ["rota", "nomedarota", "route", "codigorota"]),
    agentName: textFrom(row, ["agente", "agent", "responsavel", "responsavelrota", "donodarota"]),
    clientName: textFrom(row, clientHeaderKeys),
    document: textFrom(row, ["cnpj", "cpf", "documento"]), mcc: textFrom(row, ["mcc", "codigomcc"]), cnae: textFrom(row, ["cnae", "codigocnae"]), segment: textFrom(row, ["segmento", "atividade", "ramo"]),
    projectedTpv: numericFrom(row, ["tpv", "tpvprecificado", "tpvestimado", "tpvprojetado", "tpvpotencial", "tpvcomprometido", "tpvmensal", "faturamento", "volume", "valor", "valorpotencial"]), stage, status: lifecycle.status, phase: lifecycle.phase,
    temperature: textFrom(row, ["temperatura", "temperature", "prioridade"]), phone: textFrom(row, ["telefone", "telefoneprincipal", "celular", "telefonecelular", "fone", "whatsapp", "contato"]), city: textFrom(row, ["cidade", "municipio", "localidade", "cidadeuf"]), lastInteraction: textFrom(row, ["ultimainteracao", "ultimocontato", "dataultimaatividade", "dataultimainteracao", "dataultimocontato", "datamovimentacao", "datadamovimentacao"]), nextAction: textFrom(row, ["proximaacao", "proximainteracao", "acao", "nextaction", "proximopasso"]), notes: textFrom(row, ["observacao", "observacoes", "notas", "nota", "comentario", "comentarios", "obs", "origemlead", "subcanal"]), rawJson: JSON.stringify(row),
  }; }).filter((row) => row.clientName);
}

function normalizedSheetName(sheetName: string) { return headerKey(sheetName); }

function hasClientHeader(row: unknown[]) {
  return row.some(value => clientHeaderKeys.includes(headerKey(String(value ?? ""))));
}

function hasOperationalHeader(row: unknown[]) {
  return row.some(value => ["mcc", "segmento", "tpvprecificado", "agente", "status", "etapa", "rota"].includes(headerKey(String(value ?? ""))));
}

function readSheetRecords(sheet: XLSX.WorkSheet) {
  const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: "", raw: false, blankrows: false });
  const headerIndex = rows.findIndex(row => hasClientHeader(row) && hasOperationalHeader(row));
  if (headerIndex < 0) return [];
  const headers = rows[headerIndex]!.map((header, index) => String(header || `coluna_${index + 1}`).trim());
  return rows.slice(headerIndex + 1)
    .filter(row => row.some(value => String(value ?? "").trim()))
    .map(row => Object.fromEntries(headers.map((header, index) => [header, row[index] ?? ""])));
}

function isPreferredOperationalSheet(sheetName: string, portfolioType?: "base" | "route") {
  const name = normalizedSheetName(sheetName);
  if (portfolioType === "base") return name.includes("novosclientes") || name.includes("novosativos");
  if (portfolioType === "route") return name.includes("planejad") || name.includes("qualific") || name.includes("propost") || name.includes("negoci") || name.includes("perdid") || name.includes("novosclientes") || name.includes("novosativos");
  return true;
}

/**
 * Lê arquivos com múltiplas abas e seleciona uma aba de negócio em vez de assumir
 * que a primeira aba (frequentemente uma lista de tarefas) contém clientes.
 */
export function parsePortfolioSpreadsheetBuffer(buffer: ArrayBuffer | Uint8Array, options?: { portfolioType?: "base" | "route" }) {
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true, codepage: 65001 });
  const candidates = workbook.SheetNames.map((sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    const parsed = sheet ? toParsedPortfolioRows(readSheetRecords(sheet), sheetName) : [];
    return { sheetName, parsed };
  }).filter(candidate => candidate.parsed.length > 0);
  const operationalCandidates = candidates.filter(candidate => isPreferredOperationalSheet(candidate.sheetName, options?.portfolioType));
  const selected = operationalCandidates.length ? operationalCandidates : candidates;
  const rows = selected.flatMap(candidate => candidate.parsed);
  if (!rows.length) throw new Error("Não localizamos valores na coluna Nome/Cliente nas abas Novos Planejados, Qualificações, Propostas, Novos Clientes ou Novos Ativos. Confirme se o arquivo foi exportado completo.");
  return rows;
}

export function parsePortfolioPdfTableLines(lines: string[]) {
  const headerIndex = lines.findIndex((line) => /cliente|razao social|estabelecimento/i.test(line) && /rota|route/i.test(line));
  if (headerIndex < 0) throw new Error("Não localizamos uma tabela com as colunas Cliente e Rota no PDF. Para PDF, use um arquivo com texto selecionável e cabeçalhos de tabela.");
  const headers = lines[headerIndex]!.split(/\s{2,}|\t+|;/).map((item) => item.trim()).filter(Boolean);
  const clientIndex = headers.findIndex((item) => /cliente|razao social|estabelecimento/i.test(item));
  const routeIndex = headers.findIndex((item) => /rota|route/i.test(item));
  if (clientIndex < 0 || routeIndex < 0) throw new Error("O PDF precisa trazer as colunas Cliente e Rota.");
  const records = lines.slice(headerIndex + 1).map((line) => line.split(/\s{2,}|\t+|;/).map((item) => item.trim())).filter((cells) => cells.length >= Math.max(clientIndex, routeIndex) + 1).map((cells) => Object.fromEntries(headers.map((header, index) => [header, cells[index] ?? ""])));
  return toParsedPortfolioRows(records);
}

const HTML_ENTITIES: Record<string, string> = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };

function decodeHtmlText(value: string) {
  return value
    .replace(/<br\s*\/?\s*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCodePoint(Number.parseInt(code, 10)))
    .replace(/&([a-z]+);/gi, (entity, name: string) => HTML_ENTITIES[name.toLocaleLowerCase("pt-BR")] ?? entity)
    .replace(/\s+/g, " ")
    .trim();
}

/** Extrai somente uma tabela estática; scripts, estilos e templates são descartados e nunca executados. */
export function parsePortfolioHtmlTable(html: string) {
  const sanitized = html.replace(/<(script|style|template)\b[\s\S]*?<\/\1>/gi, "");
  const tables = Array.from(sanitized.matchAll(/<table\b[^>]*>([\s\S]*?)<\/table>/gi), match => match[1] ?? "");
  for (const table of tables) {
    const rows = Array.from(table.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi), match =>
      Array.from((match[1] ?? "").matchAll(/<(?:th|td)\b[^>]*>([\s\S]*?)<\/(?:th|td)>/gi), cell => decodeHtmlText(cell[1] ?? "")),
    ).filter(cells => cells.length > 0);
    const headerIndex = rows.findIndex(cells => cells.some(cell => /cliente|\bnome\b|raz[aã]o social|estabelecimento|lojista|merchant/i.test(cell)));
    if (headerIndex < 0) continue;
    const headers = rows[headerIndex]!;
    const records = rows.slice(headerIndex + 1)
      .filter(cells => cells.some(Boolean))
      .map(cells => Object.fromEntries(headers.map((header, index) => [header || `coluna_${index + 1}`, cells[index] ?? ""])));
    const parsed = toParsedPortfolioRows(records);
    if (parsed.length) return parsed;
  }
  throw new Error("O relatório HTML não contém uma tabela reconhecível com a coluna Nome ou Cliente.");
}
