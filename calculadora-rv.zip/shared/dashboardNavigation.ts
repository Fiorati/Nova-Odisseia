export type DashboardView =
  | "painel"
  | "calculadora"
  | "periodo"
  | "nordica"
  | "psv"
  | "psv-ritual"
  | "rmr"
  | "ranking"
  | "perfil"
  | "lideranca"
  | "card-final"
  | "carteiras"
  | "lista-inteligente"
  | "super-pipe"
  | "prospeccao"
  | "campanhas"
  | "spartacus"
  | "como-utilizar"
  | "biblioteca"
  | "atualizacoes"
  | "x1"
  | "promessas"
  | "contagem-ativos";

export type DashboardNavigationItem = { key: DashboardView; label: string };

const AGENT_NAVIGATION: readonly DashboardNavigationItem[] = [
  { key: "painel", label: "Meu painel" },
  { key: "promessas", label: "Roteiro e Objetivo" },
  { key: "x1", label: "Arena X1" },
  { key: "periodo", label: "Período" },
  { key: "nordica", label: "Estratégia Nórdica" },
  { key: "prospeccao", label: "Cavalo de Tróia" },
  { key: "calculadora", label: "Calculadora RV" },
  { key: "psv", label: "PSV semanal" },
  { key: "psv-ritual", label: "Ritual PSV" },
  { key: "spartacus", label: "SPARTACUS" },
  { key: "biblioteca", label: "Biblioteca de Ítaca" },
  { key: "atualizacoes", label: "Atualizações da Odisseia" },
  { key: "carteiras", label: "Carteiras" },
  { key: "lista-inteligente", label: "Lista Inteligente" },
  { key: "rmr", label: "RMR" },
  { key: "card-final", label: "Card final" },
  { key: "ranking", label: "Troféus" },
  { key: "como-utilizar", label: "Como utilizar?" },
  { key: "perfil", label: "Meu perfil" },
];

const LEADER_NAVIGATION: readonly DashboardNavigationItem[] = [
  { key: "painel", label: "Gestão do time" },
  { key: "promessas", label: "Roteiro e Objetivo" },
  { key: "contagem-ativos", label: "Contagem de Ativos" },
  { key: "x1", label: "Arena X1" },
  { key: "super-pipe", label: "Super Pipe" },
  { key: "campanhas", label: "Campanhas" },
  { key: "spartacus", label: "SPARTACUS" },
  { key: "biblioteca", label: "Biblioteca de Ítaca" },
  { key: "atualizacoes", label: "Atualizações da Odisseia" },
  { key: "carteiras", label: "Carteiras" },
  { key: "lista-inteligente", label: "Lista Inteligente" },
  { key: "ranking", label: "Troféus" },
  { key: "como-utilizar", label: "Como utilizar?" },
  { key: "perfil", label: "Meu perfil" },
];

export function getDashboardNavigation(
  isLeader: boolean
): readonly DashboardNavigationItem[] {
  return isLeader ? LEADER_NAVIGATION : AGENT_NAVIGATION;
}

export function isDashboardView(value: string | null): value is DashboardView {
  return (
    getDashboardNavigation(false).some(item => item.key === value) ||
    getDashboardNavigation(true).some(item => item.key === value) ||
    value === "lideranca"
  );
}
