export type TrainingPublicationStatus = "rascunho" | "publicado";

/** A Biblioteca é legível por usuários autenticados; só a administração global gerencia o acervo. */
export function canManageTraining(role: "user" | "admin" | null | undefined) {
  return role === "admin";
}

export function canReadTraining(status: TrainingPublicationStatus) {
  return status === "publicado";
}
