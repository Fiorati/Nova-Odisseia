import {
  normalizeSalesPipeValue,
  type SuperPipeStage,
  getSuperPipeStage,
} from "./salesPipeline";

export type PortfolioLifecycle = {
  status: string;
  phase: "Qualificação" | "Proposta" | "Fechamento";
  superStage: SuperPipeStage;
};

const lifecycleByStage: Record<SuperPipeStage, PortfolioLifecycle> = {
  planned: {
    status: "Planejado",
    phase: "Qualificação",
    superStage: "planned",
  },
  qualification: {
    status: "Em qualificação",
    phase: "Qualificação",
    superStage: "qualification",
  },
  negotiation: {
    status: "Em negociação",
    phase: "Proposta",
    superStage: "negotiation",
  },
  lost: { status: "Perdido", phase: "Fechamento", superStage: "lost" },
  customer: { status: "Cliente", phase: "Fechamento", superStage: "customer" },
  active: { status: "Ativo", phase: "Fechamento", superStage: "active" },
};

/** Converte a etapa livre da fonte em Status e Fase consistentes no produto. */
export function getPortfolioLifecycle(
  stage: string | null | undefined,
  sourceSheet?: string | null
): PortfolioLifecycle {
  const source = `${stage ?? ""} ${sourceSheet ?? ""}`;
  const normalized = normalizeSalesPipeValue(source);
  if (normalized.includes("mapead"))
    return { status: "Mapeado", phase: "Qualificação", superStage: "planned" };
  return lifecycleByStage[getSuperPipeStage(source)];
}

export type PortfolioMergeable = {
  id: number;
  importId: number;
  routeKey?: string;
  referenceMonth?: string | null;
  route: string;
  clientName: string;
  document: string;
  phone: string;
  projectedTpv: number;
  stage: string;
  status: string;
  phase: string;
  temperature: string;
  mcc: string;
  cnae: string;
  segment: string;
  city: string;
  lastInteraction: string;
  nextAction: string;
  nextContactAt: Date | null;
  notes: string | null;
  importedAt: Date;
  fileName: string;
};

const keyPart = (value: string | null | undefined) =>
  normalizeSalesPipeValue(value).replace(/[^a-z0-9]/g, "");
const text = (value: string | null | undefined) => (value ?? "").trim();

function aliases(entry: PortfolioMergeable) {
  const route = keyPart(entry.route);
  const client = keyPart(entry.clientName);
  const values = [`${route}:cliente:${client}`];
  const document = keyPart(entry.document);
  const phone = keyPart(entry.phone);
  if (document) values.push(`${route}:documento:${document}`);
  if (phone) values.push(`${route}:telefone:${phone}`);
  return values;
}

function combine(
  previous: PortfolioMergeable,
  current: PortfolioMergeable
): PortfolioMergeable {
  const value = <T extends string | Date | null>(newer: T, older: T) => {
    if (newer instanceof Date) return newer;
    return text(newer) ? newer : older;
  };
  return {
    ...previous,
    ...current,
    route: value(current.route, previous.route),
    clientName: value(current.clientName, previous.clientName),
    document: value(current.document, previous.document),
    phone: value(current.phone, previous.phone),
    mcc: value(current.mcc, previous.mcc),
    cnae: value(current.cnae, previous.cnae),
    segment: value(current.segment, previous.segment),
    projectedTpv:
      current.projectedTpv > 0 ? current.projectedTpv : previous.projectedTpv,
    stage: value(current.stage, previous.stage),
    status: value(current.status, previous.status),
    phase: value(current.phase, previous.phase),
    temperature: value(current.temperature, previous.temperature),
    city: value(current.city, previous.city),
    lastInteraction: value(current.lastInteraction, previous.lastInteraction),
    nextAction: value(current.nextAction, previous.nextAction),
    nextContactAt: current.nextContactAt ?? previous.nextContactAt,
    notes: current.notes ?? previous.notes,
  };
}

/** Junta planilhas da mesma competência sem perder o primeiro campo preenchido nem somar TPV em duplicidade. */
export function mergePortfolioEntries(entries: PortfolioMergeable[]) {
  const byIdentity = new Map<
    string,
    PortfolioMergeable & {
      sourceFileNames: string[];
      sourceImportCount: number;
    }
  >();
  const keyToIdentity = new Map<string, string>();
  const ordered = [...entries].sort(
    (left, right) =>
      left.importedAt.getTime() - right.importedAt.getTime() ||
      left.importId - right.importId
  );
  for (const entry of ordered) {
    const entryAliases = aliases(entry);
    const matched = Array.from(
      new Set(
        entryAliases.map(alias => keyToIdentity.get(alias)).filter(Boolean)
      )
    ) as string[];
    const identity = matched[0] ?? entryAliases[0]!;
    const linked = matched
      .map(key => byIdentity.get(key))
      .filter(
        (
          item
        ): item is PortfolioMergeable & {
          sourceFileNames: string[];
          sourceImportCount: number;
        } => Boolean(item)
      )
      .sort(
        (left, right) =>
          left.importedAt.getTime() - right.importedAt.getTime() ||
          left.importId - right.importId
      );
    const existing = linked.length
      ? linked
          .slice(1)
          .reduce<PortfolioMergeable>(
            (previous, current) => combine(previous, current),
            linked[0]!
          )
      : undefined;
    const next = existing ? combine(existing, entry) : entry;
    const sourceFileNames = Array.from(
      new Set([...linked.flatMap(item => item.sourceFileNames), entry.fileName])
    );
    const sourceImportCount = Math.max(
      linked.reduce((sum, item) => sum + item.sourceImportCount, 0),
      sourceFileNames.length
    );
    const matchedSet = new Set(matched);
    matched.forEach(key => byIdentity.delete(key));
    for (const [alias, mappedIdentity] of Array.from(keyToIdentity.entries())) {
      if (matchedSet.has(mappedIdentity)) keyToIdentity.set(alias, identity);
    }
    byIdentity.set(identity, { ...next, sourceFileNames, sourceImportCount });
    aliases(next).forEach(alias => keyToIdentity.set(alias, identity));
  }
  return Array.from(byIdentity.values());
}
