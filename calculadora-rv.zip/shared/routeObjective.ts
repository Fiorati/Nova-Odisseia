export type DailyRouteDraft = {
  clientName: string;
  clientCode: string;
  taskType: string;
  address: string;
  scheduledTime: string;
  appointmentStatus: string;
  situation: string;
  notes?: string | null;
  confidence?: number;
};
export type DailyPriorityDraft = {
  position: number;
  objective: string;
  clientName: string;
  expectedResult: string;
  ownerName: string;
  how: string;
  whenLabel: string;
  completed: boolean;
};
export const normalizeRouteText = (value: unknown, max = 240) =>
  String(value ?? "")
    .normalize("NFKC")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
export const normalizeRouteDay = (value: string) =>
  /^\d{4}-\d{2}-\d{2}$/.test(value)
    ? value
    : new Date().toISOString().slice(0, 10);
export function dailyRouteDedupeKey(
  item: Pick<DailyRouteDraft, "clientName" | "clientCode" | "scheduledTime">
) {
  return [item.clientCode || item.clientName, item.scheduledTime]
    .map(v =>
      normalizeRouteText(v)
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "")
    )
    .join("|")
    .slice(0, 255);
}
export function normalizeDailyRouteDraft(
  item: DailyRouteDraft
): DailyRouteDraft {
  return {
    clientName: normalizeRouteText(item.clientName, 180),
    clientCode: normalizeRouteText(item.clientCode, 64),
    taskType: normalizeRouteText(item.taskType, 24),
    address: normalizeRouteText(item.address, 500),
    scheduledTime: /^\d{2}:\d{2}$/.test(item.scheduledTime)
      ? item.scheduledTime
      : "",
    appointmentStatus: normalizeRouteText(item.appointmentStatus, 80),
    situation: normalizeRouteText(item.situation, 120),
    notes: normalizeRouteText(item.notes, 1000) || null,
    confidence: Number.isFinite(item.confidence)
      ? Math.max(0, Math.min(1, Number(item.confidence)))
      : undefined,
  };
}
export function routeEffectivenessSuggestions(items: DailyRouteDraft[]) {
  const tips: string[] = [];
  if (items.some(i => !i.scheduledTime))
    tips.push("Defina horário para os compromissos sem janela de visita.");
  if (items.some(i => !i.address))
    tips.push("Complete os endereços antes de sair para reduzir improvisos.");
  if (
    items.filter(i => /não agendada/i.test(i.appointmentStatus)).length >
    Math.max(1, items.length / 2)
  )
    tips.push(
      "Confirme as visitas prioritárias por telefone antes do deslocamento."
    );
  if (items.length > 8)
    tips.push(
      "Agrupe clientes por microrrota e proteja tempo para os cinco objetivos do dia."
    );
  return tips.length
    ? tips
    : [
        "Roteiro com horários e informações suficientes; confirme deslocamentos e resultados esperados.",
      ];
}

export function dedupeDailyRoutes(items: DailyRouteDraft[]) {
  const map = new Map<string, DailyRouteDraft>();
  for (const item of items.map(normalizeDailyRouteDraft)) {
    const key = dailyRouteDedupeKey(item);
    const previous = map.get(key);
    if (!previous) map.set(key, item);
    else
      map.set(key, {
        ...previous,
        ...Object.fromEntries(
          Object.entries(item).filter(
            ([, value]) => value !== "" && value != null
          )
        ),
      });
  }
  return Array.from(map.values());
}

export const routeSuggestions = routeEffectivenessSuggestions;
