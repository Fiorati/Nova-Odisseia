export type TrainingReference = {
  title: string;
  url: string;
  note: string;
};

export type TrainingTable = {
  title?: string;
  columns: string[];
  rows: string[][];
};

export type TrainingSection = {
  id: string;
  eyebrow: string;
  title: string;
  overview: string;
  paragraphs: string[];
  objectives?: string[];
  tables?: TrainingTable[];
  script?: { label: string; text: string };
  checklist?: string[];
  practice?: { title: string; prompt: string; steps: string[] };
};

export type TrainingBody = {
  intro: string;
  operationalNote: string;
  outcomes: { label: string; evidence: string }[];
  sections: TrainingSection[];
  closing: string;
};

export const INITIAL_TRAINING_SLUG =
  "onboarding-clientes-gestao-estrategica-base";
export const INITIAL_TRAINING_COVER =
  "/manus-storage/biblioteca-itaca-onboarding-cover-1280_5fad1ad1.webp";
export const INITIAL_TRAINING_COVER_SMALL =
  "/manus-storage/biblioteca-itaca-onboarding-cover-640_c005fd47.webp";
export const INITIAL_TRAINING_COVER_SRC_SET = `${INITIAL_TRAINING_COVER_SMALL} 640w, ${INITIAL_TRAINING_COVER} 1280w`;

export const INITIAL_TRAINING_CONTENT: TrainingBody = {
  intro:
    "O fechamento é o porto de partida, não o fim da navegação. Nesta trilha, você aprenderá a transformar uma negociação em uma jornada consultiva: alinhar valor, combinar uma agenda previsível, registrar compromissos e revisar o que efetivamente aproxima o cliente do resultado desejado.",
  operationalNote:
    "As menções a CRM, tarefas, réguas, matriz de ativação ou produtos refletem a rotina descrita no material-base deste curso. Antes de executar qualquer procedimento, condição comercial, ativação, retirada de concorrência ou comunicação com cliente, confirme a versão vigente dos materiais internos e a orientação da sua liderança. Não registre nem mova dados de clientes fora dos sistemas e canais autorizados.",
  outcomes: [
    {
      label: "Posicionar valor",
      evidence:
        "Um resumo de objetivo do cliente e compromissos mútuos, validado ao final do fechamento.",
    },
    {
      label: "Criar previsibilidade",
      evidence:
        "Três marcos de acompanhamento combinados com objetivo, responsável e próximo passo.",
    },
    {
      label: "Registrar continuidade",
      evidence:
        "Uma tarefa no CRM com contexto, ação, critério de sucesso e prazo.",
    },
    {
      label: "Ajustar com método",
      evidence:
        "Um plano de ação pequeno, com dono, hipótese e sinal observável de evolução.",
    },
  ],
  sections: [
    {
      id: "valor-no-fechamento",
      eyebrow: "Módulo 1 · A promessa de navegação",
      title:
        "O discurso no fechamento: vender continuidade, não apenas uma solução",
      overview:
        "A confiança construída na venda precisa se transformar em clareza de jornada. O papel consultivo começa quando você traduz o que ouviu em uma hipótese de valor verificável, sem prometer resultados que não controla.",
      paragraphs: [
        "Uma conversa madura evita generalidades. Em vez de encerrar com “qualquer coisa, estou à disposição”, indique o que será acompanhado, quem participa e em que momento a evolução será revisada. O cliente deve perceber que a parceria tem começo, marcos e espaço para ajuste.",
        "A pergunta central é simples: qual resultado de negócio o cliente espera perceber? A resposta orienta a primeira visita, ajuda a identificar o ponto focal e impede que a implantação se reduza a uma lista administrativa desconectada da operação real.",
      ],
      objectives: [
        "Reafirmar o contexto escutado na negociação.",
        "Definir uma hipótese de valor em linguagem simples.",
        "Apresentar a sequência de acompanhamento e confirmar responsabilidades.",
      ],
      tables: [
        {
          title: "Estrutura em quatro movimentos",
          columns: ["Movimento", "Intenção", "Pergunta ou linguagem possível"],
          rows: [
            [
              "Reafirmar o contexto",
              "Demonstrar escuta e reduzir ambiguidade.",
              "“Você comentou que o horário de pico concentra grande parte da operação. É nesse ponto que vamos observar primeiro.”",
            ],
            [
              "Definir hipótese de valor",
              "Conectar a parceria a uma necessidade, sem garantia imprópria.",
              "“Nossa hipótese é que, com a operação pronta e o time orientado, haverá mais fluidez nessa etapa.”",
            ],
            [
              "Apresentar a jornada",
              "Dar previsibilidade.",
              "“Proponho voltarmos em duas datas para conferir uso, ajustar pendências e escolher o próximo ganho.”",
            ],
            [
              "Confirmar compromisso mútuo",
              "Tornar responsabilidades visíveis.",
              "“Eu conduzo e registro os próximos passos; quem será o ponto focal para validar as ações?”",
            ],
          ],
        },
      ],
      script: {
        label: "Script adaptável de fechamento consultivo",
        text: "Antes de concluirmos, quero alinhar como vamos trabalhar depois de hoje. Meu papel é acompanhar a implantação e ajudar você a transformar o acordo em rotina. Vamos definir três momentos: o início, uma checagem de consolidação e uma conversa de plano de ação. Em cada encontro, vamos sair com uma decisão e um próximo passo. Para você, qual resultado faria esta parceria valer a pena nos próximos meses?",
      },
      practice: {
        title: "Prática de campo",
        prompt:
          "Reescreva o script acima para um contexto real, sem incluir dados pessoais, números confidenciais ou informações fora dos sistemas autorizados.",
        steps: [
          "Escreva uma hipótese de valor em uma frase.",
          "Inclua uma pergunta aberta sobre o resultado esperado.",
          "Revise e retire qualquer promessa que não dependa apenas de você.",
        ],
      },
    },
    {
      id: "agenda-contratada",
      eyebrow: "Módulo 2 · Marcar os portos antes da partida",
      title: "Previsibilidade e trava de agenda",
      overview:
        "Agenda contratada não é uma sequência vaga de visitas. É um pacto de ritmo: o cliente sabe quando será procurado, por qual motivo e o que precisa trazer para a conversa.",
      paragraphs: [
        "Ao combinar a cadência ainda no fechamento, você reduz a inércia que costuma aparecer depois da assinatura. O compromisso ganha forma quando cada encontro tem uma finalidade distinta e uma saída observável.",
        "Se uma data mudar, não trate a remarcação como detalhe. Registre a alteração, reconfirme a intenção do encontro e deixe a nova decisão visível nos canais aprovados. Previsibilidade é uma entrega ao cliente e à equipe que dará continuidade ao acompanhamento.",
      ],
      tables: [
        {
          title: "Cadência de três encontros",
          columns: ["Marco", "Objetivo", "Evidência ao encerrar"],
          rows: [
            [
              "Visita 1 · Ativação",
              "Alinhar início, responsáveis e pendências.",
              "Checklist de início, responsáveis e data de retorno.",
            ],
            [
              "Visita 2 · Consolidação",
              "Ouvir atritos e conferir como a operação está se adaptando.",
              "O que avançou, o que bloqueou e uma ação prioritária.",
            ],
            [
              "Visita 3 · Plano estratégico",
              "Testar a hipótese de valor e escolher um experimento viável.",
              "Ação, dono, prazo e sinal de evolução.",
            ],
          ],
        },
      ],
      script: {
        label: "Roteiro de convite e confirmação",
        text: "Para que a implantação não fique solta, sugiro já reservarmos três momentos curtos. No primeiro, alinhamos o início e as pendências; no segundo, verificamos como a operação se adaptou; no terceiro, analisamos o que vale ajustar para aproximar o resultado que você quer. Posso te sugerir estas datas?",
      },
      checklist: [
        "Data e horário confirmados.",
        "Participante principal e ponto focal identificados.",
        "Objetivo do próximo encontro escrito em uma frase.",
        "Ação esperada de cada lado até a próxima conversa.",
        "Registro feito exclusivamente no sistema ou canal autorizado.",
      ],
    },
    {
      id: "crm-continuidadade",
      eyebrow: "Módulo 3 · O mapa que outra pessoa consegue ler",
      title: "Execução operacional no CRM",
      overview:
        "Um registro de qualidade conecta intenção e execução. Ele ajuda você a recuperar contexto, permite apoio da liderança quando necessário e evita que o cliente precise repetir a própria história.",
      paragraphs: [
        "Após cada visita alinhada, transforme a conversa em uma tarefa objetiva. O valor do registro não é volume de texto: é permitir que qualquer pessoa autorizada entenda o propósito, a pendência e a próxima decisão sem interpretar a memória de uma reunião.",
        "Ao usar o CRM mencionado no material-base, respeite sempre os campos e os procedimentos vigentes da sua operação. O padrão abaixo é uma estrutura de raciocínio que pode ser aplicada aos campos autorizados, e não uma instrução para copiar dados a outras ferramentas.",
      ],
      tables: [
        {
          title: "Estrutura de uma tarefa útil",
          columns: ["Campo", "Como preencher", "Exemplo seguro"],
          rows: [
            [
              "Objetivo",
              "Comece com um verbo e um resultado observável.",
              "Validar pendências do início e confirmar o ponto focal.",
            ],
            [
              "Contexto",
              "Registre o acordo de forma concisa.",
              "O cliente prioriza reduzir dúvidas do time no horário de maior movimento.",
            ],
            [
              "Ação",
              "Descreva o que será feito no encontro.",
              "Revisar checklist, ouvir operadores e listar bloqueios.",
            ],
            [
              "Critério de sucesso",
              "Diga como saberemos que a conversa avançou.",
              "Pendências classificadas, responsável definido e próximo contato confirmado.",
            ],
            [
              "Prazo",
              "Use a data combinada, sem inventar expectativa.",
              "Data da próxima visita ou contato.",
            ],
          ],
        },
      ],
      practice: {
        title: "Registro de continuidade",
        prompt:
          "Converta uma conversa fictícia em uma tarefa legível por outra pessoa da equipe.",
        steps: [
          "Escreva o objetivo em uma frase.",
          "Diferencie fato observado de hipótese.",
          "Defina uma única pendência prioritária.",
          "Indique responsável, prazo e critério de sucesso.",
        ],
      },
    },
    {
      id: "plano-estrategico",
      eyebrow: "Módulo 4 · Ajustar velas com evidência",
      title: "Validação do plano de ação e gestão estratégica da base",
      overview:
        "O plano estratégico precisa ser pequeno o suficiente para acontecer e claro o suficiente para ser avaliado. Em vez de promessas amplas, escolha um experimento que responda a uma pergunta de negócio.",
      paragraphs: [
        "A revisão madura começa pela observação: o que o cliente esperava, o que ocorreu e onde apareceu fricção? Depois, selecione a menor ação capaz de produzir aprendizado. Dessa forma, cada encontro transforma-se em avanço ou em informação útil para recalibrar a rota.",
        "Princípios de onboarding e Customer Success enfatizam primeira vitória, aprendizado progressivo, comunicação consistente e acompanhamento da adoção. A aplicação local deve respeitar a realidade do cliente e os indicadores que sua operação está autorizada a usar. [1] [2]",
      ],
      tables: [
        {
          title: "Canvas de plano de ação",
          columns: ["Elemento", "Pergunta de qualidade"],
          rows: [
            [
              "Resultado desejado",
              "Que mudança o cliente quer perceber na operação ou no negócio?",
            ],
            ["Hipótese", "O que acreditamos que pode ajudar e por quê?"],
            [
              "Ação simples",
              "Qual é o menor passo que pode ser executado nesta semana?",
            ],
            ["Dono", "Quem faz e quem acompanha?"],
            ["Prazo", "Quando revisaremos?"],
            [
              "Sinal de evolução",
              "Que evidência indica avanço ou necessidade de ajuste?",
            ],
          ],
        },
        {
          title: "Cinco rotinas de gestão estratégica da base",
          columns: ["Rotina", "Pergunta operacional"],
          rows: [
            [
              "Handoff de contexto",
              "O que foi acordado, quem decide e que resultado importa?",
            ],
            [
              "Mapa de marcos",
              "Qual é o próximo passo visível para o cliente?",
            ],
            [
              "Leitura de sinais",
              "Há evidência de avanço, dúvida ou bloqueio?",
            ],
            [
              "Ação priorizada",
              "Qual única ação pode destravar mais valor agora?",
            ],
            [
              "Fechamento de ciclo",
              "O cliente percebeu valor? O que manter ou ajustar?",
            ],
          ],
        },
      ],
      checklist: [
        "Pergunte o que o cliente esperava desde o último encontro.",
        "Descreva o que ocorreu antes de justificar o resultado.",
        "Classifique a fricção: entendimento, processo, acesso, treinamento ou prioridade.",
        "Combine a próxima ação com dono e prazo.",
        "Defina a pergunta que continua em aberto.",
      ],
    },
    {
      id: "roleplay",
      eyebrow: "Oficina de Ítaca · Simulação em dupla",
      title: "Roleplay: a primeira travessia",
      overview:
        "Praticar uma conversa antes do campo reduz improviso e torna mais fácil receber feedback específico. A atividade simula a passagem do aceite para a primeira jornada de acompanhamento.",
      paragraphs: [
        "Cenário: uma pequena empresa acaba de confirmar uma parceria. A decisora está satisfeita com a negociação, mas teme que a equipe não adote uma nova rotina em seu horário de pico. O agente precisa encerrar a venda sem exagerar promessas, marcar três encontros e registrar o objetivo da primeira visita.",
      ],
      tables: [
        {
          title: "Papéis e missão",
          columns: ["Papel", "Missão", "Comportamento"],
          rows: [
            [
              "Agente consultivo",
              "Conduzir fechamento, perguntar sobre valor, propor cadência e resumir o acordo.",
              "Use perguntas abertas e confirmações.",
            ],
            [
              "Cliente decisor",
              "Trazer preocupação operacional e escolher ponto focal.",
              "Faça uma objeção sobre tempo e uma pergunta sobre acompanhamento.",
            ],
            [
              "Observador",
              "Avaliar clareza e qualidade do plano.",
              "Dê um elogio específico e uma melhoria acionável.",
            ],
          ],
        },
        {
          title: "Roteiro de 12 minutos",
          columns: ["Tempo", "Etapa", "Entrega"],
          rows: [
            [
              "2 min",
              "Preparação",
              "Hipótese de valor e objetivo da primeira visita.",
            ],
            ["5 min", "Conversa", "Cliente confirma ou ajusta a jornada."],
            [
              "3 min",
              "Registro",
              "Tarefa com objetivo, contexto, ação e critério.",
            ],
            ["2 min", "Feedback", "Uma força e um ponto de melhoria."],
          ],
        },
      ],
      checklist: [
        "O agente conectou a conversa a um objetivo do cliente?",
        "As próximas etapas possuem data e motivo?",
        "A preocupação foi confirmada antes da resposta?",
        "O registro permitiria continuidade por outra pessoa autorizada?",
        "A conversa evitou garantias impróprias?",
      ],
    },
  ],
  closing:
    "A jornada para Ítaca não se mede pelo número de contatos feitos, mas pela qualidade da próxima decisão que o cliente consegue tomar com você. Quando o valor é claro, o plano é visível e o acompanhamento é disciplinado, cada encontro deixa de ser uma cobrança e se torna uma construção conjunta.",
};

export const INITIAL_TRAINING_REFERENCES: TrainingReference[] = [
  {
    title:
      "Gainsight — Customer Onboarding: Best Practices and Actionable Tips",
    url: "https://www.gainsight.com/blog/customer-onboarding/",
    note: "Perspectiva sobre primeira entrega de valor, educação do cliente, cadência e acompanhamento.",
  },
  {
    title: "Dock — SaaS Customer Onboarding Guide: Best Practices & Templates",
    url: "https://www.dock.us/library/customer-onboarding",
    note: "Referência para handoff entre áreas, plano compartilhado, marcos e entrega progressiva de valor.",
  },
  {
    title: "Bain & Company — Net Promoter System®",
    url: "https://www.bain.com/consulting-services/customer-strategy-and-marketing/net-promoter-score-system/",
    note: "Referência para escuta de feedback e orientação por lealdade do cliente.",
  },
  {
    title:
      "Leitura complementar — Predictable Revenue, Aaron Ross e Marylou Tyler",
    url: "https://predictablerevenue.com/",
    note: "Processos repetíveis de receita e prospecção.",
  },
  {
    title:
      "Leitura complementar — Marketing Management, Philip Kotler e Kevin Lane Keller",
    url: "https://www.pearson.com/en-us/subject-catalog/p/marketing-management/P200000003528/9780135887158",
    note: "Valor, segmentação e gestão de relacionamento.",
  },
];
