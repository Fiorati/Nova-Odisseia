import { afterAll, describe, expect, it, vi } from "vitest";
import { eq, inArray } from "drizzle-orm";
import { emailVerificationChallenges, users } from "../drizzle/schema";
import { appRouter } from "./routers";
import { ensureTestAdminAccount, getCredentialsForUser, getDb, saveEmailVerificationChallenge } from "./db";
import { createVerificationCode } from "./registration";
import type { TrpcContext } from "./_core/context";

const integrationIt = process.env.DATABASE_URL ? it : it.skip;
const createdIds: number[] = [];
const challengeEmails: string[] = [];

describe("integração de cadastro Stone", () => {
  integrationIt("exige código, cria as credenciais e inicia a sessão", async () => {
    const suffix = `${Date.now()}${Math.random().toString(36).slice(2, 8)}`;
    const caller = appRouter.createCaller({ user: null, req: { headers: {} } as TrpcContext["req"], res: { cookie: vi.fn() } as unknown as TrpcContext["res"] });
    const email = `agente.${suffix}@stone.com.br`;
    const verification = await createVerificationCode();
    challengeEmails.push(email);
    await saveEmailVerificationChallenge({ email, name: "Agente Stone Temporário", leadershipRole: "none", codeHash: verification.passwordHash, codeSalt: verification.passwordSalt, expiresAt: new Date(Date.now() + 15 * 60_000) });
    const confirmed = await caller.auth.verifyRegistrationCode({ email, code: verification.code });
    const result = await caller.auth.completeRegistration({ email, password: "senha-segura", verificationToken: confirmed.verificationToken });
    createdIds.push(result.user.id);
    expect(result.user.email).toMatch(/@stone\.com\.br$/);
    expect(await getCredentialsForUser(result.user.id)).not.toBeNull();
  });

  integrationIt("mantém o acesso administrativo provisionado com papel admin", async () => {
    const result = await ensureTestAdminAccount();
    expect(result?.role).toBe("admin");
  });

  afterAll(async () => {
    if (!process.env.DATABASE_URL) return;
    const db = await getDb();
    for (const id of createdIds) await db.delete(users).where(eq(users.id, id));
    if (challengeEmails.length) await db.delete(emailVerificationChallenges).where(inArray(emailVerificationChallenges.email, challengeEmails));
  });
});
