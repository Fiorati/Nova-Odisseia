import PDFDocument from "pdfkit";
import { and, desc, eq } from "drizzle-orm";
import { documentExports } from "../drizzle/schema";
import { getDb } from "./db";
import { storagePut } from "./storage";

export type ExportSection = { title: string; text?: string; items?: string[] };
export type ExportPayload = {
  exportType: "psv" | "rmr" | "roteiro" | "treinamento";
  referenceKey: string;
  title: string;
  subtitle: string;
  sections: ExportSection[];
};
const recent = new Map<number, number[]>();
function checkRate(userId: number) {
  const now = Date.now();
  const valid = (recent.get(userId) ?? []).filter(t => now - t < 60_000);
  if (valid.length >= 6)
    throw new Error("Aguarde um minuto antes de gerar outro PDF.");
  valid.push(now);
  recent.set(userId, valid);
}
const clean = (value: unknown, max = 2000) =>
  String(value ?? "")
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .trim()
    .slice(0, max);
function fileLabel(payload: ExportPayload) {
  return (
    `${payload.exportType}-${payload.referenceKey}`
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9-]+/g, "-")
      .replace(/-+/g, "-")
      .slice(0, 120)
      .toLowerCase() + ".pdf"
  );
}
export async function renderMindMapPdf(payload: ExportPayload) {
  return new Promise<Buffer>((resolve, reject) => {
    const doc = new PDFDocument({
      size: "A4",
      layout: "landscape",
      margin: 36,
      info: {
        Title: clean(payload.title, 180),
        Author: "Nova Odisseia: Fiorati",
      },
    });
    const chunks: Buffer[] = [];
    doc.on("data", c => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    const W = doc.page.width,
      H = doc.page.height;
    doc.rect(0, 0, W, H).fill("#f4f3ec");
    doc.roundedRect(28, 26, W - 56, 86, 16).fill("#0e3426");
    doc
      .fillColor("#bff27a")
      .font("Helvetica-Bold")
      .fontSize(10)
      .text("NOVA ODISSEIA · CADERNO OFFLINE", 48, 43);
    doc
      .fillColor("#ffffff")
      .fontSize(23)
      .text(clean(payload.title, 140), 48, 60, { width: W - 170 });
    doc
      .fillColor("#dcebd8")
      .font("Helvetica")
      .fontSize(9)
      .text(clean(payload.subtitle, 240), 48, 90, { width: W - 150 });
    doc.save().translate(W - 82, 64);
    doc.circle(0, 0, 27).fill("#bff27a");
    doc
      .fillColor("#0e3426")
      .font("Helvetica-Bold")
      .fontSize(24)
      .text("Φ", -8, -13);
    doc.restore();
    const sections = payload.sections.slice(0, 8);
    const columns = sections.length > 4 ? 4 : Math.max(2, sections.length);
    const rows = Math.ceil(sections.length / columns);
    const gap = 14;
    const top = 132;
    const cardW = (W - 72 - gap * (columns - 1)) / columns;
    const cardH = (H - top - 42 - gap * (rows - 1)) / rows;
    const hubX = W / 2;
    const hubY = 121;
    sections.forEach((_, index) => {
      const col = index % columns;
      const row = Math.floor(index / columns);
      const x = 36 + col * (cardW + gap);
      const y = top + row * (cardH + gap);
      doc
        .moveTo(hubX, hubY)
        .lineTo(x + cardW / 2, y)
        .lineWidth(1.2)
        .strokeColor("#80b99a")
        .stroke();
    });
    doc.circle(hubX, hubY, 9).fillAndStroke("#bff27a", "#0e3426");
    sections.forEach((section, index) => {
      const col = index % columns,
        row = Math.floor(index / columns),
        x = 36 + col * (cardW + gap),
        y = top + row * (cardH + gap);
      doc
        .roundedRect(x, y, cardW, cardH, 12)
        .fillAndStroke(index % 2 ? "#ffffff" : "#eef9e6", "#a7d8b8");
      doc
        .fillColor("#0e3426")
        .font("Helvetica-Bold")
        .fontSize(12)
        .text(clean(section.title, 100), x + 14, y + 13, { width: cardW - 28 });
      let cursor = y + 35;
      doc.fillColor("#285a43").font("Helvetica").fontSize(8.5);
      if (section.text) {
        doc.text(clean(section.text, 900), x + 14, cursor, {
          width: cardW - 28,
          height: cardH - 50,
          ellipsis: true,
          lineGap: 2,
        });
        cursor = doc.y + 5;
      }
      for (const item of (section.items ?? []).slice(0, 9)) {
        doc.text(`• ${clean(item, 240)}`, x + 14, cursor, {
          width: cardW - 28,
          height: Math.max(10, y + cardH - cursor - 10),
          ellipsis: true,
          lineGap: 2,
        });
        cursor = doc.y + 3;
        if (cursor > y + cardH - 18) break;
      }
    });
    doc
      .fillColor("#577363")
      .fontSize(7)
      .text(
        "Material privado gerado sob demanda. Revise antes de usar e confirme regras internas com sua liderança.",
        36,
        H - 24,
        { width: W - 72, align: "center" }
      );
    doc.end();
  });
}
export function buildExportEmailPayload(input: {
  email: string;
  name: string;
  fileName: string;
  pdf: Buffer;
  title: string;
}) {
  return {
    from: process.env.EMAIL_FROM,
    to: [input.email],
    subject: `Seu caderno offline — ${input.title}`,
    text: `Olá, ${input.name}. Seu PDF da Nova Odisseia está anexado. Ele contém dados privados do seu planejamento; armazene com cuidado.`,
    attachments: [
      { filename: input.fileName, content: input.pdf.toString("base64") },
    ],
  };
}
async function sendByEmail(input: {
  email: string;
  name: string;
  fileName: string;
  pdf: Buffer;
  title: string;
}) {
  const apiKey = process.env.RESEND_API_KEY,
    from = process.env.EMAIL_FROM;
  if (!apiKey || !from)
    throw new Error("O envio de e-mail não está configurado.");
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ ...buildExportEmailPayload(input), from }),
  });
  if (!response.ok)
    throw new Error(
      "O PDF foi criado, mas o e-mail não pôde ser enviado agora."
    );
}
export async function createDocumentExport(
  user: { id: number; email?: string | null; name?: string | null },
  payload: ExportPayload,
  sendEmail: boolean
) {
  checkRate(user.id);
  const pdf = await renderMindMapPdf(payload);
  if (pdf.length > 8 * 1024 * 1024)
    throw new Error("O PDF excedeu o limite seguro de 8 MB.");
  const fileName = fileLabel(payload);
  const stored = await storagePut(
    `document-exports/${user.id}/${Date.now()}-${fileName}`,
    pdf,
    "application/pdf"
  );
  const db = await getDb();
  await db.insert(documentExports).values({
    userId: user.id,
    exportType: payload.exportType,
    referenceKey: clean(payload.referenceKey, 180),
    fileName,
    fileKey: stored.key,
    fileUrl: stored.url,
  });
  let emailed = false,
    emailWarning = "";
  if (sendEmail) {
    if (!user.email)
      emailWarning = "Seu usuário não possui e-mail autenticado.";
    else
      try {
        await sendByEmail({
          email: user.email,
          name: user.name || "viajante",
          fileName,
          pdf,
          title: payload.title,
        });
        emailed = true;
        await db
          .update(documentExports)
          .set({ emailedAt: new Date() })
          .where(
            and(
              eq(documentExports.userId, user.id),
              eq(documentExports.fileKey, stored.key)
            )
          );
      } catch (error) {
        emailWarning =
          error instanceof Error
            ? error.message
            : "Não foi possível enviar o e-mail.";
      }
  }
  return {
    fileName,
    fileUrl: stored.url,
    emailed,
    emailWarning,
    sizeBytes: pdf.length,
  };
}
export async function listDocumentExports(userId: number) {
  const db = await getDb();
  return db
    .select()
    .from(documentExports)
    .where(eq(documentExports.userId, userId))
    .orderBy(desc(documentExports.createdAt))
    .limit(20);
}
