import { describe, expect, it } from "vitest";
import { extractPipelinePrintDraft, validatePrintUploads } from "./printExtraction";

const tinyPng = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]).toString("base64");
const upload = { fileName: "funil.png", fileMimeType: "image/png" as const, fileDataBase64: tinyPng };

describe("print extraction", () => {
  it("recusa conteúdo que não corresponde ao MIME declarado", () => {
    expect(() => validatePrintUploads([{ ...upload, fileMimeType: "image/jpeg" }])).toThrow("não corresponde");
  });

  it("envia somente a imagem recebida e devolve rascunho sem persistir", async () => {
    let imageUrl = "";
    const draft = await extractPipelinePrintDraft(9001, [upload], {
      listModels: async () => ({ data: [{ id: "gemini-3-flash-preview", object: "model", created: 0, owned_by: "google" }] }),
      invoke: async input => {
        const content = input.messages[1]!.content as Array<{ type: string; image_url?: { url: string } }>;
        imageUrl = content.find(part => part.type === "image_url")?.image_url?.url ?? "";
        return { id: "draft", created: 0, model: "gemini-3-flash-preview", choices: [{ index: 0, finish_reason: "stop", message: { role: "assistant", content: JSON.stringify({ notice: "Revise antes de salvar.", records: [{ clientName: "Cliente de teste", temperature: "quente", segmentLabel: "Alimentação", mcc: "5812", projectedTpv: 50000, nextContactAt: "2026-08-29", stage: "negociacao", confidence: 0.91 }] }) } }] };
      },
    });
    expect(imageUrl.startsWith("data:image/png;base64,")).toBe(true);
    expect(draft.records[0]?.clientName).toBe("Cliente de teste");
  });
});
