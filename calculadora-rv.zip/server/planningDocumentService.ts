import { and, desc, eq } from "drizzle-orm";
import { planningDocuments } from "../drizzle/schema";
import { getDb } from "./db";
import { storagePut } from "./storage";
const formats = {
  "application/pdf": { ext: "pdf", signature: Buffer.from("%PDF") },
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
    ext: "docx",
    signature: Buffer.from([0x50, 0x4b, 0x03, 0x04]),
  },
} as const;
export function validatePlanningUpload(
  mimeType: keyof typeof formats,
  fileDataBase64: string
) {
  const descriptor = formats[mimeType];
  const buffer = Buffer.from(fileDataBase64, "base64");
  if (!buffer.length || buffer.length > 8 * 1024 * 1024)
    throw new Error("O documento deve ter até 8 MB.");
  if (
    !buffer
      .subarray(0, descriptor.signature.length)
      .equals(descriptor.signature)
  )
    throw new Error("O conteúdo não corresponde ao formato informado.");
  return { descriptor, buffer };
}
export async function listPlanningDocuments(
  userId: number,
  input: { documentType: "psv" | "rmr"; referenceKey: string }
) {
  const db = await getDb();
  return db
    .select()
    .from(planningDocuments)
    .where(
      and(
        eq(planningDocuments.userId, userId),
        eq(planningDocuments.documentType, input.documentType),
        eq(planningDocuments.referenceKey, input.referenceKey)
      )
    )
    .orderBy(desc(planningDocuments.createdAt))
    .limit(12);
}
export async function uploadPlanningDocument(
  userId: number,
  input: {
    documentType: "psv" | "rmr";
    referenceKey: string;
    fileName: string;
    mimeType: keyof typeof formats;
    fileDataBase64: string;
  }
) {
  const { descriptor: d, buffer: b } = validatePlanningUpload(
    input.mimeType,
    input.fileDataBase64
  );
  const safe = input.fileName.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 160);
  const stored = await storagePut(
    `planning-documents/${userId}/${input.documentType}/${Date.now()}-${safe}`,
    b,
    input.mimeType
  );
  const db = await getDb();
  await db.insert(planningDocuments).values({
    userId,
    documentType: input.documentType,
    referenceKey: input.referenceKey.slice(0, 80),
    fileName: safe,
    mimeType: input.mimeType,
    fileSizeBytes: b.length,
    fileKey: stored.key,
    fileUrl: stored.url,
  });
  return listPlanningDocuments(userId, {
    documentType: input.documentType,
    referenceKey: input.referenceKey,
  });
}
export async function removePlanningDocument(userId: number, id: number) {
  const db = await getDb();
  const result = await db
    .delete(planningDocuments)
    .where(
      and(eq(planningDocuments.id, id), eq(planningDocuments.userId, userId))
    );
  return { removed: Number(result[0]?.affectedRows ?? 0) > 0 };
}
