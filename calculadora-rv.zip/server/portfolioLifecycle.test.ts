import { describe, expect, it } from "vitest";
import {
  getPortfolioLifecycle,
  mergePortfolioEntries,
} from "../shared/portfolioLifecycle";
import type { PortfolioMergeable } from "../shared/portfolioLifecycle";

const entry = (
  overrides: Partial<PortfolioMergeable> = {}
): PortfolioMergeable => ({
  id: 1,
  importId: 1,
  route: "Rota Medeiros",
  clientName: "Loja Aurora",
  document: "",
  phone: "",
  projectedTpv: 0,
  stage: "Planejado",
  status: "Planejado",
  phase: "Qualificação",
  temperature: "",
  mcc: "",
  cnae: "",
  segment: "",
  city: "",
  lastInteraction: "",
  nextAction: "",
  nextContactAt: null,
  notes: null,
  importedAt: new Date("2026-08-01T12:00:00Z"),
  fileName: "planejados.xlsx",
  ...overrides,
});

describe("ciclo e consolidação da carteira", () => {
  it("deriva Status e Fase das etapas do funil", () => {
    expect(getPortfolioLifecycle("Novos em qualificação")).toMatchObject({
      status: "Em qualificação",
      phase: "Qualificação",
    });
    expect(getPortfolioLifecycle("Em proposta")).toMatchObject({
      status: "Em negociação",
      phase: "Proposta",
    });
    expect(getPortfolioLifecycle("Novos perdidos")).toMatchObject({
      status: "Perdido",
      phase: "Fechamento",
    });
    expect(getPortfolioLifecycle("", "Novos clientes")).toMatchObject({
      status: "Cliente",
      phase: "Fechamento",
    });
  });

  it("combina fontes complementares por cliente e rota sem somar TPV duplicado", () => {
    const result = mergePortfolioEntries([
      entry({ projectedTpv: 30000 }),
      entry({
        id: 2,
        importId: 2,
        fileName: "propostas.xlsx",
        stage: "Em proposta",
        status: "Em negociação",
        phase: "Proposta",
        city: "São Paulo",
        nextAction: "Enviar proposta",
        importedAt: new Date("2026-08-02T12:00:00Z"),
      }),
    ]);
    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      projectedTpv: 30000,
      city: "São Paulo",
      nextAction: "Enviar proposta",
      status: "Em negociação",
      phase: "Proposta",
      sourceImportCount: 2,
    });
  });

  it("reconcilia aliases transitivos de nome, documento e telefone em um único cliente", () => {
    const result = mergePortfolioEntries([
      entry({ id: 1, document: "12345678000190", projectedTpv: 50000 }),
      entry({
        id: 2,
        importId: 2,
        clientName: "Clínica Itaca",
        document: "12345678000190",
        phone: "11988887777",
        fileName: "qualificacoes.xlsx",
        importedAt: new Date("2026-08-02T12:00:00Z"),
      }),
      entry({
        id: 3,
        importId: 3,
        clientName: "Nome atualizado",
        phone: "11988887777",
        city: "São Paulo",
        fileName: "propostas.xlsx",
        importedAt: new Date("2026-08-03T12:00:00Z"),
      }),
    ]);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      clientName: "Nome atualizado",
      document: "12345678000190",
      phone: "11988887777",
      projectedTpv: 50000,
      city: "São Paulo",
      sourceImportCount: 3,
    });
  });
});
