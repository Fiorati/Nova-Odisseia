import { afterAll, describe, expect, it } from "vitest";
import { inArray } from "drizzle-orm";
import { agentProfiles, userNotifications, users } from "../drizzle/schema";
import { appRouter } from "./routers";
import { getDb } from "./db";
import type { TrpcContext } from "./_core/context";

const integrationIt = process.env.DATABASE_URL ? it : it.skip;
const ids: number[] = [];
const today = () => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Sao_Paulo" }).format(new Date());

async function createUser(displayName: string, leadershipRole: "none" | "polo" | "distrital", polo: string, district: string) {
  const db = await getDb(); const suffix = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const created = await db.insert(users).values({ openId: `social_${suffix}`, name: displayName, email: `social_${suffix}@example.invalid`, loginMethod: "integration-test" }).$returningId();
  const id = created[0]?.id; if (!id) throw new Error("Falha ao criar usuário temporário."); ids.push(id);
  await db.insert(agentProfiles).values({ userId: id, displayName, leadershipRole, polo, district });
  return id;
}

function callerFor(userId: number) {
  return appRouter.createCaller({ user: { id: userId } as TrpcContext["user"], req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] });
}

describe("Arena X1 e Promessas hierárquicas", () => {
  integrationIt("permite X1 apenas na mesma hierarquia e consolida vencedor", async () => {
    const agentA = await createUser("Agente X1 A", "none", "Polo X1", "Distrito X1");
    const agentB = await createUser("Agente X1 B", "none", "Polo X1", "Distrito X1");
    const leader = await createUser("Líder X1", "polo", "Polo X1", "Distrito X1");
    await expect(callerFor(agentA).x1.create({ opponentUserId: leader, challengeDate: today(), kpis: ["salesTasks"] })).rejects.toThrow("mesma hierarquia");
    const challenge = await callerFor(agentA).x1.create({ opponentUserId: agentB, challengeDate: today(), kpis: ["salesTasks", "newTpv"] });
    await callerFor(agentB).x1.respond({ id: challenge.id, accept: true });
    expect(await callerFor(agentA).x1.saveResults({ id: challenge.id, results: { salesTasks: 10, newProposals: 0, newClients: 0, newActives: 0, newTpv: 50000 } })).toMatchObject({ completed: false });
    expect(await callerFor(agentB).x1.saveResults({ id: challenge.id, results: { salesTasks: 8, newProposals: 0, newClients: 0, newActives: 0, newTpv: 30000 } })).toMatchObject({ completed: true, winner: "criador" });
    const arena = await callerFor(agentA).x1.arena();
    expect(arena.scoreboard.find(item => item.userId === agentA)).toMatchObject({ wins: 1, losses: 0 });
  });

  integrationIt("notifica o líder e limita o painel diário ao mesmo polo", async () => {
    const db = await getDb();
    const leader = await createUser("Líder Promessa", "polo", "Polo Promessa", "Distrito Promessa");
    const agent = await createUser("Agente Promessa", "none", "Polo Promessa", "Distrito Promessa");
    const outside = await createUser("Agente Outro Polo", "none", "Polo Externo", "Distrito Promessa");
    await callerFor(agent).promises.save({ periodType: "dia", periodKey: today(), salesTasks: 10, newProposals: 2, newClients: 1, newActives: 1, newTpv: 30000 });
    const leaderNotifications = await db.select().from(userNotifications).where(inArray(userNotifications.userId, [leader]));
    expect(leaderNotifications.some(item => item.kind === "nova_promessa")).toBe(true);
    expect((await callerFor(leader).promises.panel()).poloDay.map(item => item.displayName)).toContain("Agente Promessa");
    expect((await callerFor(outside).promises.panel()).poloDay.map(item => item.displayName)).not.toContain("Agente Promessa");
  });
});

afterAll(async () => {
  if (!ids.length || !process.env.DATABASE_URL) return;
  const db = await getDb(); await db.delete(users).where(inArray(users.id, ids));
});
