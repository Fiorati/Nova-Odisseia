import { and, asc, eq } from "drizzle-orm";
import { dailyPriorities, dailyRouteEntries } from "../drizzle/schema";
import {
  dailyRouteDedupeKey,
  normalizeDailyRouteDraft,
  normalizeRouteDay,
  routeEffectivenessSuggestions,
  type DailyPriorityDraft,
  type DailyRouteDraft,
} from "../shared/routeObjective";
import { invokeLLM } from "./_core/llm";
import { getDb } from "./db";

export async function analyzeRoutePrints(
  uploads: Array<{
    fileName: string;
    fileMimeType: string;
    fileDataBase64: string;
  }>
) {
  const content: any[] = [
    {
      type: "text",
      text: "Extraia somente o roteiro comercial visível. Não invente. Retorne cliente, código, tipo de tarefa, endereço, horário HH:MM, status do agendamento, situação, observação e confiança 0-1. Ignore navegação e status do celular.",
    },
  ];
  for (const upload of uploads)
    content.push({
      type: "image_url",
      image_url: {
        url: `data:${upload.fileMimeType};base64,${upload.fileDataBase64}`,
        detail: "high",
      },
    });
  const response = await invokeLLM({
    model: "gemini-3-flash-preview",
    messages: [{ role: "user", content }],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "daily_route",
        strict: true,
        schema: {
          type: "object",
          properties: {
            records: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  clientName: { type: "string" },
                  clientCode: { type: "string" },
                  taskType: { type: "string" },
                  address: { type: "string" },
                  scheduledTime: { type: "string" },
                  appointmentStatus: { type: "string" },
                  situation: { type: "string" },
                  notes: { type: "string" },
                  confidence: { type: "number" },
                },
                required: [
                  "clientName",
                  "clientCode",
                  "taskType",
                  "address",
                  "scheduledTime",
                  "appointmentStatus",
                  "situation",
                  "notes",
                  "confidence",
                ],
                additionalProperties: false,
              },
            },
          },
          required: ["records"],
          additionalProperties: false,
        },
      },
    },
  });
  const parsed = JSON.parse(
    String(response.choices[0]?.message?.content || '{"records":[]}')
  ) as { records: DailyRouteDraft[] };
  return {
    records: parsed.records
      .map(normalizeDailyRouteDraft)
      .filter(r => r.clientName),
    warning:
      "Revise todos os campos antes de salvar. O print não é armazenado.",
  };
}
export async function getDailyRouteDay(userId: number, day: string) {
  const db = await getDb();
  const dayKey = normalizeRouteDay(day);
  const entries = await db
    .select()
    .from(dailyRouteEntries)
    .where(
      and(
        eq(dailyRouteEntries.userId, userId),
        eq(dailyRouteEntries.dayKey, dayKey)
      )
    )
    .orderBy(asc(dailyRouteEntries.scheduledTime));
  const priorities = await db
    .select()
    .from(dailyPriorities)
    .where(
      and(
        eq(dailyPriorities.userId, userId),
        eq(dailyPriorities.dayKey, dayKey)
      )
    )
    .orderBy(asc(dailyPriorities.position));
  return {
    dayKey,
    entries,
    priorities,
    suggestions: routeEffectivenessSuggestions(entries),
  };
}
export async function confirmDailyRouteDraft(
  userId: number,
  day: string,
  records: DailyRouteDraft[]
) {
  const db = await getDb();
  const dayKey = normalizeRouteDay(day);
  for (const raw of records) {
    const r = normalizeDailyRouteDraft(raw);
    if (!r.clientName) continue;
    const { confidence: _confidence, ...stored } = r;
    await db
      .insert(dailyRouteEntries)
      .values({ userId, dayKey, ...stored, dedupeKey: dailyRouteDedupeKey(r) })
      .onDuplicateKeyUpdate({ set: { ...stored } });
  }
  return getDailyRouteDay(userId, dayKey);
}
export async function saveDailyPriorities(
  userId: number,
  day: string,
  priorities: DailyPriorityDraft[]
) {
  if (priorities.length !== 5)
    throw new Error("Cadastre exatamente cinco prioridades.");
  const db = await getDb();
  const dayKey = normalizeRouteDay(day);
  for (const p of priorities) {
    await db
      .insert(dailyPriorities)
      .values({ userId, dayKey, ...p })
      .onDuplicateKeyUpdate({ set: { ...p } });
  }
  return getDailyRouteDay(userId, dayKey);
}
export async function removeDailyRouteEntry(userId: number, id: number) {
  const db = await getDb();
  await db
    .delete(dailyRouteEntries)
    .where(
      and(eq(dailyRouteEntries.id, id), eq(dailyRouteEntries.userId, userId))
    );
  return { removed: true };
}
