import { describe, expect, it } from "vitest";
import { getDashboardNavigation } from "../shared/dashboardNavigation";
import {
  INITIAL_TRAINING_COVER,
  INITIAL_TRAINING_COVER_SMALL,
  INITIAL_TRAINING_COVER_SRC_SET,
  INITIAL_TRAINING_CONTENT,
  INITIAL_TRAINING_REFERENCES,
  INITIAL_TRAINING_SLUG,
} from "../shared/trainingContent";
import { canManageTraining, canReadTraining } from "../shared/trainingAccess";

describe("Biblioteca de Ítaca — curso inaugural", () => {
  it("usa capas WebP responsivas em vez do PNG editorial pesado", () => {
    expect(INITIAL_TRAINING_COVER).toMatch(/-1280_[a-z0-9]+\.webp$/);
    expect(INITIAL_TRAINING_COVER_SMALL).toMatch(/-640_[a-z0-9]+\.webp$/);
    expect(INITIAL_TRAINING_COVER_SRC_SET).toContain(" 640w");
    expect(INITIAL_TRAINING_COVER_SRC_SET).toContain(" 1280w");
    expect(INITIAL_TRAINING_COVER_SRC_SET).not.toContain(".png");
  });

  it("mantém uma trilha estruturada de onboarding sem dados de clientes", () => {
    expect(INITIAL_TRAINING_SLUG).toMatch(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
    expect(INITIAL_TRAINING_CONTENT.outcomes).toHaveLength(4);
    expect(
      INITIAL_TRAINING_CONTENT.sections.map(section => section.id)
    ).toEqual([
      "valor-no-fechamento",
      "agenda-contratada",
      "crm-continuidadade",
      "plano-estrategico",
      "roleplay",
    ]);
    expect(JSON.stringify(INITIAL_TRAINING_CONTENT)).not.toMatch(
      /@stone\.com\.br|\b\d{14}\b/
    );
  });

  it("mantém fontes externas rastreáveis para aprofundamento", () => {
    expect(INITIAL_TRAINING_REFERENCES).toHaveLength(5);
    expect(
      INITIAL_TRAINING_REFERENCES.every(reference =>
        reference.url.startsWith("https://")
      )
    ).toBe(true);
    expect(
      INITIAL_TRAINING_REFERENCES.map(reference => reference.title)
    ).toEqual(
      expect.arrayContaining([
        expect.stringContaining("Gainsight"),
        expect.stringContaining("Dock"),
        expect.stringContaining("Bain"),
      ])
    );
  });
});

describe("Biblioteca de Ítaca — navegação", () => {
  it("fica disponível a agentes e a lideranças, inclusive no seletor móvel compartilhado", () => {
    expect(
      getDashboardNavigation(false).some(item => item.key === "biblioteca")
    ).toBe(true);
    expect(
      getDashboardNavigation(true).some(item => item.key === "biblioteca")
    ).toBe(true);
  });
});

describe("Biblioteca de Ítaca — autorização", () => {
  it("permite leitura somente após publicação e reserva a gestão ao administrador global", () => {
    expect(canReadTraining("publicado")).toBe(true);
    expect(canReadTraining("rascunho")).toBe(false);
    expect(canManageTraining("admin")).toBe(true);
    expect(canManageTraining("user")).toBe(false);
    expect(canManageTraining(null)).toBe(false);
  });
});
