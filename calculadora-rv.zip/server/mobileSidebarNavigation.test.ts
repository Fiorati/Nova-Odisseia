import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { getDashboardNavigation } from "../shared/dashboardNavigation";

const homePath = fileURLToPath(
  new URL("../client/src/pages/Home.tsx", import.meta.url)
);

describe("menu lateral para celular vertical", () => {
  it("oferece acionador acessível, painel pela esquerda e a mesma navegação autorizada", () => {
    const source = readFileSync(homePath, "utf8");
    expect(source).toContain('aria-label="Abrir menu lateral"');
    expect(source).toMatch(/<SheetContent\s+side="left"/);
    expect(source).toContain("nav.map(([key, Icon, label]) =>");
    expect(getDashboardNavigation(false)).toHaveLength(19);
    expect(getDashboardNavigation(true)).toHaveLength(14);
  });
});
