import XLSX from "xlsx";
import {
  formatItakaDate,
  getItakaMessageForDate,
  parseItakaDailyMessages,
  type ItakaDailyMessage,
} from "../shared/itakaDailyMessage";
import { storageGetSignedUrl } from "./storage";

const ITAKA_MESSAGES_KEY = "banco_mensagens_itaka_cb4b8909.xlsx";
let messagesCache: Promise<ItakaDailyMessage[]> | null = null;

function getSaoPauloCalendarDate(now = new Date()): Date {
  const values = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Sao_Paulo",
    day: "numeric",
    month: "numeric",
    year: "numeric",
  })
    .formatToParts(now)
    .reduce<Record<string, string>>((result, part) => {
      if (part.type !== "literal") result[part.type] = part.value;
      return result;
    }, {});

  return new Date(Number(values.year), Number(values.month) - 1, Number(values.day), 12);
}

async function getItakaMessages(): Promise<ItakaDailyMessage[]> {
  if (!messagesCache) {
    messagesCache = (async () => {
      const signedUrl = await storageGetSignedUrl(ITAKA_MESSAGES_KEY);
      const response = await fetch(signedUrl, { signal: AbortSignal.timeout(10_000) });
      if (!response.ok) throw new Error("A base diária ÍTAKA está temporariamente indisponível.");

      const workbook = XLSX.read(Buffer.from(await response.arrayBuffer()), { type: "buffer" });
      const worksheet = workbook.Sheets["Banco de Mensagens"];
      if (!worksheet) throw new Error("A base diária ÍTAKA não contém a aba esperada.");

      return parseItakaDailyMessages(
        XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet, { defval: "" }),
      );
    })().catch(error => {
      messagesCache = null;
      throw error;
    });
  }

  return messagesCache;
}

export async function getDailyItakaMessage(now = new Date()) {
  const calendarDate = getSaoPauloCalendarDate(now);
  return {
    dateLabel: formatItakaDate(calendarDate),
    message: getItakaMessageForDate(await getItakaMessages(), calendarDate),
  };
}

export { getSaoPauloCalendarDate };
