import { describe, expect, it } from "vitest";
import { calculateAutomaticMigrationBase, getDefaultPersonCommissionPercent, resolveClientCommissionBase, resolveMigrationBase } from "../shared/migrationBase";

describe("base automática da Migração M1", () => {
  it("calcula alimentação agressiva pelo MCC 5812 e TPV de R$ 30 mil", () => {
    const result = calculateAutomaticMigrationBase({ mcc: "5812", tpv: 30000, proposal: "agressiva" });
    expect(result.tier).toBe("30-50k");
    expect(result.segmentId).toBe("alimentacao-restaurantes");
    expect(result.base).toBe(125);
  });

  it("encontra a regra pelo CNAE quando o MCC não foi informado", () => {
    const result = calculateAutomaticMigrationBase({ cnae: "4520-0/01", tpv: 120000, proposal: "agressiva" });
    expect(result.base).toBe(1080);
  });

  it("permite que uma base manual substitua a sugestão automática", () => {
    expect(resolveMigrationBase(125, 180, true)).toBe(180);
    expect(resolveMigrationBase(125, null, true)).toBe(125);
    expect(resolveMigrationBase(125, 180, false)).toBe(0);
  });

  it("prioriza a comissão percentual customizada sobre PJ, MEI e matriz", () => {
    const custom = resolveClientCommissionBase({ automaticBase: 300, migratedTpv: 30000, customCommissionPercent: 0.071, defaultPersonCommissionPercent: 0.08, eligible: true });
    expect(custom.source).toBe("custom-percent");
    expect(custom.base).toBeCloseTo(21.3, 8);

    const mei = resolveClientCommissionBase({ automaticBase: 300, migratedTpv: 30000, customCommissionPercent: null, defaultPersonCommissionPercent: 0.08, eligible: true });
    expect(mei.source).toBe("person-default");
    expect(mei.base).toBeCloseTo(24, 8);
  });

  it("seleciona percentuais padrão distintos para PJ e MEI", () => {
    const defaults = { PJ: 0.1, MEI: 0.071 };
    expect(getDefaultPersonCommissionPercent("PJ", defaults)).toBe(0.1);
    expect(getDefaultPersonCommissionPercent("MEI", defaults)).toBe(0.071);
  });
});
