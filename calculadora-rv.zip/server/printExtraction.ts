import { listLLMModels, invokeLLM, type InvokeResult, type ModelInfo } from "./_core/llm";

export type PrintUpload = {
  fileName: string;
  fileMimeType: "image/jpeg" | "image/png" | "image/webp";
  fileDataBase64: string;
};

export type PipelinePrintDraft = {
  clientName: string;
  temperature: "quente" | "frio";
  segmentLabel: string;
  mcc: string;
  projectedTpv: number;
  nextContactAt: string;
  stage: "mapeado" | "qualificando" | "planejado" | "negociacao";
  confidence: number;
};

export type PortfolioPrintDraft = {
  route: string;
  clientName: string;
  document: string;
  mcc: string;
  cnae: string;
  segment: string;
  projectedTpv: number;
  status: string;
  phase: string;
  temperature: string;
  phone: string;
  city: string;
  lastInteraction: string;
  nextAction: string;
  nextContactAt: string;
  notes: string;
  confidence: number;
};

type DraftResponse<T> = { notice: string; records: T[] };
type VisionInvoker = (input: Parameters<typeof invokeLLM>[0]) => Promise<InvokeResult>;
type ModelLister = () => Promise<{ data: ModelInfo[] }>;

const MAX_PRINTS = 4;
const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_ANALYSES_PER_WINDOW = 6;
const printAnalyses = new Map<number, { count: number; startedAt: number }>();

function assertAnalysisLimit(userId: number) {
  const now = Date.now();
  const current = printAnalyses.get(userId);
  const active = !current || now - current.startedAt > WINDOW_MS ? { count: 0, startedAt: now } : current;
  active.count += 1;
  printAnalyses.set(userId, active);
  if (active.count > MAX_ANALYSES_PER_WINDOW) {
    throw new Error("Você atingiu o limite temporário de leituras de print. Aguarde alguns minutos e tente novamente.");
  }
}

function bytesFor(upload: PrintUpload) {
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(upload.fileDataBase64)) throw new Error("O conteúdo da imagem é inválido.");
  const bytes = Buffer.from(upload.fileDataBase64, "base64");
  if (!bytes.length || bytes.byteLength > MAX_IMAGE_BYTES) throw new Error("Cada print deve ter até 2 MB.");
  return bytes;
}

function validMagicBytes(bytes: Buffer, mimeType: PrintUpload["fileMimeType"]) {
  if (mimeType === "image/jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (mimeType === "image/png") return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  return bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
}

export function validatePrintUploads(uploads: PrintUpload[]) {
  if (!uploads.length || uploads.length > MAX_PRINTS) throw new Error("Envie entre 1 e 4 prints por leitura.");
  uploads.forEach(upload => {
    if (!upload.fileName.trim() || upload.fileName.length > 160) throw new Error("O nome do print é inválido.");
    const bytes = bytesFor(upload);
    if (!validMagicBytes(bytes, upload.fileMimeType)) throw new Error("O tipo do arquivo não corresponde ao conteúdo do print.");
  });
}

function toImageParts(uploads: PrintUpload[]) {
  return uploads.map(upload => ({
    type: "image_url" as const,
    image_url: { url: `data:${upload.fileMimeType};base64,${upload.fileDataBase64}`, detail: "high" as const },
  }));
}

function contentFrom(response: InvokeResult) {
  const content = response.choices[0]?.message.content;
  if (typeof content !== "string" || !content.trim()) throw new Error("Não foi possível interpretar o print. Tente uma imagem mais nítida.");
  try { return JSON.parse(content) as unknown; }
  catch { throw new Error("A leitura do print retornou um formato inválido. Tente novamente com uma imagem mais nítida."); }
}

function chooseVisionModel(models: ModelInfo[]) {
  const model = models.find(item => item.id.startsWith("gemini-")) ?? models[0];
  if (!model) throw new Error("Não há um modelo de leitura de imagem disponível neste momento.");
  return model.id;
}

const pipelineSchema = {
  name: "pipeline_print_draft",
  strict: true,
  schema: {
    type: "object",
    properties: {
      notice: { type: "string" },
      records: {
        type: "array",
        items: {
          type: "object",
          properties: {
            clientName: { type: "string" }, temperature: { type: "string", enum: ["quente", "frio"] }, segmentLabel: { type: "string" }, mcc: { type: "string" }, projectedTpv: { type: "number" }, nextContactAt: { type: "string" }, stage: { type: "string", enum: ["mapeado", "qualificando", "planejado", "negociacao"] }, confidence: { type: "number" },
          },
          required: ["clientName", "temperature", "segmentLabel", "mcc", "projectedTpv", "nextContactAt", "stage", "confidence"],
          additionalProperties: false,
        },
        maxItems: 30,
      },
    },
    required: ["notice", "records"],
    additionalProperties: false,
  },
} as const;

const portfolioSchema = {
  name: "portfolio_print_draft",
  strict: true,
  schema: {
    type: "object",
    properties: {
      notice: { type: "string" },
      records: {
        type: "array",
        items: {
          type: "object",
          properties: {
            route: { type: "string" }, clientName: { type: "string" }, document: { type: "string" }, mcc: { type: "string" }, cnae: { type: "string" }, segment: { type: "string" }, projectedTpv: { type: "number" }, status: { type: "string" }, phase: { type: "string" }, temperature: { type: "string" }, phone: { type: "string" }, city: { type: "string" }, lastInteraction: { type: "string" }, nextAction: { type: "string" }, nextContactAt: { type: "string" }, notes: { type: "string" }, confidence: { type: "number" },
          },
          required: ["route", "clientName", "document", "mcc", "cnae", "segment", "projectedTpv", "status", "phase", "temperature", "phone", "city", "lastInteraction", "nextAction", "nextContactAt", "notes", "confidence"],
          additionalProperties: false,
        },
        maxItems: 120,
      },
    },
    required: ["notice", "records"],
    additionalProperties: false,
  },
} as const;

async function extract<T>(userId: number, uploads: PrintUpload[], kind: "pipeline" | "portfolio", options?: { invoke?: VisionInvoker; listModels?: ModelLister }): Promise<DraftResponse<T>> {
  validatePrintUploads(uploads);
  assertAnalysisLimit(userId);
  const invoke = options?.invoke ?? invokeLLM;
  const listModels = options?.listModels ?? listLLMModels;
  const model = chooseVisionModel((await listModels()).data);
  const isPipeline = kind === "pipeline";
  const schema = isPipeline ? pipelineSchema : portfolioSchema;
  const instruction = isPipeline
    ? "Leia estes prints de funil comercial e devolva APENAS clientes claramente legíveis. Não invente texto ou valores. Use projectedTpv em reais, sem separador. Converta a etapa para mapeado, qualificando, planejado ou negociacao. Para dados ausentes, use string vazia, 0 ou frio. nextContactAt deve ser AAAA-MM-DD ou vazio."
    : "Leia estes prints de carteira ou funil comercial e devolva APENAS registros claramente legíveis. Não invente texto ou valores. Use projectedTpv em reais, sem separador. Preserve status exibido; fase deve ser Qualificação, Proposta ou Fechamento quando for possível inferir. Para campos ausentes, use string vazia ou 0. nextContactAt deve ser AAAA-MM-DD ou vazio. A rota só deve ser preenchida se estiver explícita no print.";
  const result = await invoke({
    model,
    maxTokens: 2400,
    messages: [{ role: "system", content: "Você extrai dados de prints de CRM para um rascunho privado. Nunca preencha informação incerta e nunca execute ações." }, { role: "user", content: [{ type: "text", text: `${instruction} O usuário revisará e confirmará cada registro antes de salvar.` }, ...toImageParts(uploads)] }],
    responseFormat: { type: "json_schema", json_schema: schema },
  });
  return contentFrom(result) as DraftResponse<T>;
}

export const extractPipelinePrintDraft = (userId: number, uploads: PrintUpload[], options?: { invoke?: VisionInvoker; listModels?: ModelLister }) => extract<PipelinePrintDraft>(userId, uploads, "pipeline", options);
export const extractPortfolioPrintDraft = (userId: number, uploads: PrintUpload[], options?: { invoke?: VisionInvoker; listModels?: ModelLister }) => extract<PortfolioPrintDraft>(userId, uploads, "portfolio", options);
