import { describe, expect, it } from "vitest";
import * as XLSX from "xlsx";
import { parsePortfolioHtmlTable, parsePortfolioPdfTableLines, parsePortfolioSpreadsheetBuffer } from "../shared/portfolioFileParsing";

function workbookBuffer(bookType: "xlsx" | "biff8") {
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Rota", "Cliente", "TPV", "Etapa"], ["Rota 01", "Loja Teste", 12500, "Negociação"]]), "Carteira");
  return XLSX.write(workbook, { type: "array", bookType });
}

describe("portfolio file parsing", () => {
  it("parses CSV, XLSX and XLS files into portfolio rows", () => {
    const csv = new TextEncoder().encode("Rota;Cliente;TPV;Etapa\nRota 02;Loja CSV;R$ 8.500,00;Qualificação");
    const csvRows = parsePortfolioSpreadsheetBuffer(csv);
    const xlsxRows = parsePortfolioSpreadsheetBuffer(workbookBuffer("xlsx"));
    const xlsRows = parsePortfolioSpreadsheetBuffer(workbookBuffer("biff8"));
    expect(csvRows[0]).toMatchObject({ route: "Rota 02", clientName: "Loja CSV", projectedTpv: 8500, stage: "Qualificação" });
    expect(xlsxRows[0]).toMatchObject({ route: "Rota 01", clientName: "Loja Teste", projectedTpv: 12500, stage: "Negociação" });
    expect(xlsRows[0]).toMatchObject({ route: "Rota 01", clientName: "Loja Teste", projectedTpv: 12500, stage: "Negociação" });
  });

  it("reconhece Nome e agrega as abas operacionais de exportações Google com múltiplas abas", () => {
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Data", "Agente", "Tarefas Realizadas"], ["2026-08-28", "Agente 01", 10]]), "Time");
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Carteira de Agosto"], [], ["Lead", "Nome", "MCC", "Segmento", "TPV Precificado", "Agente", "Data da movimentação", "Status"], ["L-0", "Lead Planejado", 5812, "Alimentação", 7000, "agente01@stone.com.br", "2026-08-28", "Planejado"]]), "Novos Planejados");
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Lead", "Nome", "MCC", "Segmento", "TPV Precificado", "Agente", "Status"], ["L-1", "Lead Qualificado", 5812, "Alimentação", 12000, "agente01@stone.com.br", "Qualificação"]]), "Qualificações");
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Oportunidade", "Nome", "MCC", "Segmento", "TPV Precificado", "Agente", "Status"], ["O-1", "Lead em Proposta", 7538, "Oficinas", 50000, "agente01@stone.com.br", "Em proposta"]]), "Propostas");
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Conta", "Nome", "MCC", "Segmento", "TPV Precificado", "Agente"], ["C-0", "Cliente Novo", 5411, "Mercado", 25000, "agente01@stone.com.br"]]), "Novos Clientes");
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet([["Conta", "Nome", "MCC", "Segmento", "TPV Precificado", "Agente", "Ativado"], ["C-1", "Cliente Ativo", 5411, "Mercado", 90000, "agente01@stone.com.br", "Sim"]]), "Novos Ativos");
    const buffer = XLSX.write(workbook, { type: "array", bookType: "xlsx" });
    const base = parsePortfolioSpreadsheetBuffer(buffer, { portfolioType: "base" });
    const route = parsePortfolioSpreadsheetBuffer(buffer, { portfolioType: "route" });
    expect(base.map(row => row.clientName)).toEqual(["Cliente Novo", "Cliente Ativo"]);
    expect(route.map(row => row.clientName)).toEqual(["Lead Planejado", "Lead Qualificado", "Lead em Proposta", "Cliente Novo", "Cliente Ativo"]);
    expect(route[0]).toMatchObject({ agentName: "agente01@stone.com.br", projectedTpv: 7000, stage: "Planejado", lastInteraction: "2026-08-28" });
    expect(route[0]).toMatchObject({ status: "Planejado", phase: "Qualificação" });
    expect(route[2]).toMatchObject({ status: "Em negociação", phase: "Proposta" });
    expect(route[3]).toMatchObject({ status: "Cliente", phase: "Fechamento" });
    expect(route[4]).toMatchObject({ status: "Ativo", phase: "Fechamento" });
  });

  it("parses a selectable-text PDF table that contains route and client columns", () => {
    const rows = parsePortfolioPdfTableLines(["Rota  Cliente  TPV  Etapa", "Rota 03  Loja PDF  20.000  Novos planejados"]);
    expect(rows[0]).toMatchObject({ route: "Rota 03", clientName: "Loja PDF", projectedTpv: 20000, stage: "Novos planejados" });
  });

  it("normaliza os campos operacionais da Lista Inteligente", () => {
    const csv = new TextEncoder().encode("Rota;Cliente;Telefone;Cidade;Etapa;Valor;Última Interação;Próxima Ação\nRota 02;Loja Lista;(11)99999-9999;São Paulo;Negociação;R$ 50.000,00;Ligação em 25/08;Enviar proposta");
    expect(parsePortfolioSpreadsheetBuffer(csv)[0]).toMatchObject({ route: "Rota 02", clientName: "Loja Lista", phone: "(11)99999-9999", city: "São Paulo", stage: "Negociação", projectedTpv: 50000, lastInteraction: "Ligação em 25/08", nextAction: "Enviar proposta" });
  });

  it("extrai uma tabela HTML estática sem executar scripts", () => {
    const html = `<html><head><script>throw new Error("não executar")</script></head><body><table><thead><tr><th>Cliente</th><th>Telefone</th><th>Cidade</th><th>Etapa</th><th>Valor</th><th>Última Interação</th><th>Próxima Ação</th></tr></thead><tbody><tr><td>Loja &amp; Cia</td><td>(11) 98888-7777</td><td>São Paulo</td><td>Qualificação</td><td>R$ 64.000,00</td><td>Visita em 27/08</td><td>Enviar proposta</td></tr></tbody></table></body></html>`;
    expect(parsePortfolioHtmlTable(html)[0]).toMatchObject({ clientName: "Loja & Cia", phone: "(11) 98888-7777", city: "São Paulo", stage: "Qualificação", projectedTpv: 64000, lastInteraction: "Visita em 27/08", nextAction: "Enviar proposta" });
    expect(() => parsePortfolioHtmlTable("<html><body>Sem tabela de leads</body></html>")).toThrow(/tabela reconhecível/i);
  });
});
