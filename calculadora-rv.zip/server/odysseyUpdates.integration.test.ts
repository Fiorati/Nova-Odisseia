import { afterAll, describe, expect, it } from "vitest";
import { inArray } from "drizzle-orm";
import { odysseyUpdates, users } from "../drizzle/schema";
import type { TrpcContext } from "./_core/context";
import { getDb } from "./db";
import { appRouter } from "./routers";

const integrationIt = process.env.DATABASE_URL ? it : it.skip;
const userIds: number[] = [];
const updateIds: number[] = [];

async function createUser(role: "user" | "admin") {
  const db = await getDb();
  const suffix = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const created = await db
    .insert(users)
    .values({
      openId: `odyssey_update_${suffix}`,
      name: role === "admin" ? "Cronista Admin" : "Leitor Comum",
      email: `odyssey_update_${suffix}@example.invalid`,
      loginMethod: "integration-test",
      role,
    })
    .$returningId();
  const id = Number(created[0]?.id);
  if (!id) throw new Error("Falha ao criar usuário do teste editorial.");
  userIds.push(id);
  return id;
}

function callerFor(userId: number, role: "user" | "admin") {
  return appRouter.createCaller({
    user: { id: userId, role } as TrpcContext["user"],
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  });
}

afterAll(async () => {
  if (!process.env.DATABASE_URL) return;
  const db = await getDb();
  if (updateIds.length)
    await db
      .delete(odysseyUpdates)
      .where(inArray(odysseyUpdates.id, updateIds));
  if (userIds.length) await db.delete(users).where(inArray(users.id, userIds));
});

describe("Atualizações da Odisseia — integração editorial", () => {
  integrationIt(
    "lista somente publicados e bloqueia oficina para usuário comum",
    async () => {
      const userId = await createUser("user");
      const caller = callerFor(userId, "user");
      const list = await caller.odysseyUpdates.list();
      expect(list.length).toBeGreaterThanOrEqual(5);
      expect(list.every(item => item.status === "publicado")).toBe(true);
      const detail = await caller.odysseyUpdates.get({ slug: list[0]!.slug });
      expect(detail.status).toBe("publicado");
      await expect(caller.odysseyUpdates.adminList()).rejects.toThrow(
        /administração global/i
      );
      await expect(
        caller.odysseyUpdates.createDraft({
          slug: "rascunho-bloqueado",
          title: "Rascunho bloqueado para usuário",
          summary:
            "Este rascunho existe apenas para validar o bloqueio administrativo.",
          category: "Experiência",
          readingMinutes: 2,
          contentMarkdown:
            "# Conteúdo bloqueado\n\nEste conteúdo tem tamanho suficiente para a validação e não deve ser persistido.",
        })
      ).rejects.toThrow(/administração global/i);
    }
  );

  integrationIt(
    "mantém rascunho invisível até publicação explícita pelo admin",
    async () => {
      const adminId = await createUser("admin");
      const caller = callerFor(adminId, "admin");
      const slug = `atualizacao-integracao-${Date.now()}`;
      const created = await caller.odysseyUpdates.createDraft({
        slug,
        title: "Atualização de integração editorial",
        summary:
          "Uma atualização temporária usada para validar o ciclo controlado de publicação.",
        category: "Experiência",
        readingMinutes: 2,
        contentMarkdown:
          "# O que mudou\n\nEste artigo temporário valida que um rascunho não aparece para leitores antes da publicação explícita.",
      });
      updateIds.push(created.id);
      expect(
        (await caller.odysseyUpdates.list()).some(item => item.slug === slug)
      ).toBe(false);
      await expect(caller.odysseyUpdates.get({ slug })).rejects.toThrow(
        /não encontrada|não publicada/i
      );
      const draft = (await caller.odysseyUpdates.adminList()).find(
        item => item.id === created.id
      );
      expect(draft?.status).toBe("rascunho");
      await caller.odysseyUpdates.publish({ id: created.id });
      expect((await caller.odysseyUpdates.get({ slug })).status).toBe(
        "publicado"
      );
    }
  );
});
