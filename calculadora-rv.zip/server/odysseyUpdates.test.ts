import { describe, expect, it } from "vitest";
import { getDashboardNavigation } from "../shared/dashboardNavigation";
import { INITIAL_ODYSSEY_UPDATES } from "../shared/odysseyUpdates";
import {
  canManageOdysseyUpdates,
  canReadOdysseyUpdate,
} from "../shared/odysseyUpdatesAccess";

describe("Atualizações da Odisseia — conteúdo", () => {
  it("publica um conjunto inaugural único com melhoria e melhores práticas", () => {
    expect(INITIAL_ODYSSEY_UPDATES).toHaveLength(5);
    expect(new Set(INITIAL_ODYSSEY_UPDATES.map(item => item.slug)).size).toBe(
      INITIAL_ODYSSEY_UPDATES.length
    );
    for (const update of INITIAL_ODYSSEY_UPDATES) {
      expect(update.content.improvements.length).toBeGreaterThan(0);
      expect(update.content.bestPractices.length).toBeGreaterThanOrEqual(3);
      expect(update.content.impact.length).toBeGreaterThan(30);
    }
    expect(JSON.stringify(INITIAL_ODYSSEY_UPDATES)).not.toMatch(
      /@stone\.com\.br|\b\d{14}\b/
    );
  });

  it("mantém os artigos em ordem editorial decrescente", () => {
    const times = INITIAL_ODYSSEY_UPDATES.map(item =>
      item.publishedAt.getTime()
    );
    expect(times).toEqual([...times].sort((a, b) => b - a));
  });
});

describe("Atualizações da Odisseia — autorização e navegação", () => {
  it("reserva gestão ao admin e leitura ao conteúdo publicado", () => {
    expect(canManageOdysseyUpdates("admin")).toBe(true);
    expect(canManageOdysseyUpdates("user")).toBe(false);
    expect(canReadOdysseyUpdate("publicado")).toBe(true);
    expect(canReadOdysseyUpdate("rascunho")).toBe(false);
  });

  it("aparece para agentes e lideranças no menu compartilhado", () => {
    expect(
      getDashboardNavigation(false).some(item => item.key === "atualizacoes")
    ).toBe(true);
    expect(
      getDashboardNavigation(true).some(item => item.key === "atualizacoes")
    ).toBe(true);
  });
});
