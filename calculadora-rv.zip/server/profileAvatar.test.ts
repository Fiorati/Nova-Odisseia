import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const caller = appRouter.createCaller({
  user: { id: 1 } as TrpcContext["user"],
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
});

describe("contrato de foto do perfil", () => {
  it("rejeita formatos que não sejam JPEG, PNG ou WEBP antes do armazenamento", async () => {
    await expect(caller.agent.avatar({ fileName: "perfil.gif", fileMimeType: "image/gif" as "image/png", fileDataBase64: "a".repeat(32) })).rejects.toThrow();
  });

  it("rejeita dados de imagem curtos antes do armazenamento", async () => {
    await expect(caller.agent.avatar({ fileName: "perfil.png", fileMimeType: "image/png", fileDataBase64: "pequeno" })).rejects.toThrow();
  });
});
