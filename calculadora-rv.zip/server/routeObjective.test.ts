import { describe, expect, it } from "vitest";
import { dedupeDailyRoutes, routeSuggestions } from "../shared/routeObjective";

describe("Roteiro e Objetivo", () => {
  it("consolida clientes repetidos sem duplicar a agenda", () => {
    const result = dedupeDailyRoutes([
      {
        clientName: "Padaria da Vila",
        clientCode: "123",
        taskType: "PP",
        address: "Rua A",
        scheduledTime: "11:30",
        appointmentStatus: "Agendada",
        situation: "Visita",
        notes: null,
      },
      {
        clientName: " padaria da vila ",
        clientCode: "123",
        taskType: "PP",
        address: "Rua A",
        scheduledTime: "11:30",
        appointmentStatus: "Agendada",
        situation: "Visita",
        notes: "Levar proposta",
      },
    ]);
    expect(result).toHaveLength(1);
    expect(result[0]?.notes).toBe("Levar proposta");
  });

  it("sugere organização quando há tarefas sem horário ou agendamento", () => {
    const suggestions = routeSuggestions([
      {
        clientName: "Cliente",
        clientCode: "",
        taskType: "RA",
        address: "",
        scheduledTime: "",
        appointmentStatus: "Não agendada",
        situation: "Reativar",
        notes: null,
      },
    ]);
    expect(suggestions.join(" ")).toMatch(/horário|agendamento/i);
  });
});
