import { describe, expect, it } from "vitest";
import {
  buildExportEmailPayload,
  renderMindMapPdf,
} from "./documentExportService";

const payload = {
  exportType: "roteiro" as const,
  referenceKey: "2026-09-01",
  title: "Roteiro e Objetivo",
  subtitle: "Dia de campo",
  sections: [
    { title: "Prioridades", items: ["Ativação · Padaria da Vila · 11h30"] },
  ],
};

describe("PDF offline", () => {
  it("gera um PDF vetorial válido e compacto", async () => {
    const pdf = await renderMindMapPdf(payload);
    expect(pdf.subarray(0, 4).toString()).toBe("%PDF");
    expect(pdf.length).toBeGreaterThan(1000);
    expect(pdf.length).toBeLessThan(2_000_000);
  });

  it("endereça o e-mail somente ao usuário autenticado informado", () => {
    process.env.EMAIL_FROM = "fiorati@novaodisseia.com";
    const email = buildExportEmailPayload({
      email: "agente@stone.com.br",
      name: "Agente",
      fileName: "roteiro.pdf",
      pdf: Buffer.from("%PDF"),
      title: payload.title,
    });
    expect(email.to).toEqual(["agente@stone.com.br"]);
    expect(email.attachments[0]?.filename).toBe("roteiro.pdf");
  });
});
