import { describe, expect, it } from "vitest";
import {
  getDashboardNavigation,
  isDashboardView,
} from "../shared/dashboardNavigation";

describe("navegação da plataforma", () => {
  it("mantém todas as abas do agente disponíveis para o seletor móvel", () => {
    const keys = getDashboardNavigation(false).map(item => item.key);
    expect(keys).toHaveLength(19);
    expect(keys).toEqual(
      expect.arrayContaining([
        "calculadora",
        "lista-inteligente",
        "biblioteca",
        "atualizacoes",
        "como-utilizar",
        "perfil",
      ])
    );
  });

  it("mantém as abas de liderança disponíveis para o seletor móvel", () => {
    const keys = getDashboardNavigation(true).map(item => item.key);
    expect(keys).toHaveLength(14);
    expect(keys).toEqual(
      expect.arrayContaining([
        "super-pipe",
        "campanhas",
        "lista-inteligente",
        "biblioteca",
        "atualizacoes",
        "promessas",
        "contagem-ativos",
      ])
    );
    expect(isDashboardView("lista-inteligente")).toBe(true);
    expect(isDashboardView("inexistente")).toBe(false);
  });
});
