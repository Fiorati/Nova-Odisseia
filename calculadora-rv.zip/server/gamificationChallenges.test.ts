import { describe, expect, it } from "vitest";
import { calculateX1Winner, emptyX1Results, promisePeriodKey, sanitizeX1Results, validPromisePeriodKey } from "../shared/gamificationChallenges";

describe("gamificação diária e promessas", () => {
  it("apura o X1 por KPI selecionado sem somar métricas fora do desafio", () => {
    const creator = { ...emptyX1Results(), salesTasks: 10, newProposals: 1, newTpv: 10000 };
    const opponent = { ...emptyX1Results(), salesTasks: 8, newProposals: 2, newTpv: 50000 };
    expect(calculateX1Winner(["salesTasks", "newProposals"], creator, opponent)).toEqual({ creatorScore: 1, opponentScore: 1, winner: "empate" });
  });

  it("normaliza resultados negativos e inválidos para zero", () => {
    expect(sanitizeX1Results({ salesTasks: -1, newTpv: Number.NaN })).toEqual(emptyX1Results());
  });

  it("gera chaves diárias, semanais e mensais determinísticas", () => {
    const date = new Date("2026-08-27T12:00:00.000Z");
    expect(promisePeriodKey("dia", date)).toBe("2026-08-27");
    expect(promisePeriodKey("semana", date)).toBe("2026-08-24");
    expect(promisePeriodKey("mes", date)).toBe("2026-08");
    expect(validPromisePeriodKey("mes", "2026-08")).toBe(true);
    expect(validPromisePeriodKey("semana", "2026-08")).toBe(false);
  });
});
