import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const readClientFile = (relativePath: string) =>
  readFileSync(
    fileURLToPath(
      new URL(`../client/src/pages/${relativePath}`, import.meta.url)
    ),
    "utf8"
  );

describe("contraste e escopo do tema", () => {
  it("aplica o fundo escuro somente ao sidebar principal", () => {
    const theme = readClientFile("ulisses-theme.css");
    const platform = readClientFile("platform.css");
    expect(theme).toContain(".app-primary-sidebar {");
    expect(theme).not.toMatch(/(^|\n)aside\s*\{/);
    expect(platform).not.toMatch(/(^|\n)aside(?:\s|:|>)/);
  });

  it("mantém o bloco de prática da Biblioteca com fundo e texto claros", () => {
    const source = readClientFile("BibliotecaItacaPanel.tsx");
    expect(source).toContain("bg-emerald-50 p-4");
    expect(source).toContain("font-semibold text-emerald-950");
  });
});
