import { describe, expect, it } from "vitest";
import { validatePlanningUpload } from "./planningDocumentService";

describe("anexos privados de PSV/RMR", () => {
  it("aceita um PDF cuja assinatura corresponde ao tipo", () => {
    const result = validatePlanningUpload(
      "application/pdf",
      Buffer.from("%PDF-1.7\nconteudo").toString("base64")
    );
    expect(result.buffer.subarray(0, 4).toString()).toBe("%PDF");
  });

  it("rejeita conteúdo incompatível com o tipo declarado", () => {
    expect(() =>
      validatePlanningUpload(
        "application/pdf",
        Buffer.from("arquivo falso").toString("base64")
      )
    ).toThrow(/formato/i);
  });
});
