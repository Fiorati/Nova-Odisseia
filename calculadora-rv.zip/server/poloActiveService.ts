import { and, eq, gte, lte, sql } from "drizzle-orm";
import {
  agentProfiles,
  poloActiveCommitments,
  promises,
} from "../drizzle/schema";
import { getDb } from "./db";

async function resolvePolo(userId: number, role: string, requested?: string) {
  const db = await getDb();
  const [profile] = await db
    .select()
    .from(agentProfiles)
    .where(eq(agentProfiles.userId, userId))
    .limit(1);
  if (role !== "admin" && profile?.leadershipRole !== "polo")
    throw new Error("Apenas Donos de Polo acessam esta área.");
  const polo = role === "admin" && requested ? requested : profile?.polo;
  if (!polo) throw new Error("Cadastre o polo no perfil.");
  return polo;
}
const weekEnd = (key: string) => {
  const date = new Date(`${key}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + 6);
  return date.toISOString().slice(0, 10);
};

export async function getPoloActivePanel(
  userId: number,
  role: string,
  input: { dayKey: string; weekKey: string; polo?: string }
) {
  const db = await getDb();
  const polo = await resolvePolo(userId, role, input.polo);
  const rows = await db
    .select()
    .from(poloActiveCommitments)
    .where(eq(poloActiveCommitments.polo, polo));
  const [day] = await db
    .select({ total: sql<number>`coalesce(sum(${promises.newActives}),0)` })
    .from(promises)
    .where(
      and(
        eq(promises.polo, polo),
        eq(promises.periodType, "dia"),
        eq(promises.periodKey, input.dayKey)
      )
    );
  const [week] = await db
    .select({ total: sql<number>`coalesce(sum(${promises.newActives}),0)` })
    .from(promises)
    .where(
      and(
        eq(promises.polo, polo),
        eq(promises.periodType, "dia"),
        gte(promises.periodKey, input.weekKey),
        lte(promises.periodKey, weekEnd(input.weekKey))
      )
    );
  const item = (type: "dia" | "semana", key: string, total: number) => {
    const row = rows.find(r => r.periodType === type && r.periodKey === key);
    return {
      target: row?.targetActives ?? 0,
      notes: row?.notes ?? "",
      agentsCommitted: Number(total ?? 0),
    };
  };
  return {
    polo,
    day: item("dia", input.dayKey, day?.total ?? 0),
    week: item("semana", input.weekKey, week?.total ?? 0),
  };
}
export async function savePoloActiveCommitment(
  userId: number,
  role: string,
  input: {
    periodType: "dia" | "semana";
    periodKey: string;
    targetActives: number;
    notes?: string;
    polo?: string;
  }
) {
  const db = await getDb();
  const polo = await resolvePolo(userId, role, input.polo);
  await db
    .insert(poloActiveCommitments)
    .values({
      createdByUserId: userId,
      polo,
      periodType: input.periodType,
      periodKey: input.periodKey,
      targetActives: input.targetActives,
      notes: input.notes || null,
    })
    .onDuplicateKeyUpdate({
      set: {
        createdByUserId: userId,
        targetActives: input.targetActives,
        notes: input.notes || null,
      },
    });
  return { saved: true };
}
