# Segurança da Jornada do Herói - Stone

Este projeto foi configurado para tratar os dados operacionais dos agentes como privados. A autorização é verificada no servidor em todas as operações relevantes: cada agente acessa apenas seus próprios registros, lideranças ficam restritas ao seu polo ou distrito e administradores continuam sujeitos à autenticação.

| Controle | Aplicação |
|---|---|
| Hierarquia | Novos cadastros recebem perfil de agente. A alteração de hierarquia não ocorre pelo próprio perfil nem pela tela pública. |
| Carteiras e rotas | Atribuições e importações respeitam escopo organizacional; uma liderança não administrativa não pode atribuir rota a perfil já vinculado a outro escopo. |
| Campanhas | Criação e edição seguem isolamento por polo/distrito e proprietário; resultados permanecem manuais e não são fabricados. |
| Auditoria | Alterações de rotas, importações e campanhas registram apenas ator, tipo, alvo, escopo e horário. Não são registrados senhas, textos de campanha, planilhas nem dados de clientes. |
| Navegador | Mutações tRPC exigem origem do mesmo host, e a aplicação publica cabeçalhos contra clickjacking, MIME sniffing, recursos ativos embutidos e permissões de dispositivo desnecessárias. |

As senhas são armazenadas somente como hash com salt. Códigos de recuperação expiram, possuem tentativas limitadas e a solicitação inicial mantém resposta neutra para não confirmar se um e-mail tem conta.

> Nenhuma aplicação web pode tornar secreto o código que precisa ser executado no navegador. Por isso, as regras de negócio, dados privados, permissões, segredos e operações sensíveis permanecem no servidor. O build de produção não publica source maps. O acesso ao repositório e às configurações de publicação deve permanecer restrito aos administradores autorizados do ambiente.

Alterações futuras de privilégio devem ser provisionadas por um administrador autorizado, com revisão do escopo e testes de permissão antes da publicação.
