type Props = { name: string; src?: string | null; size?: "sm" | "md" | "lg"; trophy?: boolean };

export default function ProfileAvatar({ name, src, size = "md", trophy = false }: Props) {
  const dimensions = size === "sm" ? "h-8 w-8 text-[10px]" : size === "lg" ? "h-20 w-20 text-xl" : "h-11 w-11 text-sm";
  const initials = name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase() || "NO";
  return <span className={`relative grid shrink-0 place-items-center overflow-visible rounded-full bg-emerald-100 font-bold text-emerald-800 ${dimensions}`} aria-label={`Foto de ${name}`}>
    {src ? <img src={src} alt={`Foto de ${name}`} className="h-full w-full rounded-full object-cover" /> : initials}
    {trophy && <span className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-amber-300 text-[11px] shadow" aria-label="Vencedor de X1">🏆</span>}
  </span>;
}
