import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import {
  PSV_CREATION_PROMPT,
  RMR_CREATION_PROMPT,
} from "@shared/planningPrompts";
import { Copy, FileText, Paperclip, Trash2 } from "lucide-react";
import { toast } from "sonner";

const allowed = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];
async function toBase64(file: File) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let out = "";
  for (let i = 0; i < bytes.length; i += 8192)
    out += String.fromCharCode(...Array.from(bytes.subarray(i, i + 8192)));
  return btoa(out);
}
export function PlanningDocumentPanel({
  type,
  referenceKey,
}: {
  type: "psv" | "rmr";
  referenceKey: string;
}) {
  const utils = trpc.useUtils();
  const q = trpc.planningDocuments.list.useQuery({
    documentType: type,
    referenceKey,
  });
  const upload = trpc.planningDocuments.upload.useMutation({
    onSuccess: async () => {
      await utils.planningDocuments.list.invalidate({
        documentType: type,
        referenceKey,
      });
      toast.success("Documento anexado com acesso privado.");
    },
    onError: e => toast.error(e.message),
  });
  const remove = trpc.planningDocuments.remove.useMutation({
    onSuccess: () =>
      utils.planningDocuments.list.invalidate({
        documentType: type,
        referenceKey,
      }),
  });
  const prompt = type === "psv" ? PSV_CREATION_PROMPT : RMR_CREATION_PROMPT;
  return (
    <section className="rounded-xl border border-emerald-100 bg-white p-5">
      <p className="font-mono text-[10px] tracking-[.12em] text-emerald-600">
        DOCUMENTO PRONTO · IA COMO APOIO
      </p>
      <h2 className="mt-1 text-xl font-semibold text-emerald-950">
        Anexe sua {type.toUpperCase()} ou gere um prompt orientado.
      </h2>
      <p className="mt-2 text-sm text-emerald-800">
        Você pode criar o material no Gemini ou outra IA, revisar o resultado e
        anexar o PDF ou DOCX. Não inclua dados pessoais ou informações fora dos
        sistemas autorizados.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button
          variant="outline"
          className="border-emerald-200 text-emerald-950"
          onClick={async () => {
            await navigator.clipboard.writeText(prompt);
            toast.success(`Prompt de ${type.toUpperCase()} copiado.`);
          }}
        >
          <Copy size={16} />
          Gerar prompt para criar {type.toUpperCase()}
        </Button>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-md bg-[#0e3426] px-4 py-2 text-sm font-semibold text-white">
          <Paperclip size={16} />
          Anexar documento
          <input
            hidden
            type="file"
            accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            onChange={async e => {
              const file = e.target.files?.[0];
              if (!file) return;
              if (!allowed.includes(file.type) || file.size > 8 * 1024 * 1024) {
                toast.error("Use PDF ou DOCX de até 8 MB.");
                return;
              }
              upload.mutate({
                documentType: type,
                referenceKey,
                fileName: file.name,
                mimeType: file.type as
                  | "application/pdf"
                  | "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                fileDataBase64: await toBase64(file),
              });
              e.target.value = "";
            }}
          />
        </label>
      </div>
      <div className="mt-4 space-y-2">
        {q.data?.map(doc => (
          <div
            className="flex items-center justify-between rounded-lg bg-emerald-50 p-3 text-xs text-emerald-950"
            key={doc.id}
          >
            <span className="flex items-center gap-2">
              <FileText size={15} />
              {doc.fileName} · {(doc.fileSizeBytes / 1024).toFixed(0)} KB
            </span>
            <button
              aria-label={`Remover ${doc.fileName}`}
              onClick={() => remove.mutate({ id: doc.id })}
            >
              <Trash2 size={15} />
            </button>
          </div>
        ))}
        {!q.isLoading && !q.data?.length && (
          <p className="text-xs text-emerald-700">
            Nenhum documento anexado neste período.
          </p>
        )}
      </div>
    </section>
  );
}
