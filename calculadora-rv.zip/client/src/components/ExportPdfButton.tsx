import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Download, Mail } from "lucide-react";
import { toast } from "sonner";
export type ExportPayload = {
  exportType: "psv" | "rmr" | "roteiro" | "treinamento";
  referenceKey: string;
  title: string;
  subtitle: string;
  sections: Array<{ title: string; text?: string; items?: string[] }>;
};
export function ExportPdfButton({
  payload,
  label = "Exportar PDF",
}: {
  payload: ExportPayload;
  label?: string;
}) {
  const mutation = trpc.documentExports.create.useMutation({
    onSuccess: r => {
      const a = document.createElement("a");
      a.href = r.fileUrl;
      a.download = r.fileName;
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
      r.emailed
        ? toast.success("PDF baixado e enviado ao seu e-mail.")
        : toast.info(r.emailWarning || "PDF pronto para download.");
    },
    onError: e => toast.error(e.message),
  });
  return (
    <Button
      variant="outline"
      className="border-emerald-200 text-emerald-950"
      disabled={mutation.isPending}
      onClick={() => mutation.mutate({ payload, sendEmail: true })}
    >
      {mutation.isPending ? (
        <Mail className="animate-pulse" size={16} />
      ) : (
        <Download size={16} />
      )}{" "}
      {mutation.isPending ? "Gerando..." : label}
    </Button>
  );
}
