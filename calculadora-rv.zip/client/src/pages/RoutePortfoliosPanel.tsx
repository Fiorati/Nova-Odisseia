import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  PortfolioPrintReview,
  type PortfolioPrintRecord,
} from "@/components/PrintReviewPanels";
import { trpc } from "@/lib/trpc";
import { getPortfolioImportFormat } from "@shared/portfolioImportFormat";
import {
  parsePortfolioPdfTableLines,
  parsePortfolioSpreadsheetBuffer,
  type ParsedPortfolioRow,
} from "@shared/portfolioFileParsing";
import {
  CalendarDays,
  FileText,
  FolderKanban,
  ImagePlus,
  Link2,
  ListFilter,
  Loader2,
  MapPinned,
  Phone,
  Sparkles,
  UploadCloud,
  UsersRound,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import RouteAssignmentsPanel from "./RouteAssignmentsPanel";

type PortfolioType = "base" | "route";
type ImportScope = "route" | "polo" | "district";
const brl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});
const MAX_FILE_BYTES = 12 * 1024 * 1024;
const currentMonth = () => new Date().toISOString().slice(0, 7);
const normalize = (value: string) => value.trim().toLocaleLowerCase("pt-BR");

async function parsePdf(file: File) {
  const [{ getDocument, GlobalWorkerOptions }, workerSrc] = await Promise.all([
    import("pdfjs-dist"),
    import("pdfjs-dist/build/pdf.worker.mjs?url"),
  ]);
  GlobalWorkerOptions.workerSrc = workerSrc.default;
  const pdf = await getDocument({
    data: new Uint8Array(await file.arrayBuffer()),
  }).promise;
  if (pdf.numPages > 60)
    throw new Error("O PDF excede o limite de 60 páginas para importação.");
  const lines: string[] = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
    const content = await (await pdf.getPage(pageNumber)).getTextContent();
    const grouped = new Map<number, Array<{ text: string; x: number }>>();
    content.items.forEach(item => {
      const textItem = item as { str?: unknown; transform?: readonly number[] };
      if (
        typeof textItem.str !== "string" ||
        !textItem.str.trim() ||
        !textItem.transform
      )
        return;
      const y = Math.round(Number(textItem.transform[5] ?? 0) / 3) * 3;
      grouped.set(y, [
        ...(grouped.get(y) ?? []),
        { text: textItem.str.trim(), x: Number(textItem.transform[4] ?? 0) },
      ]);
    });
    Array.from(grouped.entries())
      .sort(([left], [right]) => right - left)
      .forEach(([, cells]) => {
        const line = cells
          .sort((left, right) => left.x - right.x)
          .map(cell => cell.text)
          .join("  ");
        if (line) lines.push(line);
      });
  }
  return parsePortfolioPdfTableLines(lines);
}

async function parseFile(
  file: File,
  portfolioType: PortfolioType
): Promise<ParsedPortfolioRow[]> {
  return getPortfolioImportFormat(file.name, file.type) === "pdf"
    ? parsePdf(file)
    : parsePortfolioSpreadsheetBuffer(await file.arrayBuffer(), {
        portfolioType,
      });
}
function fileToBase64(file: File) {
  return file.arrayBuffer().then(buffer => {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let index = 0; index < bytes.length; index += 8192)
      binary += String.fromCharCode(
        ...Array.from(bytes.subarray(index, index + 8192))
      );
    return btoa(binary);
  });
}
function jsonToBase64(value: unknown) {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  let binary = "";
  for (let index = 0; index < bytes.length; index += 8192)
    binary += String.fromCharCode(
      ...Array.from(bytes.subarray(index, index + 8192))
    );
  return btoa(binary);
}
function base64ToFile(base64: string, name: string) {
  const binary = atob(base64);
  return new File(
    [Uint8Array.from(binary, character => character.charCodeAt(0))],
    name,
    {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
  );
}
function temperatureWeight(value: string) {
  const item = normalize(value);
  return item.includes("quente") || item.includes("alta")
    ? 2
    : item.includes("morno") || item.includes("media") || item.includes("média")
      ? 1
      : 0;
}
function formatImportedAt(value: Date | undefined) {
  return value
    ? new Intl.DateTimeFormat("pt-BR", {
        dateStyle: "short",
        timeStyle: "short",
      }).format(value)
    : "—";
}

function PortfolioTab({
  type,
  focusListIntelligent = false,
}: {
  type: PortfolioType;
  focusListIntelligent?: boolean;
}) {
  const fileInput = useRef<HTMLInputElement>(null);
  const scopedInput = useRef<HTMLInputElement>(null);
  const [referenceMonth, setReferenceMonth] = useState("");
  const [uploadMonth, setUploadMonth] = useState(currentMonth);
  const [sheetUrl, setSheetUrl] = useState("");
  const [stoneUrl, setStoneUrl] = useState("");
  const [showGoogle, setShowGoogle] = useState(false);
  const [showStone, setShowStone] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");
  const [phaseFilter, setPhaseFilter] = useState("all");
  const [cityFilter, setCityFilter] = useState("all");
  const utils = trpc.useUtils();
  const queryInput = useMemo(
    () => ({
      portfolioType: type,
      ...(referenceMonth ? { referenceMonth } : {}),
    }),
    [referenceMonth, type]
  );
  const portfolio = trpc.portfolio.getForMyRoute.useQuery(queryInput);
  const dashboard = trpc.agent.dashboard.useQuery();
  const leadership = dashboard.data?.profile?.leadershipRole ?? "none";
  const hasPolo = Boolean(dashboard.data?.profile?.polo?.trim());
  const canUploadSharedScope = leadership === "distrital" || hasPolo;
  const scope: ImportScope = leadership === "distrital" ? "district" : "polo";
  const entries = portfolio.data?.entries ?? [];
  const tpv = entries.reduce((sum, item) => sum + item.projectedTpv, 0);
  const visibleMonth = portfolio.data?.referenceMonth ?? referenceMonth;
  const statuses = useMemo(
    () =>
      Array.from(
        new Set(entries.map(entry => entry.status).filter(Boolean))
      ).sort(),
    [entries]
  );
  const phases = useMemo(
    () =>
      Array.from(
        new Set(entries.map(entry => entry.phase).filter(Boolean))
      ).sort(),
    [entries]
  );
  const cities = useMemo(
    () =>
      Array.from(
        new Set(entries.map(entry => entry.city).filter(Boolean))
      ).sort(),
    [entries]
  );
  const filteredEntries = useMemo(
    () =>
      entries.filter(
        entry =>
          (statusFilter === "all" || entry.status === statusFilter) &&
          (phaseFilter === "all" || entry.phase === phaseFilter) &&
          (cityFilter === "all" || entry.city === cityFilter)
      ),
    [cityFilter, entries, phaseFilter, statusFilter]
  );
  const priorityEntries = useMemo(
    () =>
      [...entries]
        .sort(
          (left, right) =>
            temperatureWeight(right.temperature) -
              temperatureWeight(left.temperature) ||
            right.projectedTpv - left.projectedTpv
        )
        .slice(0, 3),
    [entries]
  );
  const imported = async (
    data: {
      rowCount: number;
      waitingRoutes: string[];
      duplicateCount?: number;
      distributedRouteCount?: number;
      referenceMonth?: string;
    },
    importScope: ImportScope
  ) => {
    setReferenceMonth(data.referenceMonth ?? uploadMonth);
    await utils.portfolio.getForMyRoute.invalidate();
    const duplicates = data.duplicateCount
      ? ` ${data.duplicateCount} duplicidade(s) foram removidas.`
      : "";
    const distribution = data.distributedRouteCount
      ? ` ${data.distributedRouteCount} rota(s) receberam atualização.`
      : "";
    toast.success(
      importScope === "route"
        ? `Carteira da rota importada.${duplicates}`
        : data.waitingRoutes.length
          ? `${data.rowCount} linhas importadas; ${data.waitingRoutes.length} rota(s) aguardam titularidade.${distribution}${duplicates}`
          : `${data.rowCount} linhas distribuídas com sucesso.${distribution}${duplicates}`
    );
  };
  const routeUpload = trpc.portfolio.import.useMutation({
    onSuccess: data => imported(data, "route"),
    onError: error => toast.error(error.message),
  });
  const poloUpload = trpc.portfolio.importPolo.useMutation({
    onSuccess: data => imported(data, "polo"),
    onError: error => toast.error(error.message),
  });
  const districtUpload = trpc.portfolio.importDistrict.useMutation({
    onSuccess: data => imported(data, "district"),
    onError: error => toast.error(error.message),
  });
  const stoneLeadList = trpc.portfolio.importStoneLeadList.useMutation({
    onSuccess: data => {
      void imported(data, "route");
      setShowStone(false);
      setStoneUrl("");
    },
    onError: error => toast.error(error.message),
  });
  const pending =
    routeUpload.isPending ||
    poloUpload.isPending ||
    districtUpload.isPending ||
    stoneLeadList.isPending;
  useEffect(() => {
    if (focusListIntelligent && type === "route") setShowStone(true);
  }, [focusListIntelligent, type]);
  const upload = async (file: File | undefined, importScope: ImportScope) => {
    if (!file) return;
    if (file.size > MAX_FILE_BYTES) {
      toast.error("Envie um arquivo de até 12 MB.");
      return;
    }
    try {
      const [rows, fileDataBase64] = await Promise.all([
        parseFile(file, type),
        fileToBase64(file),
      ]);
      if (!rows.length)
        throw new Error(
          "Não encontrei uma coluna Nome preenchida nas abas operacionais do arquivo."
        );
      const input = {
        portfolioType: type,
        fileName: file.name,
        fileDataBase64,
        fileMimeType: file.type || "application/octet-stream",
        referenceMonth: uploadMonth,
        rows,
      };
      if (importScope === "route") await routeUpload.mutateAsync(input);
      if (importScope === "polo") await poloUpload.mutateAsync(input);
      if (importScope === "district") await districtUpload.mutateAsync(input);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Não foi possível ler o arquivo."
      );
    }
  };
  const uploadMany = async (
    files: FileList | null,
    importScope: ImportScope
  ) => {
    for (const file of Array.from(files ?? [])) await upload(file, importScope);
  };
  const googleSheet = trpc.portfolio.googleSheet.useMutation({
    onSuccess: async data => {
      try {
        await upload(base64ToFile(data.fileDataBase64, data.fileName), scope);
        setShowGoogle(false);
        setSheetUrl("");
      } catch (error) {
        toast.error(
          error instanceof Error
            ? error.message
            : "Não foi possível processar a planilha."
        );
      }
    },
    onError: error => toast.error(error.message),
  });
  const importReviewedPrints = async (
    records: PortfolioPrintRecord[],
    importScope: ImportScope
  ) => {
    const rows = records.map(
      ({ confidence: _confidence, nextContactAt, ...record }) => ({
        ...record,
        nextContactAt: /^\d{4}-\d{2}-\d{2}$/.test(nextContactAt)
          ? new Date(`${nextContactAt}T12:00:00.000Z`)
          : null,
      })
    );
    const input = {
      portfolioType: type,
      fileName: `prints-revisados-${new Date().toISOString().slice(0, 10)}.json`,
      fileDataBase64: jsonToBase64(rows),
      fileMimeType: "application/json",
      referenceMonth: uploadMonth,
      sourceType: "prints_revisados",
      sourceOrigin: "revisão manual de prints",
      rows,
    };
    if (importScope === "route") await routeUpload.mutateAsync(input);
    if (importScope === "polo") await poloUpload.mutateAsync(input);
    if (importScope === "district") await districtUpload.mutateAsync(input);
  };

  return (
    <section className="rounded-xl border border-emerald-100 bg-white p-5">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div className="flex gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-lg bg-emerald-50 text-emerald-700">
            {type === "base" ? (
              <UsersRound size={20} />
            ) : (
              <FolderKanban size={20} />
            )}
          </span>
          <div>
            <p className="font-mono text-[10px] font-semibold tracking-[.13em] text-emerald-600">
              CARTEIRA COMPARTILHADA POR ROTA
            </p>
            <h3 className="mt-1 text-xl font-semibold tracking-[-.04em]">
              {type === "base"
                ? "Carteira da Base"
                : "Funil do Pipe e Lista Inteligente"}
            </h3>
            <p className="mt-1 text-sm text-emerald-800/65">
              A leitura respeita a titularidade formal de rota e preserva o
              histórico mensal.
            </p>
          </div>
        </div>
        <div className="flex gap-2 text-xs">
          <span className="rounded-md bg-emerald-50 px-3 py-2">
            <b>{entries.length}</b> registros
          </span>
          <span className="rounded-md bg-lime-100 px-3 py-2">
            <b>{brl.format(tpv)}</b> TPV
          </span>
        </div>
      </div>
      <div className="mt-5 flex flex-col justify-between gap-3 rounded-lg bg-[#f6f8f2] p-4 md:flex-row md:items-end">
        <div>
          <b className="block text-sm">Competência histórica</b>
          <span className="text-xs text-emerald-700/65">
            Escolha um mês para revisar os dados de base ou de funil daquele
            período.
          </span>
        </div>
        <label className="flex items-center gap-2 text-xs font-medium">
          <CalendarDays size={15} />
          <Input
            className="w-36"
            type="month"
            value={visibleMonth ?? ""}
            onChange={event => setReferenceMonth(event.target.value)}
          />
        </label>
      </div>
      {portfolio.data?.importInfo && (
        <div className="mt-3 rounded-lg border border-emerald-100 bg-emerald-50/50 px-4 py-3 text-xs text-emerald-900">
          <b>Última origem:</b>{" "}
          {portfolio.data.importInfo.sourceType === "lista_inteligente"
            ? "Lista Inteligente Stone"
            : portfolio.data.importInfo.fileName}{" "}
          · <b>Fontes consolidadas:</b>{" "}
          {portfolio.data.importInfo.importCount ?? 1} · <b>Domínio/origem:</b>{" "}
          {portfolio.data.importInfo.sourceOrigin} · <b>Importado em:</b>{" "}
          {formatImportedAt(portfolio.data.importInfo.importedAt)}
        </div>
      )}
      {(portfolio.data?.referenceMonths?.length ?? 0) > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {portfolio.data!.referenceMonths.slice(0, 6).map(month => (
            <button
              key={month}
              onClick={() => setReferenceMonth(month)}
              className={`rounded-md px-3 py-1.5 text-xs ${visibleMonth === month ? "bg-[#0e3426] text-white" : "bg-emerald-50 text-emerald-700"}`}
            >
              {month}
            </button>
          ))}
        </div>
      )}
      {portfolio.data?.route ? (
        <div className="mt-5 space-y-3">
          <div className="flex flex-col justify-between gap-3 rounded-lg border border-emerald-100 p-4 md:flex-row md:items-end">
            <div>
              <b className="block text-sm">
                {focusListIntelligent && type === "route"
                  ? "Lista Inteligente da rota"
                  : "Anexar carteira de rota atribuída"}
              </b>
              <span className="text-xs text-emerald-700/65">
                Rotas atuais:{" "}
                {portfolio.data.routes.map(item => item.route).join(", ")}.
              </span>
            </div>
            <div className="flex items-end gap-2">
              <label className="grid gap-1 text-[10px] font-medium text-emerald-700">
                Competência
                <Input
                  className="h-9 w-32"
                  type="month"
                  value={uploadMonth}
                  onChange={event =>
                    setUploadMonth(event.target.value || currentMonth())
                  }
                />
              </label>
              {!focusListIntelligent && (
                <>
                  <input
                    ref={fileInput}
                    className="hidden"
                    type="file"
                    multiple
                    accept=".csv,.xlsx,.xls,.pdf,text/csv,application/pdf"
                    onChange={event => {
                      void uploadMany(event.target.files, "route");
                      event.currentTarget.value = "";
                    }}
                  />
                  <Button
                    className="bg-[#0e3426]"
                    disabled={pending}
                    onClick={() => fileInput.current?.click()}
                  >
                    <UploadCloud size={16} /> Anexar arquivos
                  </Button>
                  <Button
                    variant="outline"
                    className="border-sky-300 bg-white text-emerald-950"
                    disabled={pending}
                    onClick={() =>
                      document.getElementById("route-print-input")?.click()
                    }
                  >
                    <ImagePlus size={16} /> Anexar prints
                  </Button>
                </>
              )}
              {type === "route" && (
                <Button
                  variant="outline"
                  className="border-emerald-200"
                  disabled={pending}
                  onClick={() => setShowStone(value => !value)}
                >
                  <Sparkles size={16} />{" "}
                  {showStone ? "Ocultar link" : "Lista Inteligente"}
                </Button>
              )}
            </div>
          </div>
          {type === "route" && showStone && (
            <div className="grid gap-3 rounded-lg border border-lime-200 bg-lime-50 p-4 md:grid-cols-[1fr_auto]">
              <div>
                <label className="text-xs font-semibold text-emerald-950">
                  Link exportável da Lista Inteligente Stone
                </label>
                <Input
                  className="mt-1 bg-white"
                  type="url"
                  maxLength={12000}
                  value={stoneUrl}
                  onChange={event => setStoneUrl(event.target.value)}
                  placeholder="Cole o link temporário .html recebido da Stone"
                />
                <p className="mt-2 text-xs leading-5 text-emerald-800/70">
                  Aceitamos CSV/XLSX em domínio Stone e o relatório HTML
                  temporário no host oficial{" "}
                  <b>apidata.googleusercontent.com</b>. O app não segue
                  redirecionamentos, lê até 12 MB e não salva o link nem sua
                  assinatura; registramos somente origem e data.
                </p>
              </div>
              <Button
                className="self-end bg-[#0e3426]"
                disabled={!stoneUrl.trim() || stoneLeadList.isPending}
                onClick={() =>
                  stoneLeadList.mutate({
                    url: stoneUrl,
                    referenceMonth: uploadMonth,
                  })
                }
              >
                {stoneLeadList.isPending ? (
                  <Loader2 className="animate-spin" size={16} />
                ) : (
                  <Link2 size={16} />
                )}{" "}
                Importar carteira
              </Button>
            </div>
          )}
          <PortfolioPrintReview
            inputId="route-print-input"
            showTrigger={false}
            requireRoute={false}
            disabled={pending}
            onApprove={records => importReviewedPrints(records, "route")}
          />
        </div>
      ) : (
        <div className="mt-5 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <MapPinned className="mb-2" size={18} />
          <b>Esta conta ainda não possui rota formalmente atribuída.</b>
          <p className="mt-1">
            Peça ao líder para vincular sua rota ao seu e-mail antes de
            consultar ou importar carteiras.
          </p>
        </div>
      )}
      {canUploadSharedScope && (
        <div className="mt-3 rounded-lg border border-lime-200 bg-lime-50 p-4">
          <div className="flex flex-col justify-between gap-3 md:flex-row md:items-end">
            <div>
              <p className="font-mono text-[10px] font-semibold tracking-[.12em] text-emerald-700">
                {scope === "district"
                  ? "IMPORTAÇÃO POR DISTRITO"
                  : "ATUALIZAÇÃO COMPARTILHADA DO POLO"}
              </p>
              <b className="mt-1 block text-sm text-emerald-950">
                {scope === "district"
                  ? "Subir carteira do distrito"
                  : "Subir carteira do polo"}
              </b>
              <span className="text-xs text-emerald-900/80">
                A coluna Rota é obrigatória. O sistema remove duplicidades e
                entrega cada cliente somente ao agente vinculado àquela rota por
                e-mail. Rotas sem titularidade ficam aguardando vínculo.
              </span>
            </div>
            <div className="flex flex-wrap items-end gap-2">
              <label className="grid gap-1 text-[10px] font-medium text-emerald-700">
                Competência
                <Input
                  className="h-9 w-32"
                  type="month"
                  value={uploadMonth}
                  onChange={event =>
                    setUploadMonth(event.target.value || currentMonth())
                  }
                />
              </label>
              <input
                ref={scopedInput}
                className="hidden"
                type="file"
                multiple
                accept=".csv,.xlsx,.xls,.pdf,text/csv,application/pdf"
                onChange={event => {
                  void uploadMany(event.target.files, scope);
                  event.currentTarget.value = "";
                }}
              />
              <Button
                className="bg-[#0e3426]"
                disabled={pending}
                onClick={() => scopedInput.current?.click()}
              >
                <UploadCloud size={16} /> Arquivos
              </Button>
              <Button
                variant="outline"
                className="border-sky-300 bg-white text-emerald-950"
                disabled={pending}
                onClick={() =>
                  document
                    .getElementById(`hierarchy-print-input-${scope}`)
                    ?.click()
                }
              >
                <ImagePlus size={16} /> Anexar prints
              </Button>
              <Button
                variant="outline"
                className="border-emerald-200 bg-white text-emerald-950"
                disabled={pending}
                onClick={() => setShowGoogle(value => !value)}
              >
                <Link2 size={16} /> Google Planilhas
              </Button>
            </div>
          </div>
          {showGoogle && (
            <div className="mt-4 grid gap-3 rounded-lg border border-emerald-100 bg-white p-4 md:grid-cols-[1fr_auto]">
              <div>
                <label className="text-xs font-semibold text-emerald-950">
                  Link compartilhado da Google Planilha
                </label>
                <Input
                  className="mt-1"
                  value={sheetUrl}
                  onChange={event => setSheetUrl(event.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                />
                <p className="mt-2 text-xs text-emerald-800/65">
                  A planilha deve estar liberada para visualização por link. A
                  coluna <b>Nome</b> é o cliente. Para Base, lemos Novos
                  Clientes e Novos Ativos; para Funil, Novos Planejados,
                  Qualificações e Propostas. Importações da mesma competência se
                  complementam por cliente e rota. Se não houver coluna Rota,
                  usamos o Agente por nome ou e-mail somente quando corresponder
                  exatamente a uma rota já atribuída.
                </p>
              </div>
              <Button
                className="self-end bg-[#0e3426]"
                disabled={!sheetUrl.trim() || googleSheet.isPending}
                onClick={() =>
                  googleSheet.mutate({
                    url: sheetUrl,
                    scope: scope as "polo" | "district",
                  })
                }
              >
                {googleSheet.isPending ? (
                  <Loader2 className="animate-spin" size={16} />
                ) : (
                  <Link2 size={16} />
                )}{" "}
                Importar link
              </Button>
            </div>
          )}
          <PortfolioPrintReview
            inputId={`hierarchy-print-input-${scope}`}
            showTrigger={false}
            requireRoute
            disabled={pending}
            onApprove={records => importReviewedPrints(records, scope)}
          />
        </div>
      )}
      {type === "route" && entries.length > 0 && (
        <section className="mt-5 rounded-xl border border-emerald-100 bg-[#fbfdf9] p-4">
          <div className="flex items-center gap-2">
            <Sparkles size={17} className="text-emerald-600" />
            <div>
              <p className="font-mono text-[10px] font-semibold tracking-[.12em] text-emerald-600">
                LISTA DE PRIORIDADES
              </p>
              <b className="text-sm">Priorize temperatura e valor declarado</b>
            </div>
          </div>
          <div className="mt-3 grid gap-2 md:grid-cols-3">
            {priorityEntries.map((entry, index) => (
              <div key={entry.id} className="rounded-lg bg-white p-3 shadow-sm">
                <span className="font-mono text-[10px] text-emerald-600">
                  0{index + 1}
                </span>
                <b className="mt-1 block truncate text-sm">
                  {entry.clientName}
                </b>
                <p className="mt-1 text-xs text-emerald-800/65">
                  {entry.city || "Cidade não informada"} ·{" "}
                  {entry.status || entry.stage || "Status não informado"}
                </p>
                <p className="mt-1 text-xs text-emerald-700/60">
                  {entry.phase || "Fase não informada"}
                </p>
                <p className="mt-2 font-mono text-xs text-emerald-900">
                  {entry.projectedTpv
                    ? brl.format(entry.projectedTpv)
                    : "Valor não informado"}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}
      <div className="mt-5 flex flex-wrap items-end gap-3 rounded-lg bg-[#f6f8f2] p-3">
        <span className="flex items-center gap-2 text-xs font-semibold text-emerald-800">
          <ListFilter size={15} /> Filtros
        </span>
        <label className="text-xs text-emerald-800/70">
          Status
          <select
            className="ml-2 rounded-md border border-emerald-100 bg-white px-2 py-1.5 text-emerald-950"
            value={statusFilter}
            onChange={event => setStatusFilter(event.target.value)}
          >
            <option value="all">Todos</option>
            {statuses.map(status => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-emerald-800/70">
          Fase
          <select
            className="ml-2 rounded-md border border-emerald-100 bg-white px-2 py-1.5 text-emerald-950"
            value={phaseFilter}
            onChange={event => setPhaseFilter(event.target.value)}
          >
            <option value="all">Todas</option>
            {phases.map(phase => (
              <option key={phase} value={phase}>
                {phase}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-emerald-800/70">
          Cidade
          <select
            className="ml-2 rounded-md border border-emerald-100 bg-white px-2 py-1.5 text-emerald-950"
            value={cityFilter}
            onChange={event => setCityFilter(event.target.value)}
          >
            <option value="all">Todas</option>
            {cities.map(city => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>
        </label>
        <span className="ml-auto text-xs text-emerald-700/60">
          {filteredEntries.length} de {entries.length} registros
        </span>
      </div>
      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[1540px] text-left text-xs">
          <thead className="border-b border-emerald-100 font-mono text-[10px] uppercase tracking-[.08em] text-emerald-700/65">
            <tr>
              <th className="pb-3">Rota</th>
              <th className="pb-3">Cliente</th>
              <th className="pb-3">Telefone</th>
              <th className="pb-3">Cidade</th>
              <th className="pb-3">Status</th>
              <th className="pb-3">Fase</th>
              <th className="pb-3">Valor</th>
              <th className="pb-3">Última interação</th>
              <th className="pb-3">Próxima ação</th>
              <th className="pb-3">Segmento / MCC</th>
              <th className="pb-3">Temperatura</th>
            </tr>
          </thead>
          <tbody>
            {portfolio.isLoading ? (
              <tr>
                <td colSpan={11} className="py-6 text-emerald-700/65">
                  <Loader2 className="inline animate-spin" size={15} />{" "}
                  Carregando carteira...
                </td>
              </tr>
            ) : filteredEntries.length ? (
              filteredEntries.map(entry => (
                <tr className="border-b border-emerald-50" key={entry.id}>
                  <td className="py-3 text-emerald-700/70">{entry.route}</td>
                  <td className="py-3 font-semibold">{entry.clientName}</td>
                  <td className="py-3 text-emerald-700/70">
                    {entry.phone ? (
                      <span className="flex items-center gap-1">
                        <Phone size={12} />
                        {entry.phone}
                      </span>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="py-3">{entry.city || "—"}</td>
                  <td className="py-3 font-medium text-emerald-900">
                    {entry.status || entry.stage || "—"}
                  </td>
                  <td className="py-3">{entry.phase || "—"}</td>
                  <td className="py-3 font-mono">
                    {entry.projectedTpv ? brl.format(entry.projectedTpv) : "—"}
                  </td>
                  <td className="py-3">{entry.lastInteraction || "—"}</td>
                  <td className="py-3 max-w-60">{entry.nextAction || "—"}</td>
                  <td className="py-3">
                    {entry.segment || "—"}
                    <small className="ml-1 text-emerald-700/50">
                      {entry.mcc
                        ? `MCC ${entry.mcc}`
                        : entry.cnae
                          ? `CNAE ${entry.cnae}`
                          : ""}
                    </small>
                  </td>
                  <td className="py-3">{entry.temperature || "—"}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={11}
                  className="py-8 text-center text-emerald-700/60"
                >
                  <FileText
                    className="mx-auto mb-2 text-emerald-300"
                    size={22}
                  />
                  Não há registros nesta competência para as rotas atribuídas.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

export default function RoutePortfoliosPanel({
  initialTab = "base",
  focusListIntelligent = false,
}: {
  initialTab?: PortfolioType;
  focusListIntelligent?: boolean;
}) {
  const [active, setActive] = useState<PortfolioType>(initialTab);
  const dashboard = trpc.agent.dashboard.useQuery();
  const isLeader =
    (dashboard.data?.profile?.leadershipRole ?? "none") !== "none";
  useEffect(() => setActive(initialTab), [initialTab]);
  const isDedicatedList = focusListIntelligent && active === "route";
  return (
    <div className="space-y-6">
      <div>
        <p className="font-mono text-[10px] font-semibold tracking-[.14em] text-emerald-600">
          {isDedicatedList ? "LISTA INTELIGENTE" : "CARTEIRAS E ROTAS"}
        </p>
        <h2 className="mt-2 text-3xl font-semibold tracking-[-.055em]">
          {isDedicatedList
            ? "Importe a Lista Inteligente da sua rota."
            : "Base, Funil do Pipe e Lista Inteligente."}
        </h2>
        <p className="mt-2 max-w-3xl text-sm text-emerald-800/65">
          Cole um link exportável autorizado da Stone para normalizar os leads
          da rota, removendo duplicidades e mantendo a origem rastreável.
        </p>
      </div>
      {!focusListIntelligent && (
        <div className="flex w-fit rounded-lg bg-[#eef3eb] p-1">
          <button
            onClick={() => setActive("base")}
            className={`rounded-md px-4 py-2 text-sm ${active === "base" ? "bg-white font-semibold text-emerald-900 shadow-sm" : "text-emerald-700"}`}
          >
            Carteira da Base
          </button>
          <button
            onClick={() => setActive("route")}
            className={`rounded-md px-4 py-2 text-sm ${active === "route" ? "bg-white font-semibold text-emerald-900 shadow-sm" : "text-emerald-700"}`}
          >
            Funil do Pipe
          </button>
        </div>
      )}
      <PortfolioTab type={active} focusListIntelligent={isDedicatedList} />
      {!focusListIntelligent && <RouteAssignmentsPanel enabled={isLeader} />}
    </div>
  );
}
