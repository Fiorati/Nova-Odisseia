import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import type { OdysseyUpdateBody } from "@shared/odysseyUpdates";
import {
  ArrowLeft,
  ArrowRight,
  BookOpenText,
  CheckCircle2,
  Clock3,
  Compass,
  Gauge,
  Lightbulb,
  LockKeyhole,
  Map,
  Menu,
  Route,
  ShieldCheck,
  Sparkles,
  Wrench,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "short",
  year: "numeric",
});

const CATEGORY_ICONS: Record<string, typeof Sparkles> = {
  Experiência: Sparkles,
  "Carteiras e rotas": Route,
  Conteúdo: BookOpenText,
  Desempenho: Gauge,
};

function isMarkdownContent(
  content: unknown
): content is { kind: "markdown"; markdown: string } {
  if (!content || typeof content !== "object") return false;
  const value = content as Record<string, unknown>;
  return value.kind === "markdown" && typeof value.markdown === "string";
}

function isStructuredContent(content: unknown): content is OdysseyUpdateBody {
  if (!content || typeof content !== "object") return false;
  const value = content as Partial<OdysseyUpdateBody>;
  return (
    typeof value.intro === "string" &&
    Array.isArray(value.improvements) &&
    Array.isArray(value.bestPractices) &&
    typeof value.impact === "string"
  );
}

function UpdateArticle({ body }: { body: OdysseyUpdateBody }) {
  return (
    <div className="space-y-7">
      <section className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-7">
        <p className="max-w-3xl text-base leading-7 text-emerald-900/75">
          {body.intro}
        </p>
      </section>

      <section className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-7">
        <div className="flex items-center gap-2">
          <Wrench className="text-emerald-700" size={19} />
          <h2 className="text-xl font-semibold tracking-[-.035em] text-emerald-950">
            O que mudou
          </h2>
        </div>
        <div className="mt-5 grid gap-3 md:grid-cols-2">
          {body.improvements.map(item => (
            <article
              key={item.title}
              className="rounded-xl border border-emerald-100 bg-[#f7f8f1] p-4"
            >
              <h3 className="font-semibold text-emerald-950">{item.title}</h3>
              <p className="mt-2 text-sm leading-6 text-emerald-900/70">
                {item.description}
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className="rounded-2xl border border-lime-300 bg-lime-50 p-5 sm:p-7">
        <div className="flex items-center gap-2">
          <Lightbulb className="text-emerald-700" size={19} />
          <h2 className="text-xl font-semibold tracking-[-.035em] text-emerald-950">
            Melhores práticas
          </h2>
        </div>
        <ol className="mt-5 grid gap-3">
          {body.bestPractices.map((practice, index) => (
            <li
              key={practice}
              className="flex gap-3 rounded-xl border border-lime-200 bg-white p-4 text-sm leading-6 text-emerald-900/75"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#0e3426] font-mono text-[10px] font-semibold text-lime-200">
                {index + 1}
              </span>
              <span>{practice}</span>
            </li>
          ))}
        </ol>
      </section>

      <aside className="rounded-2xl border border-emerald-800 bg-[#0e3426] p-5 text-emerald-50 sm:p-7">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[.15em] text-lime-200">
          Impacto na jornada
        </p>
        <p className="mt-3 max-w-3xl text-sm leading-7 text-emerald-50">
          {body.impact}
        </p>
      </aside>
    </div>
  );
}

function EditorialWorkshop() {
  const utils = trpc.useUtils();
  const adminList = trpc.odysseyUpdates.adminList.useQuery();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    slug: "",
    title: "",
    summary: "",
    category: "Experiência",
    readingMinutes: 3,
    contentMarkdown: "",
  });
  const createDraft = trpc.odysseyUpdates.createDraft.useMutation({
    onSuccess: async () => {
      await adminList.refetch();
      setShowForm(false);
      setForm({
        slug: "",
        title: "",
        summary: "",
        category: "Experiência",
        readingMinutes: 3,
        contentMarkdown: "",
      });
      toast.success("Rascunho criado na oficina editorial.");
    },
    onError: error => toast.error(error.message),
  });
  const publish = trpc.odysseyUpdates.publish.useMutation({
    onSuccess: async () => {
      await Promise.all([
        adminList.refetch(),
        utils.odysseyUpdates.list.invalidate(),
      ]);
      toast.success("Atualização publicada para a equipe.");
    },
    onError: error => toast.error(error.message),
  });

  return (
    <section className="rounded-2xl border border-emerald-200 bg-white p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[.15em] text-emerald-700">
            Oficina do cronista
          </p>
          <h2 className="mt-1 text-xl font-semibold tracking-[-.035em] text-emerald-950">
            Publicação controlada
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-emerald-900/70">
            Somente a administração global cria e publica atualizações.
            Rascunhos não aparecem para a equipe.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => setShowForm(value => !value)}
          className="border-emerald-200 bg-white text-emerald-950"
        >
          {showForm ? "Fechar formulário" : "Criar rascunho"}
        </Button>
      </div>

      {showForm ? (
        <form
          className="mt-6 grid gap-4 rounded-xl bg-[#f7f8f1] p-4 sm:grid-cols-2"
          onSubmit={event => {
            event.preventDefault();
            createDraft.mutate(form);
          }}
        >
          <label className="grid gap-1 text-sm font-medium text-emerald-950">
            Identificador
            <Input
              value={form.slug}
              onChange={event =>
                setForm(current => ({ ...current, slug: event.target.value }))
              }
              placeholder="exemplo-da-atualizacao"
              required
            />
          </label>
          <label className="grid gap-1 text-sm font-medium text-emerald-950">
            Categoria
            <select
              value={form.category}
              onChange={event =>
                setForm(current => ({
                  ...current,
                  category: event.target.value,
                }))
              }
              className="h-10 rounded-md border border-input bg-white px-3 text-sm text-emerald-950"
            >
              <option>Experiência</option>
              <option>Carteiras e rotas</option>
              <option>Conteúdo</option>
              <option>Desempenho</option>
            </select>
          </label>
          <label className="grid gap-1 text-sm font-medium text-emerald-950 sm:col-span-2">
            Título
            <Input
              value={form.title}
              onChange={event =>
                setForm(current => ({ ...current, title: event.target.value }))
              }
              required
            />
          </label>
          <label className="grid gap-1 text-sm font-medium text-emerald-950 sm:col-span-2">
            Resumo
            <Textarea
              value={form.summary}
              onChange={event =>
                setForm(current => ({
                  ...current,
                  summary: event.target.value,
                }))
              }
              required
            />
          </label>
          <label className="grid gap-1 text-sm font-medium text-emerald-950">
            Leitura em minutos
            <Input
              type="number"
              min={1}
              max={60}
              value={form.readingMinutes}
              onChange={event =>
                setForm(current => ({
                  ...current,
                  readingMinutes: Number(event.target.value) || 1,
                }))
              }
              required
            />
          </label>
          <label className="grid gap-1 text-sm font-medium text-emerald-950 sm:col-span-2">
            Conteúdo em Markdown
            <Textarea
              value={form.contentMarkdown}
              onChange={event =>
                setForm(current => ({
                  ...current,
                  contentMarkdown: event.target.value,
                }))
              }
              className="min-h-52 font-mono text-xs"
              placeholder="# O que mudou&#10;&#10;Descreva a melhoria e inclua as melhores práticas."
              required
            />
          </label>
          <div className="sm:col-span-2">
            <Button
              type="submit"
              disabled={createDraft.isPending}
              className="bg-[#0e3426] text-white hover:bg-[#174a36]"
            >
              {createDraft.isPending ? "Salvando..." : "Salvar rascunho"}
            </Button>
          </div>
        </form>
      ) : null}

      <div className="mt-6 border-t border-emerald-100 pt-5">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
          Rascunhos e publicações
        </p>
        {adminList.isLoading ? (
          <p className="mt-3 text-sm text-emerald-900/70">Carregando...</p>
        ) : adminList.error ? (
          <p className="mt-3 text-sm text-red-700">{adminList.error.message}</p>
        ) : (
          <div className="mt-3 grid gap-2">
            {adminList.data?.map(item => (
              <article
                key={item.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-[#f7f8f1] p-4"
              >
                <div>
                  <p className="font-semibold text-emerald-950">{item.title}</p>
                  <p className="mt-1 text-xs text-emerald-800/65">
                    {item.status === "publicado" ? "Publicado" : "Rascunho"} ·{" "}
                    {item.readingMinutes} min
                  </p>
                </div>
                {item.status === "rascunho" ? (
                  <Button
                    size="sm"
                    onClick={() => publish.mutate({ id: item.id })}
                    disabled={publish.isPending}
                    className="bg-[#0e3426] text-white hover:bg-[#174a36]"
                  >
                    Publicar
                  </Button>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                    <LockKeyhole size={14} /> Publicado
                  </span>
                )}
              </article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

export function OdysseyUpdatesPanel({ isAdmin }: { isAdmin: boolean }) {
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [category, setCategory] = useState("Todas");
  const list = trpc.odysseyUpdates.list.useQuery();
  const selected = trpc.odysseyUpdates.get.useQuery(
    { slug: selectedSlug ?? "invalido" },
    { enabled: Boolean(selectedSlug) }
  );

  const categories = useMemo(
    () => [
      "Todas",
      ...Array.from(new Set((list.data ?? []).map(item => item.category))),
    ],
    [list.data]
  );
  const visibleItems = useMemo(
    () =>
      (list.data ?? []).filter(
        item => category === "Todas" || item.category === category
      ),
    [category, list.data]
  );

  if (selectedSlug) {
    return (
      <div className="max-w-5xl space-y-6">
        <Button
          variant="ghost"
          onClick={() => setSelectedSlug(null)}
          className="px-0 text-emerald-800 hover:bg-transparent hover:text-emerald-950"
        >
          <ArrowLeft size={16} /> Voltar às atualizações
        </Button>
        {selected.isLoading ? (
          <section className="rounded-2xl border border-emerald-100 bg-white p-8">
            <p className="text-sm text-emerald-900/70">Abrindo artigo...</p>
          </section>
        ) : selected.error ? (
          <section className="rounded-2xl border border-red-200 bg-red-50 p-6 text-red-800">
            {selected.error.message}
          </section>
        ) : selected.data ? (
          <>
            <header className="overflow-hidden rounded-3xl border border-emerald-100 bg-[#0e3426] p-6 text-white sm:p-8 lg:p-10">
              <div className="flex flex-wrap items-center gap-3 font-mono text-[10px] font-semibold uppercase tracking-[.14em] text-lime-200">
                <span>{selected.data.category}</span>
                <span>·</span>
                <span>{selected.data.readingMinutes} min de leitura</span>
              </div>
              <h1 className="mt-4 max-w-3xl text-3xl font-semibold leading-tight tracking-[-.055em] sm:text-5xl">
                {selected.data.title}
              </h1>
              <p className="mt-4 max-w-3xl text-sm leading-7 text-emerald-50">
                {selected.data.summary}
              </p>
              {selected.data.publishedAt ? (
                <p className="mt-6 text-xs text-emerald-100/80">
                  Publicado em{" "}
                  {dateFormatter.format(new Date(selected.data.publishedAt))}
                </p>
              ) : null}
            </header>
            {isMarkdownContent(selected.data.content) ? (
              <section className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-7">
                <div className="prose prose-emerald max-w-none prose-headings:tracking-[-.035em]">
                  <Streamdown>{selected.data.content.markdown}</Streamdown>
                </div>
              </section>
            ) : isStructuredContent(selected.data.content) ? (
              <UpdateArticle body={selected.data.content} />
            ) : (
              <section className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-amber-900">
                Este artigo está temporariamente indisponível.
              </section>
            )}
          </>
        ) : null}
      </div>
    );
  }

  return (
    <div className="max-w-6xl space-y-7">
      <section className="overflow-hidden rounded-3xl border border-emerald-100 bg-[#0e3426] text-white">
        <div className="relative grid gap-7 p-6 sm:p-8 lg:grid-cols-[1.15fr_.85fr] lg:p-10">
          <div className="relative z-10">
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[.16em] text-lime-200">
              Diário de bordo · evolução contínua
            </p>
            <h1 className="mt-3 max-w-3xl text-3xl font-semibold leading-tight tracking-[-.055em] sm:text-5xl">
              Atualizações da Odisseia
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-emerald-50">
              As melhorias da plataforma, explicadas com contexto e acompanhadas
              das práticas que ajudam cada recurso a entregar mais valor no
              campo.
            </p>
          </div>
          <div className="relative z-10 grid grid-cols-2 gap-3 self-end">
            <div className="rounded-2xl border border-white/15 bg-white/10 p-4">
              <Map className="text-lime-200" size={19} />
              <p className="mt-3 text-2xl font-semibold">
                {list.data?.length ?? 0}
              </p>
              <p className="mt-1 text-xs text-emerald-100">
                artigos publicados
              </p>
            </div>
            <div className="rounded-2xl border border-white/15 bg-white/10 p-4">
              <Compass className="text-lime-200" size={19} />
              <p className="mt-3 text-sm font-semibold leading-5">
                Melhoria com método
              </p>
              <p className="mt-1 text-xs text-emerald-100">mudança + prática</p>
            </div>
          </div>
          <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full border-[44px] border-emerald-700/25" />
        </div>
      </section>

      <section>
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[.14em] text-emerald-700">
              Últimas evoluções
            </p>
            <h2 className="mt-1 text-2xl font-semibold tracking-[-.045em] text-emerald-950">
              O que mudou na jornada
            </h2>
          </div>
          <div className="flex max-w-full gap-2 overflow-x-auto pb-1">
            {categories.map(item => (
              <button
                key={item}
                type="button"
                onClick={() => setCategory(item)}
                className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                  category === item
                    ? "border-[#0e3426] bg-[#0e3426] text-white"
                    : "border-emerald-200 bg-white text-emerald-900 hover:border-lime-400"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        {list.isLoading ? (
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            {[0, 1, 2, 3].map(item => (
              <div
                key={item}
                className="h-52 animate-pulse rounded-2xl bg-emerald-100/60"
              />
            ))}
          </div>
        ) : list.error ? (
          <div className="mt-5 rounded-2xl border border-red-200 bg-red-50 p-5 text-red-800">
            {list.error.message}
          </div>
        ) : visibleItems.length ? (
          <div className="mt-5 grid gap-4 md:grid-cols-2">
            {visibleItems.map((item, index) => {
              const Icon = CATEGORY_ICONS[item.category] ?? Menu;
              return (
                <article
                  key={item.id}
                  className={`group flex min-h-64 flex-col rounded-2xl border p-5 shadow-[0_18px_50px_-44px_rgba(6,78,59,.65)] transition duration-200 hover:-translate-y-0.5 hover:border-lime-400 sm:p-6 ${
                    index === 0 && category === "Todas"
                      ? "border-lime-300 bg-lime-50"
                      : "border-emerald-100 bg-white"
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#0e3426] text-lime-200">
                      <Icon size={19} />
                    </span>
                    <span className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
                      {item.category}
                    </span>
                  </div>
                  <h3 className="mt-5 text-xl font-semibold tracking-[-.035em] text-emerald-950">
                    {item.title}
                  </h3>
                  <p className="mt-3 flex-1 text-sm leading-6 text-emerald-900/70">
                    {item.summary}
                  </p>
                  <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-emerald-100 pt-4">
                    <span className="inline-flex items-center gap-3 text-xs text-emerald-800/65">
                      <span className="inline-flex items-center gap-1">
                        <Clock3 size={13} /> {item.readingMinutes} min
                      </span>
                      {item.publishedAt
                        ? dateFormatter.format(new Date(item.publishedAt))
                        : "Em preparação"}
                    </span>
                    <Button
                      size="sm"
                      onClick={() => setSelectedSlug(item.slug)}
                      className="bg-[#0e3426] text-white hover:bg-[#174a36]"
                    >
                      Ler artigo <ArrowRight size={15} />
                    </Button>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="mt-5 rounded-2xl border border-dashed border-emerald-200 bg-white p-8 text-center">
            <ShieldCheck className="mx-auto text-emerald-600" size={26} />
            <p className="mt-3 font-semibold text-emerald-950">
              Nenhuma atualização nesta categoria.
            </p>
          </div>
        )}
      </section>

      <aside className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-6">
        <div className="flex items-start gap-3">
          <CheckCircle2
            className="mt-0.5 shrink-0 text-emerald-700"
            size={20}
          />
          <div>
            <h2 className="font-semibold text-emerald-950">
              Regra de ouro do diário
            </h2>
            <p className="mt-2 text-sm leading-6 text-emerald-900/70">
              Uma atualização explica o recurso; a prática recomendada mostra
              como usá-lo com segurança. Procedimentos internos vigentes sempre
              devem ser confirmados nos canais oficiais e com a liderança.
            </p>
          </div>
        </div>
      </aside>

      {isAdmin ? <EditorialWorkshop /> : null}
    </div>
  );
}
