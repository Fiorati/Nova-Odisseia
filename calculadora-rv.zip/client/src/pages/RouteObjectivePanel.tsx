import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ExportPdfButton } from "@/components/ExportPdfButton";
import { trpc } from "@/lib/trpc";
import type {
  DailyPriorityDraft,
  DailyRouteDraft,
} from "@shared/routeObjective";
import { CheckCircle2, FileImage, Filter, Save, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

const today = () => new Date().toISOString().slice(0, 10);
const blankPriority = (position: number): DailyPriorityDraft => ({
  position,
  objective: "",
  clientName: "",
  expectedResult: "",
  ownerName: "",
  how: "",
  whenLabel: "",
  completed: false,
});
async function readImage(file: File) {
  if (
    !["image/jpeg", "image/png", "image/webp"].includes(file.type) ||
    file.size > 2 * 1024 * 1024
  )
    throw new Error("Use JPG, PNG ou WEBP de até 2 MB.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (let i = 0; i < bytes.length; i += 8192)
    binary += String.fromCharCode(...Array.from(bytes.subarray(i, i + 8192)));
  return {
    fileName: file.name,
    fileMimeType: file.type as "image/jpeg" | "image/png" | "image/webp",
    fileDataBase64: btoa(binary),
  };
}

export default function RouteObjectivePanel() {
  const utils = trpc.useUtils();
  const [dayKey, setDayKey] = useState(today);
  const [filter, setFilter] = useState("");
  const [consent, setConsent] = useState(false);
  const [drafts, setDrafts] = useState<DailyRouteDraft[]>([]);
  const day = trpc.routeObjective.day.useQuery({ dayKey });
  const [priorities, setPriorities] = useState<DailyPriorityDraft[]>(() =>
    Array.from({ length: 5 }, (_, i) => blankPriority(i + 1))
  );
  useEffect(() => {
    if (!day.data) return;
    setPriorities(
      Array.from({ length: 5 }, (_, i) => {
        const found = day.data.priorities.find(p => p.position === i + 1);
        return found
          ? {
              position: found.position,
              objective: found.objective,
              clientName: found.clientName,
              expectedResult: found.expectedResult,
              ownerName: found.ownerName,
              how: found.how,
              whenLabel: found.whenLabel,
              completed: found.completed,
            }
          : blankPriority(i + 1);
      })
    );
  }, [day.data]);
  const analyze = trpc.routeObjective.analyzePrints.useMutation({
    onSuccess: r => {
      setDrafts(r.records);
      toast.info(r.warning);
    },
    onError: e => toast.error(e.message),
  });
  const confirm = trpc.routeObjective.confirm.useMutation({
    onSuccess: async () => {
      setDrafts([]);
      await utils.routeObjective.day.invalidate({ dayKey });
      toast.success("Roteiro confirmado.");
    },
    onError: e => toast.error(e.message),
  });
  const remove = trpc.routeObjective.remove.useMutation({
    onSuccess: () => utils.routeObjective.day.invalidate({ dayKey }),
  });
  const save = trpc.routeObjective.savePriorities.useMutation({
    onSuccess: async () => {
      await utils.routeObjective.day.invalidate({ dayKey });
      toast.success("Cinco prioridades salvas.");
    },
    onError: e => toast.error(e.message),
  });
  const visible = useMemo(
    () =>
      (day.data?.entries ?? []).filter(e =>
        [e.clientName, e.address, e.situation, e.appointmentStatus]
          .join(" ")
          .toLowerCase()
          .includes(filter.toLowerCase())
      ),
    [day.data?.entries, filter]
  );
  const draft = (i: number, k: keyof DailyRouteDraft, v: string) =>
    setDrafts(a => a.map((x, n) => (n === i ? { ...x, [k]: v } : x)));
  const priority = (
    i: number,
    k: keyof DailyPriorityDraft,
    v: string | boolean
  ) => setPriorities(a => a.map((x, n) => (n === i ? { ...x, [k]: v } : x)));
  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-emerald-100 bg-white p-5">
        <div className="mb-4 flex justify-end">
          <ExportPdfButton
            label="Exportar Roteiro e Objetivo em PDF"
            payload={{
              exportType: "roteiro",
              referenceKey: dayKey,
              title: "Roteiro e Objetivo",
              subtitle: `Dia ${new Date(`${dayKey}T12:00:00`).toLocaleDateString("pt-BR")}`,
              sections: [
                {
                  title: "Roteiro do dia",
                  items: (day.data?.entries ?? []).map(
                    item =>
                      `${item.scheduledTime || "sem horário"} · ${item.clientName} · ${item.appointmentStatus || item.situation || "a confirmar"}`
                  ),
                },
                {
                  title: "Cinco prioridades",
                  items: priorities.map(
                    item =>
                      `${item.objective || "Objetivo"} · ${item.clientName || "cliente a definir"} · ${item.expectedResult || "resultado a definir"} · ${item.ownerName || "responsável a definir"} · ${item.whenLabel || "horário a definir"}`
                  ),
                },
                {
                  title: "Ajustes de efetividade",
                  items: day.data?.suggestions ?? [],
                },
              ],
            }}
          />
        </div>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-mono text-[10px] tracking-[.12em] text-emerald-600">
              PRINT DO MARCOPOLO · ROTEIRO
            </p>
            <h2 className="mt-1 text-xl font-semibold text-emerald-950">
              Transforme a agenda em acompanhamento editável.
            </h2>
            <p className="mt-2 text-sm text-emerald-800">
              Revise a extração antes de confirmar. A imagem não é armazenada.
            </p>
          </div>
          <label className="grid gap-1 text-xs font-semibold text-emerald-950">
            Dia do roteiro
            <Input
              type="date"
              value={dayKey}
              onChange={e => setDayKey(e.target.value || today())}
            />
          </label>
        </div>
        <label className="mt-4 flex items-start gap-2 text-xs text-emerald-900">
          <input
            type="checkbox"
            checked={consent}
            onChange={e => setConsent(e.target.checked)}
            className="mt-0.5 accent-emerald-700"
          />
          Autorizo uma leitura única do print para criar um rascunho revisável.
        </label>
        <label
          className={`mt-4 inline-flex cursor-pointer items-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold ${consent ? "bg-[#0e3426] text-white" : "bg-slate-100 text-slate-500"}`}
        >
          <FileImage size={17} />
          Incluir prints do Roteiro
          <input
            hidden
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            disabled={!consent || analyze.isPending}
            onChange={async e => {
              try {
                const files = Array.from(e.target.files ?? []).slice(0, 4);
                analyze.mutate({
                  dayKey,
                  uploads: await Promise.all(files.map(readImage)),
                });
              } catch (err) {
                toast.error(
                  err instanceof Error ? err.message : "Arquivo inválido."
                );
              }
              e.target.value = "";
            }}
          />
        </label>
      </section>
      {drafts.length > 0 && (
        <section className="rounded-xl border border-amber-200 bg-amber-50 p-5">
          <h3 className="font-semibold text-amber-950">
            Revise antes de salvar
          </h3>
          <div className="mt-4 space-y-3">
            {drafts.map((d, i) => (
              <div
                className="grid gap-2 rounded-lg bg-white p-3 md:grid-cols-4"
                key={`${d.clientName}-${i}`}
              >
                {(
                  [
                    ["clientName", "Cliente"],
                    ["address", "Endereço"],
                    ["scheduledTime", "Horário"],
                    ["appointmentStatus", "Agendamento"],
                    ["clientCode", "Código"],
                    ["taskType", "Tipo"],
                    ["situation", "Situação"],
                    ["notes", "Observação"],
                  ] as const
                ).map(([k, p]) => (
                  <Input
                    key={k}
                    value={String(d[k] ?? "")}
                    onChange={e => draft(i, k, e.target.value)}
                    placeholder={p}
                  />
                ))}
              </div>
            ))}
          </div>
          <Button
            className="mt-4 bg-[#0e3426] text-white"
            onClick={() => confirm.mutate({ dayKey, records: drafts })}
          >
            <CheckCircle2 size={16} />
            Confirmar roteiro revisado
          </Button>
        </section>
      )}
      <section className="rounded-xl border border-emerald-100 bg-white p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="text-xl font-semibold text-emerald-950">
            Acompanhamento do dia
          </h2>
          <label className="relative">
            <Filter
              className="absolute left-3 top-3 text-emerald-600"
              size={15}
            />
            <Input
              className="pl-9"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Filtrar roteiro"
            />
          </label>
        </div>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-xs">
            <thead>
              <tr className="border-b border-emerald-100 text-emerald-700">
                <th className="pb-3">Hora</th>
                <th>Cliente</th>
                <th>Endereço</th>
                <th>Agendamento</th>
                <th>Situação</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {visible.map(e => (
                <tr className="border-b border-emerald-50" key={e.id}>
                  <td className="py-3 font-mono">{e.scheduledTime || "—"}</td>
                  <td>
                    <b>{e.clientName}</b>
                  </td>
                  <td>{e.address || "—"}</td>
                  <td>{e.appointmentStatus || "—"}</td>
                  <td>{e.situation || "—"}</td>
                  <td>
                    <button
                      aria-label="Excluir"
                      onClick={() => remove.mutate({ id: e.id })}
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!day.isLoading && !visible.length && (
            <p className="py-8 text-center text-sm text-emerald-700">
              Nenhum compromisso confirmado.
            </p>
          )}
        </div>
        <div className="mt-4 grid gap-2 md:grid-cols-2">
          {day.data?.suggestions.map(t => (
            <p
              className="rounded-lg bg-lime-50 p-3 text-xs text-emerald-950"
              key={t}
            >
              {t}
            </p>
          ))}
        </div>
      </section>
      <section className="rounded-xl border border-emerald-100 bg-white p-5">
        <h2 className="text-xl font-semibold text-emerald-950">
          Cinco prioridades do dia
        </h2>
        <div className="mt-4 space-y-3">
          {priorities.map((p, i) => (
            <div
              className="grid gap-2 rounded-lg bg-[#f5f8f2] p-3 md:grid-cols-3"
              key={p.position}
            >
              <b className="md:col-span-3">Prioridade {p.position}</b>
              {(
                [
                  ["objective", "Objetivo"],
                  ["clientName", "Cliente"],
                  ["expectedResult", "Resultado esperado"],
                  ["ownerName", "Quem?"],
                  ["how", "Como?"],
                  ["whenLabel", "Quando?"],
                ] as const
              ).map(([k, ph]) => (
                <Input
                  key={k}
                  value={String(p[k])}
                  onChange={e => priority(i, k, e.target.value)}
                  placeholder={ph}
                />
              ))}
            </div>
          ))}
        </div>
        <Button
          className="mt-4 bg-[#0e3426] text-white"
          onClick={() => save.mutate({ dayKey, priorities })}
        >
          <Save size={16} />
          Salvar cinco prioridades
        </Button>
      </section>
    </div>
  );
}
