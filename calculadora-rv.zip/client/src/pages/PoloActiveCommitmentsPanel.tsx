import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Save, Target } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
const today = () => new Date().toISOString().slice(0, 10);
const monday = (v: string) => {
  const d = new Date(`${v}T12:00:00Z`),
    n = d.getUTCDay();
  d.setUTCDate(d.getUTCDate() + (n === 0 ? -6 : 1 - n));
  return d.toISOString().slice(0, 10);
};
export default function PoloActiveCommitmentsPanel() {
  const utils = trpc.useUtils();
  const [date, setDate] = useState(today);
  const input = useMemo(
    () => ({ dayKey: date, weekKey: monday(date) }),
    [date]
  );
  const q = trpc.poloActives.panel.useQuery(input);
  const [day, setDay] = useState(0),
    [week, setWeek] = useState(0),
    [dayNotes, setDayNotes] = useState(""),
    [weekNotes, setWeekNotes] = useState("");
  useEffect(() => {
    if (q.data) {
      setDay(q.data.day.target);
      setWeek(q.data.week.target);
      setDayNotes(q.data.day.notes);
      setWeekNotes(q.data.week.notes);
    }
  }, [q.data]);
  const save = trpc.poloActives.save.useMutation({
    onSuccess: async () => {
      await utils.poloActives.panel.invalidate(input);
      toast.success("Compromisso salvo.");
    },
    onError: e => toast.error(e.message),
  });
  const card = (
    title: string,
    type: "dia" | "semana",
    key: string,
    target: number,
    setTarget: (n: number) => void,
    notes: string,
    setNotes: (s: string) => void,
    actual: number
  ) => (
    <article className="rounded-xl border border-emerald-100 bg-white p-5">
      <div className="flex justify-between">
        <div>
          <small className="font-mono text-emerald-600">{key}</small>
          <h2 className="text-xl font-semibold text-emerald-950">{title}</h2>
        </div>
        <Target className="text-emerald-600" />
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg bg-emerald-50 p-4">
          <small>Compromisso do polo</small>
          <b className="block text-3xl">{target}</b>
        </div>
        <div className="rounded-lg bg-lime-50 p-4">
          <small>Soma dos agentes</small>
          <b className="block text-3xl">{actual}</b>
        </div>
      </div>
      <label className="mt-4 grid gap-1 text-xs">
        Quantidade
        <Input
          type="number"
          min="0"
          max="500"
          value={target}
          onChange={e => setTarget(Number(e.target.value) || 0)}
        />
      </label>
      <label className="mt-3 grid gap-1 text-xs">
        Nota
        <Textarea value={notes} onChange={e => setNotes(e.target.value)} />
      </label>
      <Button
        className="mt-4 bg-[#0e3426] text-white"
        onClick={() =>
          save.mutate({
            periodType: type,
            periodKey: key,
            targetActives: target,
            notes,
          })
        }
      >
        <Save size={16} />
        Salvar
      </Button>
    </article>
  );
  return (
    <div className="space-y-6">
      <section className="rounded-2xl bg-[#0e3426] p-7 text-white">
        <p className="font-mono text-[10px] tracking-[.15em] text-lime-200">
          CONTAGEM DE ATIVOS
        </p>
        <h1 className="mt-2 text-4xl font-semibold">
          Compromisso diário e semanal do polo.
        </h1>
      </section>
      <label className="grid max-w-xs gap-1 text-xs">
        Data de referência
        <Input
          type="date"
          value={date}
          onChange={e => setDate(e.target.value || today())}
        />
      </label>
      <section className="grid gap-5 lg:grid-cols-2">
        {card(
          "Compromisso do dia",
          "dia",
          input.dayKey,
          day,
          setDay,
          dayNotes,
          setDayNotes,
          q.data?.day.agentsCommitted ?? 0
        )}
        {card(
          "Compromisso da semana",
          "semana",
          input.weekKey,
          week,
          setWeek,
          weekNotes,
          setWeekNotes,
          q.data?.week.agentsCommitted ?? 0
        )}
      </section>
    </div>
  );
}
