import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ExportPdfButton } from "@/components/ExportPdfButton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  INITIAL_TRAINING_COVER,
  INITIAL_TRAINING_COVER_SRC_SET,
  type TrainingBody,
} from "@shared/trainingContent";
import {
  ArrowLeft,
  ArrowRight,
  BookMarked,
  Clock3,
  Compass,
  ExternalLink,
  GraduationCap,
  LibraryBig,
  LockKeyhole,
  Send,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "short",
  year: "numeric",
});

function TrainingCoverImage({
  src,
  alt,
  className,
  sizes,
  priority = false,
}: {
  src?: string | null;
  alt: string;
  className: string;
  sizes: string;
  priority?: boolean;
}) {
  const resolvedSource = src || INITIAL_TRAINING_COVER;
  const usesOptimizedInitialCover = resolvedSource === INITIAL_TRAINING_COVER;

  return (
    <img
      src={resolvedSource}
      srcSet={
        usesOptimizedInitialCover ? INITIAL_TRAINING_COVER_SRC_SET : undefined
      }
      sizes={usesOptimizedInitialCover ? sizes : undefined}
      alt={alt}
      width={1280}
      height={720}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      fetchPriority={priority ? "high" : "low"}
      className={className}
    />
  );
}

function isMarkdownContent(
  value: TrainingBody | { kind: "markdown"; markdown: string }
): value is { kind: "markdown"; markdown: string } {
  return "kind" in value && value.kind === "markdown";
}

function parseReferenceLines(value: string) {
  return value
    .split("\n")
    .map(line => line.trim())
    .filter(Boolean)
    .map(line => {
      const [title = "", url = "", note = ""] = line
        .split("|")
        .map(part => part.trim());
      return { title, url, note };
    });
}

function TrainingCard({
  training,
  onOpen,
}: {
  training: {
    slug: string;
    title: string;
    summary: string;
    category: string;
    audience: string;
    estimatedMinutes: number;
    coverUrl: string;
    publishedAt: Date | null;
  };
  onOpen: () => void;
}) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-emerald-100 bg-white shadow-[0_18px_50px_-42px_rgba(6,78,59,.65)] transition duration-200 hover:-translate-y-0.5 hover:border-lime-400 hover:shadow-[0_22px_55px_-38px_rgba(6,78,59,.55)]">
      <div className="relative aspect-[16/8] overflow-hidden bg-[#0e3426]">
        <TrainingCoverImage
          src={training.coverUrl || INITIAL_TRAINING_COVER}
          alt="Ilustração da jornada até Ítaca"
          sizes="(max-width: 767px) calc(100vw - 40px), 464px"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.025]"
        />
        <span className="absolute left-4 top-4 rounded-full border border-white/20 bg-[#0e3426]/90 px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-lime-100">
          {training.category}
        </span>
      </div>
      <div className="p-5 sm:p-6">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 font-mono text-[10px] font-semibold uppercase tracking-[.1em] text-emerald-700/65">
          <span className="inline-flex items-center gap-1">
            <Clock3 size={13} /> {training.estimatedMinutes} min
          </span>
          <span>{training.audience}</span>
        </div>
        <h2 className="mt-3 text-xl font-semibold tracking-[-.035em] text-emerald-950">
          {training.title}
        </h2>
        <p className="mt-3 text-sm leading-6 text-emerald-900/70">
          {training.summary}
        </p>
        <div className="mt-5 flex items-center justify-between gap-3">
          <span className="text-xs text-emerald-800/60">
            {training.publishedAt
              ? `Publicado em ${dateFormatter.format(new Date(training.publishedAt))}`
              : "Em preparação"}
          </span>
          <Button
            size="sm"
            onClick={onOpen}
            className="bg-[#0e3426] text-white hover:bg-[#174a36]"
          >
            <BookMarked size={15} /> Abrir trilha <ArrowRight size={15} />
          </Button>
        </div>
      </div>
    </article>
  );
}

function StructuredCourse({ body }: { body: TrainingBody }) {
  return (
    <div className="space-y-7">
      <section className="rounded-2xl border border-emerald-100 bg-[#f7f8f1] p-5 sm:p-6">
        <p className="text-base leading-7 text-emerald-950">{body.intro}</p>
        <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-950">
          <div className="flex items-start gap-2">
            <ShieldCheck className="mt-0.5 shrink-0 text-amber-700" size={17} />
            <p>
              <b>Limite operacional.</b> {body.operationalNote}
            </p>
          </div>
        </div>
      </section>
      <section>
        <div className="mb-3 flex items-center gap-2">
          <Compass size={18} className="text-emerald-700" />
          <h2 className="text-xl font-semibold tracking-[-.035em] text-emerald-950">
            Ao concluir, você será capaz de
          </h2>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {body.outcomes.map(outcome => (
            <article
              key={outcome.label}
              className="rounded-xl border border-emerald-100 bg-white p-4"
            >
              <p className="font-semibold text-emerald-950">{outcome.label}</p>
              <p className="mt-1 text-sm leading-5 text-emerald-800/65">
                {outcome.evidence}
              </p>
            </article>
          ))}
        </div>
      </section>
      <Accordion
        type="single"
        collapsible
        defaultValue={body.sections[0]?.id}
        className="space-y-3"
      >
        {body.sections.map((section, index) => (
          <AccordionItem
            value={section.id}
            key={section.id}
            className="overflow-hidden rounded-2xl border border-emerald-100 bg-white px-0"
          >
            <AccordionTrigger className="px-5 py-5 text-left hover:no-underline sm:px-6">
              <span className="flex min-w-0 items-start gap-3">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-lime-200 font-mono text-xs font-bold text-emerald-950">
                  {index + 1}
                </span>
                <span>
                  <span className="block font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
                    {section.eyebrow}
                  </span>
                  <span className="mt-1 block text-lg font-semibold leading-6 text-emerald-950">
                    {section.title}
                  </span>
                </span>
              </span>
            </AccordionTrigger>
            <AccordionContent className="border-t border-emerald-100 px-5 pb-6 pt-5 sm:px-6">
              <p className="text-sm font-medium leading-6 text-emerald-900">
                {section.overview}
              </p>
              <div className="mt-4 space-y-4 text-sm leading-6 text-emerald-900/75">
                {section.paragraphs.map(paragraph => (
                  <p key={paragraph}>{paragraph}</p>
                ))}
              </div>
              {section.objectives?.length ? (
                <div className="mt-5 rounded-xl bg-[#f7f8f1] p-4">
                  <p className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
                    Objetivos de prática
                  </p>
                  <ul className="mt-3 grid gap-2 text-sm text-emerald-950">
                    {section.objectives.map(item => (
                      <li className="flex gap-2" key={item}>
                        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-600" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
              {section.tables?.map(table => (
                <div
                  className="mt-5 overflow-hidden rounded-xl border border-emerald-100"
                  key={table.title ?? table.columns.join("-")}
                >
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[640px] text-left text-sm">
                      <caption className="border-b border-emerald-100 bg-[#f7f8f1] px-4 py-3 text-left font-semibold text-emerald-950">
                        {table.title}
                      </caption>
                      <thead className="bg-white font-mono text-[10px] uppercase tracking-[.1em] text-emerald-700/70">
                        <tr>
                          {table.columns.map(column => (
                            <th
                              className="px-4 py-3 font-semibold"
                              key={column}
                            >
                              {column}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {table.rows.map((row, rowIndex) => (
                          <tr
                            className="border-t border-emerald-50 align-top"
                            key={`${table.title}-${rowIndex}`}
                          >
                            {row.map((cell, cellIndex) => (
                              <td
                                className="px-4 py-3 leading-5 text-emerald-900/75"
                                key={`${rowIndex}-${cellIndex}`}
                              >
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
              {section.script ? (
                <blockquote className="mt-5 rounded-xl border-l-4 border-lime-500 bg-[#0e3426] px-5 py-4 text-sm leading-6 text-emerald-50">
                  <p className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-lime-200">
                    {section.script.label}
                  </p>
                  <p className="mt-2">“{section.script.text}”</p>
                </blockquote>
              ) : null}
              {section.checklist?.length ? (
                <div className="mt-5">
                  <p className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
                    Checklist
                  </p>
                  <ul className="mt-3 grid gap-2 text-sm text-emerald-950">
                    {section.checklist.map(item => (
                      <li className="flex gap-2" key={item}>
                        <span className="mt-1.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-lime-200 text-[10px] font-bold text-emerald-950">
                          ✓
                        </span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
              {section.practice ? (
                <aside className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
                  <p className="font-semibold text-emerald-950">
                    {section.practice.title}
                  </p>
                  <p className="mt-1 text-sm leading-6 text-emerald-900/75">
                    {section.practice.prompt}
                  </p>
                  <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm leading-6 text-emerald-950">
                    {section.practice.steps.map(step => (
                      <li key={step}>{step}</li>
                    ))}
                  </ol>
                </aside>
              ) : null}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
      <blockquote className="rounded-2xl border border-lime-300 bg-lime-200/70 p-6 text-lg leading-7 text-emerald-950">
        <span className="mb-2 block font-mono text-[10px] font-semibold uppercase tracking-[.14em] text-emerald-800">
          Retorno a Ítaca
        </span>
        {body.closing}
      </blockquote>
    </div>
  );
}

function AdminWorkshop({ isAdmin }: { isAdmin: boolean }) {
  const utils = trpc.useUtils();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    slug: "",
    summary: "",
    category: "Estudos e treinamentos",
    audience: "Equipe comercial",
    estimatedMinutes: 45,
    contentMarkdown: "",
    references: "",
  });
  const drafts = trpc.training.adminList.useQuery(undefined, {
    enabled: isAdmin,
  });
  const create = trpc.training.createDraft.useMutation({
    onSuccess: async () => {
      toast.success(
        "Rascunho criado. Ele ainda não está visível para a equipe."
      );
      setForm({
        title: "",
        slug: "",
        summary: "",
        category: "Estudos e treinamentos",
        audience: "Equipe comercial",
        estimatedMinutes: 45,
        contentMarkdown: "",
        references: "",
      });
      setOpen(false);
      await utils.training.adminList.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const publish = trpc.training.publish.useMutation({
    onSuccess: async () => {
      toast.success(
        "Treinamento publicado e aviso interno criado para os usuários atuais."
      );
      await Promise.all([
        utils.training.adminList.invalidate(),
        utils.training.list.invalidate(),
        utils.training.announcement.invalidate(),
        utils.notifications.list.invalidate(),
      ]);
    },
    onError: error => toast.error(error.message),
  });
  const canCreate =
    form.title.trim().length >= 5 &&
    form.slug.trim().length >= 3 &&
    form.summary.trim().length >= 20 &&
    form.contentMarkdown.trim().length >= 80;
  if (!isAdmin) return null;
  return (
    <section className="mt-10 rounded-2xl border border-emerald-200 bg-white p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[.14em] text-emerald-700">
            Oficina do arquivista
          </p>
          <h2 className="mt-1 text-xl font-semibold tracking-[-.035em] text-emerald-950">
            Publicação controlada
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-emerald-800/65">
            Este espaço é exclusivo da administração global. Rascunhos não
            aparecem para agentes, lideranças ou distritais até a publicação
            explícita.
          </p>
        </div>
        <Button
          variant="outline"
          className="border-emerald-200 text-emerald-950"
          onClick={() => setOpen(value => !value)}
        >
          {open ? "Fechar editor" : "Criar rascunho"}
        </Button>
      </div>
      {open ? (
        <div className="mt-6 border-t border-emerald-100 pt-6">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-1 text-xs font-medium text-emerald-950">
              Título
              <Input
                value={form.title}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    title: event.target.value,
                  }))
                }
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950">
              Identificador da URL
              <Input
                value={form.slug}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    slug: event.target.value
                      .toLowerCase()
                      .replace(/[^a-z0-9-]/g, ""),
                  }))
                }
                placeholder="ex.: negociacao-consultiva"
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950">
              Categoria
              <Input
                value={form.category}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    category: event.target.value,
                  }))
                }
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950">
              Público
              <Input
                value={form.audience}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    audience: event.target.value,
                  }))
                }
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950">
              Duração estimada (min)
              <Input
                type="number"
                min={5}
                max={480}
                value={form.estimatedMinutes}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    estimatedMinutes: Number(event.target.value) || 5,
                  }))
                }
              />
            </label>
            <div className="rounded-lg bg-[#f7f8f1] px-4 py-3 text-xs leading-5 text-emerald-800/70">
              <b className="block text-emerald-950">Capa segura</b>O novo
              rascunho utilizará a ilustração da Biblioteca até receber um ativo
              próprio autorizado.
            </div>
            <label className="grid gap-1 text-xs font-medium text-emerald-950 md:col-span-2">
              Resumo
              <Textarea
                rows={3}
                value={form.summary}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    summary: event.target.value,
                  }))
                }
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950 md:col-span-2">
              Conteúdo em Markdown
              <Textarea
                rows={12}
                value={form.contentMarkdown}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    contentMarkdown: event.target.value,
                  }))
                }
                placeholder="# Título\n\nTexto do treinamento..."
              />
            </label>
            <label className="grid gap-1 text-xs font-medium text-emerald-950 md:col-span-2">
              Referências externas — uma por linha: Título | URL | Nota
              <Textarea
                rows={4}
                value={form.references}
                onChange={event =>
                  setForm(current => ({
                    ...current,
                    references: event.target.value,
                  }))
                }
                placeholder="Fonte | https://exemplo.com | Como a fonte apoia a trilha"
              />
            </label>
          </div>
          <Button
            className="mt-5 bg-[#0e3426] text-white hover:bg-[#174a36]"
            disabled={!canCreate || create.isPending}
            onClick={() =>
              create.mutate({
                ...form,
                coverUrl: INITIAL_TRAINING_COVER,
                references: parseReferenceLines(form.references),
              })
            }
          >
            <Send size={16} />{" "}
            {create.isPending ? "Salvando..." : "Salvar como rascunho"}
          </Button>
        </div>
      ) : null}
      <div className="mt-7 border-t border-emerald-100 pt-5">
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[.12em] text-emerald-700">
          Rascunhos e publicações
        </p>
        <div className="mt-3 grid gap-3">
          {drafts.data?.map(draft => (
            <div
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-[#f7f8f1] p-4"
              key={draft.id}
            >
              <div>
                <p className="font-semibold text-emerald-950">{draft.title}</p>
                <p className="mt-1 text-xs text-emerald-800/65">
                  {draft.status === "publicado"
                    ? "Publicado"
                    : "Rascunho privado"}{" "}
                  · {draft.estimatedMinutes} min
                </p>
              </div>
              {draft.status === "rascunho" ? (
                <Button
                  size="sm"
                  disabled={publish.isPending}
                  onClick={() => publish.mutate({ id: draft.id })}
                >
                  Publicar e avisar
                </Button>
              ) : (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                  <LockKeyhole size={14} /> Publicado
                </span>
              )}
            </div>
          ))}
          {!drafts.isLoading && !drafts.data?.length ? (
            <p className="text-sm text-emerald-800/65">
              Nenhum conteúdo editorial registrado.
            </p>
          ) : null}
        </div>
      </div>
    </section>
  );
}

export default function BibliotecaItacaPanel({
  isAdmin,
}: {
  isAdmin: boolean;
}) {
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const library = trpc.training.list.useQuery();
  const selected = trpc.training.get.useQuery(
    { slug: selectedSlug ?? "onboarding-clientes-gestao-estrategica-base" },
    { enabled: Boolean(selectedSlug) }
  );
  const selectedItem = useMemo(
    () =>
      library.data?.find(training => training.slug === selectedSlug) ?? null,
    [library.data, selectedSlug]
  );
  if (selectedSlug)
    return (
      <div className="max-w-5xl space-y-6">
        <button
          className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-800 transition hover:text-emerald-950"
          onClick={() => setSelectedSlug(null)}
        >
          <ArrowLeft size={17} /> Voltar para a Biblioteca
        </button>
        {selected.isLoading ? (
          <div className="rounded-2xl border border-emerald-100 bg-white p-8 text-sm text-emerald-700">
            Abrindo a trilha...
          </div>
        ) : null}
        {selected.error ? (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-900">
            Não foi possível abrir este treinamento. {selected.error.message}
          </div>
        ) : null}
        {selected.data ? (
          <>
            <section className="overflow-hidden rounded-3xl border border-emerald-100 bg-[#0e3426] text-white">
              <div className="relative grid lg:grid-cols-[1.12fr_.88fr]">
                <div className="relative z-10 p-6 sm:p-8 lg:p-10">
                  <p className="font-mono text-[10px] font-semibold uppercase tracking-[.15em] text-lime-200">
                    {selected.data.category}
                  </p>
                  <h1 className="mt-3 max-w-2xl text-3xl font-semibold leading-tight tracking-[-.055em] sm:text-4xl">
                    {selected.data.title}
                  </h1>
                  <p className="mt-4 max-w-2xl text-sm leading-6 text-emerald-100/75">
                    {selected.data.summary}
                  </p>
                  <div className="mt-6 flex flex-wrap gap-3 text-xs text-emerald-100/80">
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3 py-1.5">
                      <Clock3 size={14} /> {selected.data.estimatedMinutes} min
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3 py-1.5">
                      <GraduationCap size={14} /> {selected.data.audience}
                    </span>
                  </div>
                </div>
                <TrainingCoverImage
                  src={
                    selected.data.coverUrl ||
                    selectedItem?.coverUrl ||
                    INITIAL_TRAINING_COVER
                  }
                  alt="Navegadora chegando a Ítaca"
                  sizes="(max-width: 1023px) calc(100vw - 40px), 44vw"
                  priority
                  className="min-h-56 h-full w-full object-cover lg:min-h-full"
                />
              </div>
            </section>
            <div className="flex justify-end">
              <ExportPdfButton
                label="Exportar treinamento em PDF"
                payload={{
                  exportType: "treinamento",
                  referenceKey: selected.data.slug,
                  title: selected.data.title,
                  subtitle: `${selected.data.category} · ${selected.data.estimatedMinutes} minutos`,
                  sections: isMarkdownContent(selected.data.content)
                    ? [
                        {
                          title: "Conteúdo",
                          text: selected.data.content.markdown.slice(0, 900),
                        },
                      ]
                    : selected.data.content.sections
                        .slice(0, 8)
                        .map(section => ({
                          title: section.title,
                          text: section.overview,
                          items: section.paragraphs.slice(0, 4),
                        })),
                }}
              />
            </div>
            {isMarkdownContent(selected.data.content) ? (
              <section className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-7">
                <div className="prose prose-emerald max-w-none prose-headings:tracking-[-.035em]">
                  <Streamdown>{selected.data.content.markdown}</Streamdown>
                </div>
              </section>
            ) : (
              <StructuredCourse body={selected.data.content} />
            )}
            <section className="rounded-2xl border border-emerald-100 bg-white p-5 sm:p-6">
              <div className="flex items-center gap-2">
                <LibraryBig className="text-emerald-700" size={19} />
                <h2 className="text-xl font-semibold tracking-[-.035em] text-emerald-950">
                  Referências para aprofundar
                </h2>
              </div>
              <p className="mt-2 text-sm leading-6 text-emerald-800/65">
                As fontes abaixo sustentam conceitos gerais. Leia as políticas e
                os materiais internos vigentes antes de converter conhecimento
                em procedimento operacional.
              </p>
              <div className="mt-5 grid gap-3">
                {selected.data.references.map(reference => (
                  <a
                    key={reference.url}
                    href={reference.url}
                    target="_blank"
                    rel="noreferrer"
                    className="group rounded-xl border border-emerald-100 p-4 transition hover:border-lime-400 hover:bg-[#f7f8f1]"
                  >
                    <span className="flex items-start justify-between gap-3">
                      <span>
                        <b className="block text-sm text-emerald-950">
                          {reference.title}
                        </b>
                        <span className="mt-1 block text-sm leading-5 text-emerald-800/65">
                          {reference.note}
                        </span>
                      </span>
                      <ExternalLink
                        className="mt-0.5 shrink-0 text-emerald-600"
                        size={17}
                      />
                    </span>
                  </a>
                ))}
              </div>
            </section>
          </>
        ) : null}
      </div>
    );
  return (
    <div className="max-w-6xl space-y-7">
      <section className="overflow-hidden rounded-3xl border border-emerald-100 bg-[#0e3426] text-white">
        <div className="grid items-center gap-6 p-6 sm:p-8 lg:grid-cols-[1.05fr_.95fr] lg:p-10">
          <div>
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[.16em] text-lime-200">
              Biblioteca de Ítaca · estudos e treinamentos
            </p>
            <h1 className="mt-3 max-w-2xl text-3xl font-semibold leading-tight tracking-[-.055em] sm:text-4xl">
              Conhecimento para navegar com método entre uma conversa e outra.
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-6 text-emerald-100/75">
              Trilhas práticas para transformar campo, dados e reflexão em
              decisões melhores. Cada material é publicado de forma controlada e
              apresentado com fontes para aprofundamento.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <span className="inline-flex items-center gap-2 rounded-full bg-lime-200 px-3 py-1.5 text-xs font-semibold text-emerald-950">
                <Sparkles size={14} /> Conteúdo inaugural disponível
              </span>
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-xs text-emerald-100">
                <Compass size={14} /> Treine no seu ritmo
              </span>
            </div>
          </div>
          <div className="relative hidden min-h-44 overflow-hidden rounded-2xl border border-white/10 bg-emerald-900/30 lg:block">
            <TrainingCoverImage
              src={INITIAL_TRAINING_COVER}
              alt="Ilustração da Biblioteca de Ítaca"
              sizes="430px"
              priority
              className="absolute inset-0 h-full w-full object-cover opacity-90"
            />
          </div>
        </div>
      </section>
      <section>
        <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="font-mono text-[10px] font-semibold uppercase tracking-[.14em] text-emerald-700">
              Trilhas publicadas
            </p>
            <h2 className="mt-1 text-2xl font-semibold tracking-[-.045em] text-emerald-950">
              Escolha sua próxima jornada
            </h2>
          </div>
          <p className="text-sm text-emerald-800/65">
            {library.data?.length ?? 0}{" "}
            {library.data?.length === 1
              ? "material disponível"
              : "materiais disponíveis"}
          </p>
        </div>
        {library.isLoading ? (
          <div className="grid gap-5 md:grid-cols-2">
            <div className="h-80 animate-pulse rounded-2xl bg-emerald-100/60" />
            <div className="h-80 animate-pulse rounded-2xl bg-emerald-100/60" />
          </div>
        ) : null}
        {library.error ? (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-900">
            Não foi possível carregar a Biblioteca. {library.error.message}
          </div>
        ) : null}
        {!library.isLoading && !library.error && !library.data?.length ? (
          <div className="rounded-2xl border border-emerald-100 bg-white p-8 text-center">
            <LibraryBig className="mx-auto text-emerald-600" size={30} />
            <h2 className="mt-3 font-semibold text-emerald-950">
              A Biblioteca está preparando sua primeira travessia.
            </h2>
            <p className="mt-2 text-sm text-emerald-800/65">
              Volte em breve para encontrar novas trilhas de estudo.
            </p>
          </div>
        ) : null}
        <div className="grid gap-5 md:grid-cols-2">
          {library.data?.map(training => (
            <TrainingCard
              key={training.slug}
              training={training}
              onOpen={() => setSelectedSlug(training.slug)}
            />
          ))}
        </div>
      </section>
      <AdminWorkshop isAdmin={isAdmin} />
    </div>
  );
}
