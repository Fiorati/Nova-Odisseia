import { ArrowRight, BookOpen, Compass, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";

export function TrainingAnnouncement() {
  const trainingAnnouncement = trpc.training.announcement.useQuery();
  const training = trainingAnnouncement.data?.training;
  const openLibrary = () => {
    window.location.assign("?view=biblioteca");
  };
  if (!training) return null;
  return (
    <button
      type="button"
      onClick={openLibrary}
      className="group relative w-full overflow-hidden rounded-xl border border-lime-300 bg-lime-200 p-5 text-left text-emerald-950 shadow-[0_12px_30px_-24px_rgba(6,78,59,.75)] transition hover:-translate-y-0.5 hover:bg-lime-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-700 focus-visible:ring-offset-2"
    >
      <div className="absolute -right-7 -top-10 h-28 w-28 rounded-full border-[18px] border-emerald-800/10" />
      <div className="relative flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-emerald-950 text-lime-200">
            <Sparkles size={17} />
          </span>
          <span>
            <span className="block font-mono text-[10px] font-bold uppercase tracking-[.14em] text-emerald-800">
              {trainingAnnouncement.data?.hasUnreadNotification
                ? "Novo treinamento disponível"
                : "Biblioteca de Ítaca"}
            </span>
            <strong className="mt-1 block text-base leading-5">
              {training.title}
            </strong>
            <span className="mt-1 block text-sm text-emerald-900/75">
              Abra a trilha, pratique o roteiro e leve a próxima ação para o
              campo.
            </span>
          </span>
        </div>
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-emerald-950">
          Ir para treinamentos{" "}
          <ArrowRight
            size={17}
            className="transition group-hover:translate-x-0.5"
          />
        </span>
      </div>
    </button>
  );
}

export default function ItakaDailyWelcome({
  displayName,
}: {
  displayName: string;
}) {
  const dailyMessage = trpc.agent.dailyItakaMessage.useQuery();
  const message = dailyMessage.data?.message;

  return (
    <>
      <TrainingAnnouncement />
      <section className="ledger-surface relative overflow-hidden rounded-lg border border-emerald-100 bg-white p-6 md:p-8">
        <div className="absolute -right-12 -top-14 h-40 w-40 rounded-full border-[24px] border-emerald-100/70" />
        <div className="relative max-w-4xl">
          <div className="flex items-center gap-2 font-mono text-[10px] font-semibold tracking-[.16em] text-emerald-600">
            <Compass size={14} aria-hidden="true" /> ÍTAKA /{" "}
            {dailyMessage.data?.dateLabel ?? "—"}
          </div>
          <h2 className="mt-3 text-3xl font-semibold tracking-[-.055em]">
            Olá, {displayName}.
          </h2>
          <p className="mt-3 max-w-3xl text-base font-medium leading-7 text-emerald-950">
            {message?.phrase ??
              (dailyMessage.isError
                ? "A travessia continua: organize a próxima ação e avance um passo de cada vez."
                : "Preparando a mensagem da sua jornada...")}
          </p>
          {message && (
            <aside className="itaka-passage mt-5 rounded-lg border p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="itaka-passage-label flex items-center gap-2 font-mono text-[10px] font-semibold tracking-[.13em]">
                  <BookOpen size={13} aria-hidden="true" /> PASSAGEM DA ODISSEIA
                </p>
                <span className="itaka-passage-theme rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.1em]">
                  {message.theme}
                </span>
              </div>
              <p className="itaka-passage-text mt-3 max-w-3xl whitespace-pre-line text-sm leading-6">
                {message.passage}
              </p>
              <p className="itaka-passage-citation mt-3 font-mono text-[10px] font-semibold tracking-[.12em]">
                ODISSEIA — {message.citation}
              </p>
            </aside>
          )}
        </div>
      </section>
    </>
  );
}
