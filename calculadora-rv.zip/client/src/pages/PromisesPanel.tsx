import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import {
  promisePeriodKey,
  type PromisePeriod,
} from "@shared/gamificationChallenges";
import { Flag } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import RouteObjectivePanel from "./RouteObjectivePanel";
const labels: { [K in PromisePeriod]: string } = {
  dia: "Objetivo do Dia",
  semana: "Objetivo da Semana",
  mes: "Objetivo do Mês",
};
const zero = {
  salesTasks: 0,
  newProposals: 0,
  newClients: 0,
  newActives: 0,
  newTpv: 0,
};
export default function PromisesPanel() {
  const utils = trpc.useUtils();
  const [periodType, setPeriodType] = useState<PromisePeriod>("dia");
  const [periodKey, setPeriodKey] = useState(() => promisePeriodKey("dia"));
  const [m, setM] = useState(zero);
  const save = trpc.promises.save.useMutation({
    onSuccess: async () => {
      await utils.promises.panel.invalidate();
      toast.success("Objetivo registrado.");
    },
    onError: e => toast.error(e.message),
  });
  return (
    <div className="space-y-7">
      <section className="rounded-2xl bg-[#0e3426] p-7 text-white">
        <p className="font-mono text-[10px] tracking-[.15em] text-lime-200">
          ROTEIRO E OBJETIVO
        </p>
        <h1 className="mt-2 text-4xl font-semibold tracking-[-.06em]">
          Planeje o dia. Declare o objetivo. Execute.
        </h1>
      </section>
      <RouteObjectivePanel />
      <section className="rounded-xl border border-emerald-100 bg-white p-5">
        <h2 className="text-xl font-semibold text-emerald-950">
          Objetivo numérico
        </h2>
        <div className="mt-3 flex gap-2">
          {(["dia", "semana", "mes"] as PromisePeriod[]).map(p => (
            <button
              className={`rounded-full px-4 py-2 text-xs font-semibold ${p === periodType ? "bg-[#0e3426] text-white" : "bg-emerald-50 text-emerald-900"}`}
              key={p}
              onClick={() => {
                setPeriodType(p);
                setPeriodKey(promisePeriodKey(p));
              }}
            >
              {labels[p]}
            </button>
          ))}
        </div>
        <label className="mt-4 grid gap-1 text-xs">
          Período
          <Input
            type={periodType === "mes" ? "month" : "date"}
            value={periodKey}
            onChange={e => setPeriodKey(e.target.value)}
          />
        </label>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {Object.entries({
            salesTasks: "Tarefas",
            newProposals: "Propostas",
            newClients: "Clientes",
            newActives: "Ativos",
            newTpv: "TPV",
          }).map(([key, label]) => (
            <label className="grid gap-1 text-xs" key={key}>
              {label}
              <Input
                type="number"
                min="0"
                value={m[key as keyof typeof m]}
                onChange={e =>
                  setM(v => ({ ...v, [key]: Number(e.target.value) || 0 }))
                }
              />
            </label>
          ))}
        </div>
        <Button
          className="mt-4 bg-[#0e3426] text-white"
          onClick={() => save.mutate({ periodType, periodKey, ...m })}
        >
          <Flag size={16} />
          Registrar objetivo
        </Button>
      </section>
    </div>
  );
}
