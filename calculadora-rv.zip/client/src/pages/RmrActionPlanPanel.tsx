import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { PlanningDocumentPanel } from "@/components/PlanningDocumentPanel";
import { ExportPdfButton } from "@/components/ExportPdfButton";
import { exportPrivatePdf } from "@/lib/printDocument";
import {
  BookOpenCheck,
  CheckCircle2,
  ClipboardList,
  FileDown,
  Target,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { calculateRmrKpi } from "@shared/metrics";
import { recommendRmrContent } from "@shared/rmrContent";

const percent = new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 });

export default function RmrActionPlanPanel({
  defaultGoal,
  lastVariable,
}: {
  defaultGoal: number;
  lastVariable: number;
}) {
  const [periodLabel, setPeriodLabel] = useState("Análise mensal");
  const [workingDays, setWorkingDays] = useState(20);
  const [salesTasks, setSalesTasks] = useState(0);
  const [proposals, setProposals] = useState(0);
  const [closedClients, setClosedClients] = useState(0);
  const [closedTpv, setClosedTpv] = useState(0);
  const [goalTpv, setGoalTpv] = useState(defaultGoal);
  const [variableValue, setVariableValue] = useState(lastVariable);
  const [rootCause, setRootCause] = useState("");
  const [actionPlan, setActionPlan] = useState("");
  const [owner, setOwner] = useState("");
  const [expectedResult, setExpectedResult] = useState("");
  const [dueAt, setDueAt] = useState("");
  const calculated = useMemo(
    () =>
      calculateRmrKpi({
        workingDays,
        salesTasks,
        proposals,
        closedClients,
        closedTpv,
        goalTpv,
      }),
    [workingDays, salesTasks, proposals, closedClients, closedTpv, goalTpv]
  );
  const recommendations = useMemo(
    () =>
      recommendRmrContent({
        tasksRate: calculated.taskScore,
        proposalsRate: calculated.proposalScore,
        tpvRate: calculated.tpvScore,
      }),
    [calculated]
  );
  const save = trpc.rmr.save.useMutation({
    onSuccess: result =>
      toast.success(
        result.pointsAwarded
          ? `RMR registrada. +${result.pointsAwarded} pontos por KPI mensal.`
          : "RMR registrada."
      ),
    onError: error => toast.error(error.message),
  });
  const submit = () =>
    save.mutate({
      periodLabel,
      workingDays,
      salesTasks,
      proposals,
      closedClients,
      closedTpv,
      goalTpv,
      variableValue,
      rootCause,
      actionPlan,
      owner,
      expectedResult,
      dueAt: dueAt ? new Date(`${dueAt}T12:00:00.000Z`) : null,
    });
  const exportRmr = () => {
    const ok = exportPrivatePdf("RMR — Revisão mensal", periodLabel, [
      {
        title: "Indicadores",
        items: [
          `Dias úteis: ${workingDays}`,
          `Tarefas de venda: ${salesTasks}`,
          `Propostas: ${proposals}`,
          `Clientes fechados: ${closedClients}`,
          `TPV novo: R$ ${closedTpv.toLocaleString("pt-BR")}`,
          `Meta TPV: R$ ${goalTpv.toLocaleString("pt-BR")}`,
          `RV do período: R$ ${variableValue.toLocaleString("pt-BR")}`,
        ],
      },
      {
        title: `KPI global: ${percent.format(calculated.globalKpi)}%`,
        items: [
          `Tarefas: ${percent.format(calculated.taskScore * 100)}%`,
          `Propostas: ${percent.format(calculated.proposalScore * 100)}%`,
          `TPV: ${percent.format(calculated.tpvScore * 100)}%`,
        ],
      },
      {
        title: "Plano de ação",
        items: [
          `Causa-raiz: ${rootCause || "Não informado."}`,
          `Ação: ${actionPlan || "Não informado."}`,
          `Responsável: ${owner || "Não informado."}`,
          `Prazo: ${dueAt ? new Date(`${dueAt}T12:00:00`).toLocaleDateString("pt-BR") : "Não informado."}`,
          `Resultado esperado: ${expectedResult || "Não informado."}`,
        ],
      },
    ]);
    if (!ok) toast.error("Permita a janela de impressão para salvar o PDF.");
  };
  return (
    <div className="space-y-6">
      <PlanningDocumentPanel type="rmr" referenceKey={periodLabel} />
      <section className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-mono text-[10px] font-semibold tracking-[.14em] text-emerald-600">
            RMR / REVISÃO MENSAL
          </p>
          <h2 className="mt-2 text-3xl font-semibold tracking-[-.055em]">
            Indicadores para corrigir a rota.
          </h2>
          <p className="mt-2 text-sm text-emerald-800/65">
            Registre o período e transforme o principal desvio em uma ação com
            responsável, prazo e resultado esperado.
          </p>
        </div>
        <ExportPdfButton
          label="Exportar RMR em PDF"
          payload={{
            exportType: "rmr",
            referenceKey: periodLabel,
            title: "RMR — Revisão mensal",
            subtitle: periodLabel,
            sections: [
              {
                title: "Indicadores",
                items: [
                  `Dias úteis: ${workingDays}`,
                  `Tarefas: ${salesTasks}`,
                  `Propostas: ${proposals}`,
                  `Clientes: ${closedClients}`,
                  `TPV: R$ ${closedTpv.toLocaleString("pt-BR")}`,
                  `Meta: R$ ${goalTpv.toLocaleString("pt-BR")}`,
                  `RV: R$ ${variableValue.toLocaleString("pt-BR")}`,
                ],
              },
              {
                title: `KPI global ${percent.format(calculated.globalKpi)}%`,
                items: [
                  `Tarefas: ${percent.format(calculated.taskScore * 100)}%`,
                  `Propostas: ${percent.format(calculated.proposalScore * 100)}%`,
                  `TPV: ${percent.format(calculated.tpvScore * 100)}%`,
                ],
              },
              { title: "Causa-raiz", text: rootCause || "Não informada." },
              {
                title: "Plano de ação",
                items: [
                  actionPlan || "Ação não informada.",
                  `Responsável: ${owner || "não informado"}`,
                  `Prazo: ${dueAt || "não informado"}`,
                  `Resultado: ${expectedResult || "não informado"}`,
                ],
              },
            ],
          }}
        />
      </section>
      <section className="grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
        <article className="rounded-xl border border-emerald-100 bg-white p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="grid gap-1 text-xs sm:col-span-2">
              Período
              <Input
                value={periodLabel}
                onChange={e => setPeriodLabel(e.target.value)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              Dias úteis
              <Input
                type="number"
                value={workingDays}
                onChange={e => setWorkingDays(Number(e.target.value) || 1)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              Tarefas de venda
              <Input
                type="number"
                value={salesTasks}
                onChange={e => setSalesTasks(Number(e.target.value) || 0)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              Propostas
              <Input
                type="number"
                value={proposals}
                onChange={e => setProposals(Number(e.target.value) || 0)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              Clientes fechados
              <Input
                type="number"
                value={closedClients}
                onChange={e => setClosedClients(Number(e.target.value) || 0)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              TPV novo
              <Input
                type="number"
                value={closedTpv}
                onChange={e => setClosedTpv(Number(e.target.value) || 0)}
              />
            </label>
            <label className="grid gap-1 text-xs">
              Meta TPV
              <Input
                type="number"
                value={goalTpv}
                onChange={e => setGoalTpv(Number(e.target.value) || 0)}
              />
            </label>
            <label className="grid gap-1 text-xs sm:col-span-2">
              RV do período
              <Input
                type="number"
                value={variableValue}
                onChange={e => setVariableValue(Number(e.target.value) || 0)}
              />
            </label>
          </div>
        </article>
        <article className="rounded-xl bg-[#f6f8f2] p-6">
          <p className="font-mono text-[10px] tracking-[.12em] text-emerald-600">
            KPI GLOBAL
          </p>
          <strong className="mt-3 block text-5xl tracking-[-.08em]">
            {percent.format(calculated.globalKpi)}%
          </strong>
          <p className="mt-2 text-sm text-emerald-800/65">
            Pontuação mensal única por KPI apurado.
          </p>
          <div className="mt-6 space-y-3 text-sm">
            <div className="flex justify-between">
              <span>Tarefas</span>
              <b>{percent.format(calculated.taskScore * 100)}%</b>
            </div>
            <div className="flex justify-between">
              <span>Propostas</span>
              <b>{percent.format(calculated.proposalScore * 100)}%</b>
            </div>
            <div className="flex justify-between">
              <span>TPV</span>
              <b>{percent.format(calculated.tpvScore * 100)}%</b>
            </div>
          </div>
        </article>
      </section>
      <section className="rounded-xl border border-emerald-100 bg-white p-5">
        <div className="flex items-center gap-2">
          <ClipboardList className="text-emerald-600" size={18} />
          <div>
            <p className="font-mono text-[10px] tracking-[.12em] text-emerald-600">
              PLANO DE AÇÃO
            </p>
            <h3 className="mt-1 text-xl font-semibold">
              Da causa-raiz ao próximo resultado.
            </h3>
          </div>
        </div>
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <label className="grid gap-1 text-xs">
            Causa-raiz
            <Textarea
              value={rootCause}
              onChange={e => setRootCause(e.target.value)}
            />
          </label>
          <label className="grid gap-1 text-xs">
            Ação concreta
            <Textarea
              value={actionPlan}
              onChange={e => setActionPlan(e.target.value)}
            />
          </label>
          <label className="grid gap-1 text-xs">
            Responsável
            <Input value={owner} onChange={e => setOwner(e.target.value)} />
          </label>
          <label className="grid gap-1 text-xs">
            Prazo
            <Input
              type="date"
              value={dueAt}
              onChange={e => setDueAt(e.target.value)}
            />
          </label>
          <label className="grid gap-1 text-xs lg:col-span-2">
            Resultado esperado
            <Textarea
              value={expectedResult}
              onChange={e => setExpectedResult(e.target.value)}
            />
          </label>
        </div>
        <Button
          className="mt-5 bg-[#0e3426]"
          disabled={save.isPending}
          onClick={submit}
        >
          <CheckCircle2 size={16} />{" "}
          {save.isPending ? "Registrando..." : "Registrar RMR e plano"}
        </Button>
        <p className="mt-3 flex items-center gap-2 text-xs text-emerald-700/65">
          <Target size={15} /> Revise o plano na próxima RMR conforme os
          indicadores apurados.
        </p>
      </section>
      <section className="rounded-xl border border-lime-200 bg-lime-50 p-5">
        <div className="flex items-center gap-2">
          <BookOpenCheck className="text-emerald-700" size={18} />
          <div>
            <p className="font-mono text-[10px] tracking-[.12em] text-emerald-700">
              CONTEÚDO PRIORIZADO
            </p>
            <h3 className="mt-1 text-xl font-semibold text-emerald-950">
              Estude a lacuna antes da próxima cadência.
            </h3>
          </div>
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {recommendations.map((item, index) => (
            <article
              key={item.area}
              className="rounded-lg bg-white/85 p-4 text-sm text-emerald-900"
            >
              <span className="font-mono text-[10px] text-emerald-600">
                {String(index + 1).padStart(2, "0")} · {item.format}
              </span>
              <b className="mt-2 block">{item.title}</b>
              <p className="mt-2 text-xs leading-5 text-emerald-800/70">
                {item.focus}
              </p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
