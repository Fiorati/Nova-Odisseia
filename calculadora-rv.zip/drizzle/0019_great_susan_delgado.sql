CREATE TABLE `promises` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`periodType` enum('dia','semana','mes') NOT NULL,
	`periodKey` varchar(10) NOT NULL,
	`hierarchyRole` enum('none','polo','distrital') NOT NULL,
	`district` varchar(120) NOT NULL DEFAULT '',
	`polo` varchar(120) NOT NULL DEFAULT '',
	`salesTasks` int NOT NULL DEFAULT 0,
	`newProposals` int NOT NULL DEFAULT 0,
	`newClients` int NOT NULL DEFAULT 0,
	`newActives` int NOT NULL DEFAULT 0,
	`newTpv` double NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `promises_id` PRIMARY KEY(`id`),
	CONSTRAINT `promises_user_period_uq` UNIQUE(`userId`,`periodType`,`periodKey`)
);
--> statement-breakpoint
CREATE TABLE `x1_challenges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorUserId` int NOT NULL,
	`opponentUserId` int NOT NULL,
	`hierarchyRole` enum('none','polo','distrital') NOT NULL,
	`challengeDate` varchar(10) NOT NULL,
	`status` enum('pendente','aceito','concluido','recusado','cancelado') NOT NULL DEFAULT 'pendente',
	`kpisJson` text NOT NULL,
	`creatorResultsJson` text,
	`opponentResultsJson` text,
	`winnerUserId` int,
	`loserUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `x1_challenges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `agent_profiles` ADD `avatarKey` varchar(512) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `agent_profiles` ADD `avatarUrl` varchar(700) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `promises` ADD CONSTRAINT `promises_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `x1_challenges` ADD CONSTRAINT `x1_challenges_creatorUserId_users_id_fk` FOREIGN KEY (`creatorUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `x1_challenges` ADD CONSTRAINT `x1_challenges_opponentUserId_users_id_fk` FOREIGN KEY (`opponentUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `x1_challenges` ADD CONSTRAINT `x1_challenges_winnerUserId_users_id_fk` FOREIGN KEY (`winnerUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `x1_challenges` ADD CONSTRAINT `x1_challenges_loserUserId_users_id_fk` FOREIGN KEY (`loserUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `promises_polo_period_idx` ON `promises` (`polo`,`periodType`,`periodKey`);--> statement-breakpoint
CREATE INDEX `promises_district_period_idx` ON `promises` (`district`,`periodType`,`periodKey`);--> statement-breakpoint
CREATE INDEX `x1_challenges_creator_date_idx` ON `x1_challenges` (`creatorUserId`,`challengeDate`);--> statement-breakpoint
CREATE INDEX `x1_challenges_opponent_date_idx` ON `x1_challenges` (`opponentUserId`,`challengeDate`);--> statement-breakpoint
CREATE INDEX `x1_challenges_status_date_idx` ON `x1_challenges` (`status`,`challengeDate`);