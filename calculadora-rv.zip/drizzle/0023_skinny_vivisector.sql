CREATE TABLE `odyssey_updates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(180) NOT NULL,
	`title` varchar(220) NOT NULL,
	`summary` varchar(900) NOT NULL DEFAULT '',
	`category` varchar(100) NOT NULL DEFAULT 'Experiência',
	`readingMinutes` int NOT NULL DEFAULT 3,
	`contentJson` text NOT NULL,
	`status` enum('rascunho','publicado') NOT NULL DEFAULT 'rascunho',
	`createdByUserId` int,
	`updatedByUserId` int,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `odyssey_updates_id` PRIMARY KEY(`id`),
	CONSTRAINT `odyssey_updates_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `odyssey_updates` ADD CONSTRAINT `odyssey_updates_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `odyssey_updates` ADD CONSTRAINT `odyssey_updates_updatedByUserId_users_id_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `odyssey_updates_publication_idx` ON `odyssey_updates` (`status`,`publishedAt`);