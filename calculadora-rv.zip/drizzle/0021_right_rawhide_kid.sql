CREATE TABLE `training_contents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(180) NOT NULL,
	`title` varchar(220) NOT NULL,
	`summary` varchar(900) NOT NULL DEFAULT '',
	`category` varchar(100) NOT NULL DEFAULT 'Estudos e treinamentos',
	`audience` varchar(160) NOT NULL DEFAULT 'Equipe comercial',
	`estimatedMinutes` int NOT NULL DEFAULT 45,
	`coverUrl` varchar(900) NOT NULL DEFAULT '',
	`contentJson` text NOT NULL,
	`referencesJson` text NOT NULL,
	`status` enum('rascunho','publicado') NOT NULL DEFAULT 'rascunho',
	`createdByUserId` int,
	`updatedByUserId` int,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `training_contents_id` PRIMARY KEY(`id`),
	CONSTRAINT `training_contents_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `training_contents` ADD CONSTRAINT `training_contents_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `training_contents` ADD CONSTRAINT `training_contents_updatedByUserId_users_id_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `training_contents_publication_idx` ON `training_contents` (`status`,`publishedAt`);