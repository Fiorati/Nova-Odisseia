CREATE TABLE IF NOT EXISTS `daily_priorities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dayKey` varchar(10) NOT NULL,
	`position` int NOT NULL,
	`objective` varchar(160) NOT NULL DEFAULT '',
	`clientName` varchar(180) NOT NULL DEFAULT '',
	`expectedResult` varchar(240) NOT NULL DEFAULT '',
	`ownerName` varchar(160) NOT NULL DEFAULT '',
	`how` varchar(240) NOT NULL DEFAULT '',
	`whenLabel` varchar(120) NOT NULL DEFAULT '',
	`completed` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_priorities_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_priorities_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action,
	CONSTRAINT `daily_priority_user_day_position_uq` UNIQUE(`userId`,`dayKey`,`position`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `daily_route_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`dayKey` varchar(10) NOT NULL,
	`clientName` varchar(180) NOT NULL,
	`clientCode` varchar(64) NOT NULL DEFAULT '',
	`taskType` varchar(24) NOT NULL DEFAULT '',
	`address` varchar(500) NOT NULL DEFAULT '',
	`scheduledTime` varchar(5) NOT NULL DEFAULT '',
	`appointmentStatus` varchar(80) NOT NULL DEFAULT '',
	`situation` varchar(120) NOT NULL DEFAULT '',
	`notes` text,
	`dedupeKey` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_route_entries_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_route_entries_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action,
	CONSTRAINT `daily_route_user_day_dedupe_uq` UNIQUE(`userId`,`dayKey`,`dedupeKey`)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `document_exports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`exportType` enum('psv','rmr','roteiro','treinamento') NOT NULL,
	`referenceKey` varchar(180) NOT NULL,
	`fileName` varchar(180) NOT NULL,
	`fileKey` varchar(900) NOT NULL,
	`fileUrl` varchar(1000) NOT NULL,
	`emailedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `document_exports_id` PRIMARY KEY(`id`),
	CONSTRAINT `document_exports_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `planning_documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`documentType` enum('psv','rmr') NOT NULL,
	`referenceKey` varchar(80) NOT NULL,
	`fileName` varchar(180) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`fileSizeBytes` int NOT NULL,
	`fileKey` varchar(900) NOT NULL,
	`fileUrl` varchar(1000) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `planning_documents_id` PRIMARY KEY(`id`),
	CONSTRAINT `planning_documents_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `polo_active_commitments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`createdByUserId` int NOT NULL,
	`polo` varchar(120) NOT NULL,
	`periodType` enum('dia','semana') NOT NULL,
	`periodKey` varchar(10) NOT NULL,
	`targetActives` int NOT NULL DEFAULT 0,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `polo_active_commitments_id` PRIMARY KEY(`id`),
	CONSTRAINT `polo_active_commitments_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action,
	CONSTRAINT `polo_active_commitment_uq` UNIQUE(`polo`,`periodType`,`periodKey`)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `daily_route_user_day_idx` ON `daily_route_entries` (`userId`,`dayKey`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `document_exports_user_created_idx` ON `document_exports` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `planning_documents_user_type_ref_idx` ON `planning_documents` (`userId`,`documentType`,`referenceKey`);
