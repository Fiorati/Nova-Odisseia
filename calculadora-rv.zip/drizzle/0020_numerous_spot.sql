ALTER TABLE `route_portfolio_entries` ADD `status` varchar(80) DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `route_portfolio_entries` ADD `phase` varchar(32) DEFAULT '' NOT NULL;